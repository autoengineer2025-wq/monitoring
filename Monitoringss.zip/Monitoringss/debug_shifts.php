<?php
require_once __DIR__ . '/database/init.php';

$date = '2026-02-10';

echo "=== Checking FEEDER fproduction_breaks for $date ===\n";
$result = $database->select('fproduction_breaks', ['Shift'], [
    'production_date' => $date,
    'GROUP' => 'Shift'
]);
if ($result) {
    foreach ($result as $row) {
        echo "Found Shift value: '" . $row['Shift'] . "'\n";
    }
} else {
    echo "No records found\n";
}

echo "\n=== Checking FEEDER fproduction_record for $date ===\n";
$result = $database->select('fproduction_record', ['Shift'], [
    'production_date' => $date,
    'GROUP' => 'Shift',
    'LIMIT' => 5
]);
if ($result) {
    foreach ($result as $row) {
        echo "Found Shift value: '" . $row['Shift'] . "'\n";
    }
} else {
    echo "No records found\n";
}

echo "\n=== Direct Pattern Test ===\n";
$result = $database->select('fproduction_breaks', ['Shift', 'actual_accu'], [
    'production_date' => $date,
    'Shift[~]' => '%Day%',
    'LIMIT' => 3
]);
if ($result) {
    echo "Found " . count($result) . " records matching '%Day%'\n";
    foreach ($result as $row) {
        echo "  Shift: '" . $row['Shift'] . "', actual_accu: " . $row['actual_accu'] . "\n";
    }
} else {
    echo "No records match '%Day%' pattern\n";
}

echo "\n=== Row Count for $date ===\n";
$count = $database->count('fproduction_breaks', ['production_date' => $date]);
echo "Total fproduction_breaks: $count\n";

$count = $database->count('fproduction_record', ['production_date' => $date]);
echo "Total fproduction_record: $count\n";
?>
