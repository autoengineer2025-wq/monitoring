<?php
include 'database/init.php';

try {
    echo "Checking current table structure and fixing record_id...\n";
    
    // Check current primary key
    $indexes = $database->query("SHOW INDEXES FROM cproduction_record");
    echo "Current indexes:\n";
    foreach ($indexes as $index) {
        echo "- " . $index['Key_name'] . " (" . $index['Column_name'] . ")\n";
    }
    
    // Remove any record with record_id = 0 to avoid conflicts
    $database->delete('cproduction_record', ['record_id' => 0]);
    echo "Removed any records with record_id = 0\n";
    
    // Check if record_id is already a primary key
    $isPrimaryKey = false;
    foreach ($indexes as $index) {
        if ($index['Key_name'] === 'PRIMARY' && $index['Column_name'] === 'record_id') {
            $isPrimaryKey = true;
            break;
        }
    }
    
    if (!$isPrimaryKey) {
        echo "Making record_id the primary key...\n";
        // Drop existing primary key if there is one
        $database->query("ALTER TABLE cproduction_record DROP PRIMARY KEY");
        
        // Add record_id as primary key with auto_increment
        $database->query("ALTER TABLE cproduction_record ADD PRIMARY KEY (record_id)");
    }
    
    // Now add auto_increment
    echo "Adding AUTO_INCREMENT to record_id...\n";
    $database->query("ALTER TABLE cproduction_record MODIFY COLUMN record_id INT(11) NOT NULL AUTO_INCREMENT");
    
    // Reset the auto-increment counter
    $maxId = $database->max('cproduction_record', 'record_id');
    if ($maxId) {
        $database->query("ALTER TABLE cproduction_record AUTO_INCREMENT = " . ($maxId + 1));
        echo "Auto-increment counter set to: " . ($maxId + 1) . "\n";
    } else {
        $database->query("ALTER TABLE cproduction_record AUTO_INCREMENT = 1");
        echo "Auto-increment counter set to: 1\n";
    }
    
    // Verify the changes
    echo "\nUpdated table structure:\n";
    $columns = $database->query("SHOW COLUMNS FROM cproduction_record WHERE Field = 'record_id'");
    foreach ($columns as $column) {
        echo "record_id: " . $column['Field'] . " - " . $column['Type'] . " - " . $column['Extra'] . "\n";
    }
    
    echo "\nFix completed successfully!\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
