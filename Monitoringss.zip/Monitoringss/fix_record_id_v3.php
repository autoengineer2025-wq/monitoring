<?php
include 'database/init.php';

try {
    echo "Fixing record_id AUTO_INCREMENT issue...\n";
    
    // Check current table structure
    $columns = $database->query("SHOW COLUMNS FROM cproduction_record");
    $hasRecordId = false;
    foreach ($columns as $column) {
        if ($column['Field'] === 'record_id') {
            $hasRecordId = true;
            echo "Current record_id column: " . $column['Type'] . " - " . $column['Extra'] . "\n";
            break;
        }
    }
    
    if (!$hasRecordId) {
        echo "ERROR: record_id column not found!\n";
        exit;
    }
    
    // Check if there's a primary key
    $indexes = $database->query("SHOW INDEXES FROM cproduction_record");
    $primaryKeyColumn = null;
    foreach ($indexes as $index) {
        if ($index['Key_name'] === 'PRIMARY') {
            $primaryKeyColumn = $index['Column_name'];
            break;
        }
    }
    
    echo "Current primary key column: " . ($primaryKeyColumn ?: 'None') . "\n";
    
    // Remove any record with record_id = 0
    $database->delete('cproduction_record', ['record_id' => 0]);
    echo "Cleaned up any records with record_id = 0\n";
    
    // If record_id is not the primary key, make it primary
    if ($primaryKeyColumn !== 'record_id') {
        echo "Setting record_id as primary key...\n";
        
        // If there's another primary key, drop it first
        if ($primaryKeyColumn) {
            $database->query("ALTER TABLE cproduction_record DROP PRIMARY KEY");
            echo "Dropped existing primary key\n";
        }
        
        // Add record_id as primary key
        $database->query("ALTER TABLE cproduction_record ADD PRIMARY KEY (record_id)");
        echo "Added record_id as primary key\n";
    }
    
    // Now add auto_increment
    echo "Adding AUTO_INCREMENT to record_id...\n";
    $database->query("ALTER TABLE cproduction_record MODIFY COLUMN record_id INT(11) NOT NULL AUTO_INCREMENT");
    
    // Set the auto-increment starting value
    $maxId = $database->max('cproduction_record', 'record_id');
    $nextId = $maxId ? $maxId + 1 : 1;
    $database->query("ALTER TABLE cproduction_record AUTO_INCREMENT = $nextId");
    echo "Auto-increment starting value set to: $nextId\n";
    
    // Verify the fix
    echo "\nVerification - Updated record_id column:\n";
    $columns = $database->query("SHOW COLUMNS FROM cproduction_record WHERE Field = 'record_id'");
    foreach ($columns as $column) {
        echo $column['Field'] . " - " . $column['Type'] . " - " . $column['Extra'] . "\n";
    }
    
    echo "\n✅ SUCCESS: record_id is now properly configured as AUTO_INCREMENT!\n";
    
} catch (Exception $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
}
?>
