<?php
include 'database/init.php';

try {
    echo "Checking cproduction_record table structure...\n";
    
    // Check if table exists
    $tables = $database->query("SHOW TABLES LIKE 'cproduction_record'");
    if (empty($tables)) {
        echo "Table cproduction_record does not exist!\n";
        exit;
    }
    
    echo "Table exists. Showing structure:\n";
    $columns = $database->query("SHOW COLUMNS FROM cproduction_record");
    foreach ($columns as $column) {
        echo $column['Field'] . " - " . $column['Type'] . " - " . $column['Extra'] . "\n";
    }
    
    // Check the most recent record
    echo "\nMost recent record:\n";
    $latest = $database->get('cproduction_record', '*', ['ORDER' => ['record_id' => 'DESC']]);
    if ($latest) {
        echo "record_id: " . $latest['record_id'] . "\n";
        echo "created_at: " . ($latest['created_at'] ?? 'N/A') . "\n";
    } else {
        echo "No records found.\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
