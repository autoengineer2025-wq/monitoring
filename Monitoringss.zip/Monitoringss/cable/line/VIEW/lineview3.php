<?php
include_once '../../../database/init.php';

// Function to get current shift based on time
function getCurrentShift() {
    $currentHour = intval(date('H'));
    // Day Shift: 6am (06) to 6pm (18)
    // Night Shift: 6pm (18) to 6am (06)
    if ($currentHour >= 6 && $currentHour < 18) {
        return 'Day Shift';
    } else {
        return 'Night Shift';
    }
}

$today = date('Y-m-d');
$lines = $database->select('cline', '*');
$selectedLine = 3;
// Auto-detect shift if not specified in URL
$selectedShift = $_GET['shift'] ?? getCurrentShift();
$queryRecordId = isset($_GET['record_id']) ? intval($_GET['record_id']) : null;

$prodRecord = null;
if ($queryRecordId) {
  $prodRecord = $database->get('cproduction_record', '*', ['record_id' => $queryRecordId]);
  if ($prodRecord) { $today = $prodRecord['production_date']; }
}
if (!$prodRecord) {
  $prodRecord = $database->get('cproduction_record', '*', [
    'production_date' => $today,
    'Cline_ID' => $selectedLine,
    'Shift' => $selectedShift,
    'ORDER' => ['created_at' => 'DESC']
  ]);
}
if (!$prodRecord) {
}

$recordId = $prodRecord['record_id'] ?? null;
$planTarget = $prodRecord ? intval($prodRecord['plan_target']) : 0;
$takttimeString = $prodRecord['takttime'] ?? '';

try {
  $now = new DateTime('now');
  $cutoff = null;
  if ($prodRecord) {
    $isNight = (stripos($selectedShift, 'night') !== false);
    if ($isNight) {
      $cutoff = new DateTime($today . ' 06:00:00');
      $cutoff->modify('+1 day');
    } else {
      $cutoff = new DateTime($today . ' 18:00:00');
    }
    if ($cutoff && $now >= $cutoff) {
      $prodRecord = null;
      $recordId = null;
      $planTarget = 0;
      $takttimeString = '';
      $breaks = [];
    }
  }
} catch (Exception $e) {  }

$totalPlan = (int)$planTarget;
$rawTotalResult = (int)($prodRecord['total_actual'] ?? 0);
// Use database value as primary source, fallback to sum of actuals if database is 0
$sumActuals = 0;
if ($prodRecord) {
  for ($i = 1; $i <= 5; $i++) {
    $sumActuals += (int)($prodRecord["actual{$i}"] ?? 0);
  }
}
$totalResult = ($rawTotalResult > 0) ? $rawTotalResult : $sumActuals;
$totalDifference = $totalResult - $totalPlan;
$totalReject = 0;
if (!empty($recordId)) {
  try {
    $rejRows = $database->select('cproduction_rejects', ['qty'], ['record_id' => $recordId]);
    if (is_array($rejRows)) {
      foreach ($rejRows as $r) { $totalReject += (int)($r['qty'] ?? 0); }
    }
  } catch (Exception $e) { $totalReject = 0; }
}

$breaks = [];
if ($recordId) {
  $breaks = $database->select('cproduction_breaks', '*', [
    'record_id' => $recordId,
    'production_date' => $prodRecord['production_date'],
    'ORDER' => ['break_number' => 'ASC']
  ]) ?? [];
}

$breakLabels = ['1ST','2ND','3RD','4TH','5TH'];

$loadedRecordInfo = $recordId ? ("rec #{$recordId}") : 'none';
?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MAS Monitoring</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="../../API/style.css">
  <!-- Style CSS -->
  <link rel="stylesheet" href="../../../node_modules/bootstrap/dist/css/bootstrap.min.css">
  <!-- Bootstrap Icons CSS -->
  <link rel="stylesheet" href="../../../node_modules/bootstrap-icons/font/bootstrap-icons.css">
  <!-- jQuery -->
  <script src="../../../node_modules/jquery/dist/jquery.min.js"></script>
  <!-- Bootstrap JS Bundle -->
  <script src="../../../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Chart.js -->
  <script src="../../../node_modules/chart.js/dist/chart.umd.js"></script>
  <style>
      :root {
        --card-radius: 10px;
        --card-border: #e9ecef;
        --card-shadow: 0 4px 12px rgba(0,0,0,0.06);
        --gap: 6px;
      }

      /* KPI strip styles (design only) */
      .kpi-strip {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
        margin-bottom: 6px;
      }
      .kpi-pill {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 6px 8px;
        border-radius: 999px;
        background: #f8f9fa;
        border: 1px solid #e9ecef;
        font-size: 0.85rem;
        line-height: 1;
      }
      .kpi-pill .label { color: #6c757d; font-weight: 600; }
      .kpi-pill .value { color: #212529; font-weight: 700; }

      /* Daily Operation split charts (design only) */
      .chart-grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; width: 100%; }
      .chart-box { background: #fff; border: 1px solid #e9ecef; border-radius: 6px; padding: 6px; display:flex; flex-direction:column; }
      .chart-title { font-size: 0.85rem; font-weight: 600; color:#6c757d; margin-bottom: 4px; text-align:center; }
      @media (max-width: 992px) { .chart-grid-3 { grid-template-columns: 1fr; } }

      /* Card styling */
      .card-custom {
        background: #fff;
        border: 1px solid var(--card-border);
        border-radius: var(--card-radius);
        box-shadow: var(--card-shadow);
        border: 2px solid #000;
      }

      .card-custom strong { font-weight: 600; }
      .card-custom .badge { opacity: 0.85; }

      #three-months-total {
        font-size: clamp(1.6rem, 3.2vw, 2.6rem);
        line-height: 1.1;
      }

      /* Chart containers */
      .card-custom .flex-grow-1 { min-height: 180px; }

      @media (max-width: 1400px) {
        .card-custom .flex-grow-1 { min-height: 160px; }
      }

      @media (max-width: 992px) {
        .card-custom .flex-grow-1 { min-height: 140px; }
      }

      @media (max-width: 576px) {
        .card-custom .flex-grow-1 { min-height: 120px; }
      }
      /* Layout improvements */
      .two-col-section { align-items: stretch; }
      .left-panel .card-custom { height: 100%; }
      .left-panel .table-responsive {
        /* Make the left table scroll within viewport on large screens */
        max-height: calc(100vh - 260px);
        overflow-y: auto;
      }
      .table-sticky thead th {
        position: sticky;
        top: 0;
        background: #fff;
        z-index: 2;
      }

      .group-card {
      border: 2px solid #000;
      display: flex;
    }
    .group-label {
      border-right: 2px solid #000;
      text-align: center;
      font-weight: bold;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      min-width: 100px;
    }
    .group-label .small-text {
      font-size: 1rem;
    }
    .group-label .big-letter {
      font-size: 3rem;
      color: #007bff; /* Bootstrap blue */
      line-height: 1;
    }
    .group-members {
      flex: 1;
      padding: 0.5rem;
    }
    .member-card {
      border: 1px solid #000;
      text-align: center;
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center; 
    }
    .member-card img {
      display: block;
      width: auto;          
      height: 80px;        
      margin: 0 auto;       
      border-bottom: 1px solid #000;
    }
    .member-role {
      font-weight: 500;
      padding: 0.25rem;
    }
    /* Group cards layout tweaks */
    .group-card { gap: 6px; margin-bottom: 8px; }
    .group-members .row > [class^="col-"] { padding-left: 6px; padding-right: 6px; display: flex; }
    .group-members .member-card { flex: 1 1 auto; display: flex; flex-direction: column; }
    .card-custom.group-wrapper { padding: 8px; display: grid; grid-template-rows: 1fr 1fr; gap: 8px; }
    .group-wrapper .group-card { height: 100%; }
    .member-card { justify-content: center; }
</style>
    </head>

  
    <body class="p-3">
    <!-- Hidden inputs to support read-only JS computations -->
    <input type="hidden" name="production_date" value="<?= htmlspecialchars($today) ?>">
    <input type="hidden" name="line_id" value="<?= htmlspecialchars($selectedLine) ?>">
    <input type="hidden" name="shift" value="<?= htmlspecialchars($selectedShift) ?>">
    <input type="hidden" name="record_id" id="recordId" value="<?= htmlspecialchars($recordId ?? '') ?>">
    <input type="hidden" id="plan_target" value="<?= intval($planTarget) ?>">
    <input type="hidden" id="takttime" value="<?= htmlspecialchars($takttimeString) ?>">
    <?php for ($i=1;$i<=5;$i++): ?>
      <input type="hidden" id="start_time_<?= $i ?>" value="<?= htmlspecialchars($prodRecord["Cstart_Time{$i}"] ?? '') ?>">
      <input type="hidden" id="end_time_<?= $i ?>" value="<?= htmlspecialchars($prodRecord["Cend_Time{$i}"] ?? '') ?>">
    <?php endfor; ?>

    
    <div class="row g-3">
      <!-- GRID FOR Line Info (Line / Shift / Date / Time) -->
      <div class="col-12 col-lg-2">
        <div class="card-custom h-100 px-3 py-2 d-flex flex-column">
          <!-- Header: title only -->
          <div class="d-flex align-items-center justify-content-between w-100 mb-2">
            <strong style="font-size:1rem;">Production Monitoring Dashboard</strong>
          </div>
          <!-- Row 1: Shift (left) and Date/Time (right) -->
          <div class="row g-2 align-items-center mb-1">
            <div class="col-6 d-flex align-items-center">
              <span class="badge bg-light text-dark d-flex align-items-center"><i class="bi bi-people me-1"></i><span id="shift-label"><?= htmlspecialchars($selectedShift) ?></span></span>
            </div>
            <div class="col-6 d-flex justify-content-end align-items-center gap-2">
              <span class="badge bg-light text-dark d-flex align-items-center"><i class="bi bi-calendar me-1"></i><span id="current-date"></span></span>
              <span class="badge bg-light text-dark d-flex align-items-center"><i class="bi bi-clock me-1"></i><span id="current-time"></span></span>
            </div>
          </div>
          <!-- Shift filter buttons -->
          <div class="d-flex justify-content-center mb-2">
            <div class="btn-group btn-group-sm" role="group" aria-label="Shift filter">
              <?php 
                $qsBase = [];
                if (!is_null($queryRecordId)) { $qsBase['record_id'] = (int)$queryRecordId; }
                $qsDay   = http_build_query(array_merge($qsBase, ['shift' => 'Day Shift']));
                $qsNight = http_build_query(array_merge($qsBase, ['shift' => 'Night Shift']));
              ?>
              <a href="?<?= htmlspecialchars($qsDay) ?>" class="btn btn-outline-primary <?= (stripos($selectedShift,'night') === false) ? 'active' : '' ?>">Day Shift</a>
              <a href="?<?= htmlspecialchars($qsNight) ?>" class="btn btn-outline-primary <?= (stripos($selectedShift,'night') !== false) ? 'active' : '' ?>">Night Shift</a>
            </div>
          </div>
          <script>
            (function(){
              try {
                var url = new URL(window.location.href);
                if (!url.searchParams.has('shift')) {
                  var now = new Date();
                  var h = now.getHours();
                  var detected = (h >= 6 && h < 18) ? 'Day Shift' : 'Night Shift';
                  url.searchParams.set('shift', detected);
                  window.location.replace(url.toString());
                }
              } catch(e) {  }
            })();
          </script>
          <script>
            (function(){
              try {
                function detectShiftByTime(d){
                  var h = d.getHours();
                  return (h >= 6 && h < 18) ? 'Day Shift' : 'Night Shift';
                }
                function nextBoundary(now){
                  var y = now.getFullYear(), m = now.getMonth(), day = now.getDate();
                  var sixAM = new Date(y, m, day, 6, 0, 0, 0);
                  var sixPM = new Date(y, m, day, 18, 0, 0, 0);
                  if (now < sixAM) return sixAM;
                  if (now < sixPM) return sixPM;
                  return new Date(y, m, day + 1, 6, 0, 0, 0);
                }
                function scheduleBoundaryRedirect(){
                  var now = new Date();
                  var nb = nextBoundary(now);
                  var delay = Math.max(1000, nb - now); 
                  if (window.__shift_boundary_timer) clearTimeout(window.__shift_boundary_timer);
                  window.__shift_boundary_timer = setTimeout(function(){
                    try {
                      var url = new URL(window.location.href);
                      var detected = detectShiftByTime(new Date());
                      var current = url.searchParams.get('shift') || '';
                      if (current !== detected) {
                        url.searchParams.set('shift', detected);
                        window.location.replace(url.toString());
                        return; 
                      }
                    } catch(e) {}
                    scheduleBoundaryRedirect();
                  }, delay);
                }
                if (window.__shift_poll_interval) clearInterval(window.__shift_poll_interval);
                window.__shift_poll_interval = setInterval(function(){
                  try {
                    var url = new URL(window.location.href);
                    var detected = detectShiftByTime(new Date());
                    var current = url.searchParams.get('shift') || '';
                    if (current && current !== detected) {
                      url.searchParams.set('shift', detected);
                      window.location.replace(url.toString());
                    }
                  } catch(e) {}
                }, 60000);
                scheduleBoundaryRedirect();
              } catch(e) {}
            })();
          </script>
          <!-- Row 2: Line centered -->
          <div class="w-100 text-center">
            <div class="fw-bold" style="font-size:6rem; line-height:2.5;">Line <?= htmlspecialchars($selectedLine) ?></div>
          </div>
        </div>
      </div>

    
      <!-- GRID FOR GROUP CARDS (A and B in one card) -->
      <div class="col-12 col-lg-2">
          <div class="card-custom group-wrapper h-100">
        <!-- GROUP A -->
        <div class="group-card">
          <div class="group-label">
            <span class="small-text">GROUP</span>
            <span class="big-letter">A</span>
          </div>
          <div class="group-members">
            <div class="row g-2">
              <div class="col-6">
                <div class="member-card">
                  <img id="groupA-leader" class="member-photo" data-group="A" data-role="leader"  alt="Line Leader A" title="Double-click to change photo; right-click to reset" style="cursor: pointer;">
                  <div class="member-role">Line Leader</div>
                </div>
              </div>
              <div class="col-6">
                <div class="member-card">
                  <img id="groupA-technician" class="member-photo" data-group="A" data-role="technician"  alt="Technician A" title="Double-click to change photo; right-click to reset" style="cursor: pointer;">
                  <div class="member-role">Technician</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- GROUP B -->
        <div class="group-card">
          <div class="group-label">
            <span class="small-text">GROUP</span>
            <span class="big-letter">B</span>
          </div>
          <div class="group-members">
            <div class="row g-2">
              <div class="col-6">
                <div class="member-card">
                  <img id="groupB-leader" class="member-photo" data-group="B" data-role="leader" src="s.png" alt="Line Leader B" title="Double-click to change photo; right-click to reset" style="cursor: pointer;">
                  <div class="member-role">Line Leader</div>
                </div>
              </div>
              <div class="col-6">
                <div class="member-card">
                  <img id="groupB-technician" class="member-photo" data-group="B" data-role="technician" src="s.png" alt="Technician B" title="Double-click to change photo; right-click to reset" style="cursor: pointer;">
                  <div class="member-role">Technician</div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
      <!-- GRID FOR ACHIEVEMENT RATE -->
    <div class="col-12 col-lg-2">
    <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2">
      <div class="d-flex align-items-center justify-content-between w-100 mb-1">
        <strong style="font-size:0.9rem;">ACHIEVEMENT RATE</strong>
        <div class="d-flex flex-wrap gap-1 ms-2">
          <span class="badge bg-danger px-1 py-1">95%↓</span>
          <span class="badge bg-warning text-dark px-1 py-1">96-99%</span>
          <span class="badge bg-success px-1 py-1">100%</span>
          <span class="badge bg-primary px-1 py-1">101%↑</span>
        </div>
      </div>
      <div class="d-flex justify-content-center w-100 mt-auto">
        <canvas id="achievementChart"></canvas>
      </div>
    </div>
    </div>

      <!-- GRID FOR PER BREAKTIME ACHIEVEMENT RATE -->
      <div class="col-12 col-lg-4">
     <div class="card-custom h-100 d-flex flex-column justify-content-between px-2 py-1" style="min-height: 360px;">
       <div class="d-flex align-items-center justify-content-between w-100 mb-1">
         <strong style="font-size:0.9rem;">Achievement Per Break</strong>
       </div>
       <div class="d-flex justify-content-center w-100 mt-auto" style="height: 100%; min-height: 320px;">
         <canvas id="achievementPerBreakChart" style="width: 100%; height: 100%;"></canvas>
       </div>
     </div>
   </div>

      <!-- GRID FOR LINE REJECTION RATE -->
    <div class="col-12 col-lg-2">
    <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2">
      <div class="d-flex align-items-center justify-content-between w-100 mb-1">
        <strong style="font-size:0.9rem;">LINE REJECTION RATE</strong>
        <div class="d-flex flex-wrap gap-1 ms-2">
          <span class="badge bg-danger px-1 py-1">95%↓</span>
          <span class="badge bg-warning text-dark px-1 py-1">96-99%</span>
          <span class="badge bg-success px-1 py-1">100%</span>
          <span class="badge bg-primary px-1 py-1">101%↑</span>
        </div>
      </div>
      <div class="d-flex justify-content-center w-100 mt-auto">
        <div class="w-100 d-flex flex-column align-items-center">
          <canvas id="lineRejectionChart" width="120" height="120"></canvas>
          <div class="small text-muted mt-1">Line Reject: <span id="lineRejectionValue">-</span></div>
        </div>
      </div>
    </div>
    </div>

    </div>

    <!-- Main content: Left = Drawing Numbers Data (full height), Right = all charts/metrics -->
    <div class="row g-3 mb-2 two-col-section">
    <div class="col-12 col-sm-6 col-lg-6">
    <div class="card-custom h-100 d-flex flex-column px-2 py-1">
        <div class="d-flex justify-content-between align-items-center mb-1">
            <strong style="font-size:0.9rem;">Data Analytics Board</strong>
        </div>
        <!-- Shift Totals KPI Strip -->
        <div class="row g-2 px-2 mb-1">
          <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm p-2 text-center">
              <div class="fs-3 text-muted" style="font-size:1rem;">Total Plan</div>
              <div class="fw-bold" id="kpi-total-plan" style="font-size:3rem;"><?= number_format($totalPlan) ?></div> 
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm p-2 text-center">
              <div class="fs-3 text-muted">Total Result</div>
              <div class="fw-bold" id="kpi-total-result" style="font-size:3rem;"><?= number_format($totalResult) ?></div>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm p-2 text-center">
              <div class="fs-3 text-muted">Total Difference</div>
              <div class="fw-bold <?= ($totalDifference<0?'text-danger':($totalDifference>0?'text-success':'')) ?>" id="kpi-total-difference" style="font-size:3rem;"><?= ($totalDifference===0?'-':number_format($totalDifference)) ?></div>
            </div>
          </div>
          <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm p-2 text-center">
              <div class="fs-3 text-muted">Total Reject</div>
              <div class="fw-bold text-danger" id="kpi-total-reject" style="font-size:3rem;"><?= number_format($totalReject) ?></div>
              <input type="hidden" id="total_result_accu" value="<?= $totalResult ?>">
              <input type="hidden" id="total_reject_accu" value="<?= $totalReject ?>">
            </div>
          </div>
        </div>
        <div class="table-responsive flex-grow-1">
            <?php if (!$prodRecord): ?>
              <div class="alert alert-warning m-2">
                No production record found for the selected criteria. Try selecting another date, or create a record in <code>MAS/line/line1.php</code>.
              </div>
            <?php endif; ?>
            <table class="table table-bordered text-center mb-0 analytics-table table-sticky">
                <tr>
                    <th colspan="2" rowspan="2" style="text-align: center; vertical-align: middle;">
                      Break
                    </th>
                    <th colspan="2" rowspan="">Time</th>
                    <th rowspan="2" style="text-align: center; vertical-align: middle;">
                      WORK HR
                    </th>                    
                    <th colspan="2">PLAN</th>
                    <th colspan="2">RESULT</th>
                    <th colspan="2">DIFF</th>
                    <th colspan="2">REJECT</th>
                    <th colspan="5"  style="text-align: center; vertical-align: middle;">REMARKS</th>
                </tr>
                <tr>
                    <th>Start</th>
                    <th>End</th>
                    <th>Output</th> 
                    <th>Accu</th>
                    <th>Output</th>
                    <th>Accu</th>
                    <th>Balanced</th>
                    <th>Accu</th>
                    <th>Qty</th>
                    <th>Accu</th>
                    <th>Classification</th>
                    <th>Reason</th>
                    <th>Countermeasure</th>
                </tr>
                      <tbody>
                      <?php
                        $hasSnapshots = is_array($breaks) && count($breaks) === 5;
                        $accuReject = 0;
                        for ($i=1; $i<=5; $i++):
                          $snap = $hasSnapshots ? $breaks[$i-1] : null;
                          $start = $snap['start_time'] ?? ($prodRecord["Cstart_Time{$i}"] ?? '');
                          $end   = $snap['end_time'] ?? ($prodRecord["Cend_Time{$i}"] ?? '');
                          $workSeconds = intval($snap['work_seconds'] ?? 0);
                          if (!$workSeconds && $start && $end) {
                            $st = strtotime($start); $en = strtotime($end); if ($en > $st) $workSeconds = $en - $st;
                          }
                          $workHourStr = $workSeconds ? (round($workSeconds/3600,2).' HR | '.number_format($workSeconds).' SEC') : '-';
                          $planOut = intval($snap['plan_output'] ?? 0);
                          $planAcc = intval($snap['plan_accu'] ?? 0);
                          $actOut  = intval($snap['actual_output'] ?? ($prodRecord["actual{$i}"] ?? 0));
                          $actAcc = intval($snap['actual_accu'] ?? 0);
                          if (!$actAcc) {
                            $sum=0; for($j=1;$j<= $i;$j++){ $sum += intval($prodRecord["actual{$j}"] ?? 0);} $actAcc = $sum;
                          }
                          $diffBal = ($snap && isset($snap['diff_balanced'])) ? intval($snap['diff_balanced']) : ($actOut - $planOut);
                          $diffAcc = ($snap && isset($snap['diff_accu'])) ? intval($snap['diff_accu']) : ($actAcc - $planAcc);
                          $rejQty  = intval($snap['reject_qty'] ?? 0);
                          $accuReject = intval($snap['reject_accu'] ?? ($accuReject + $rejQty));
                          $classif = $snap['classification'] ?? '';
                          $reason  = $snap['reason'] ?? '';
                          $cm      = $snap['countermeasure'] ?? '';
                      ?>
                      <tr>
                          <td colspan="2"><?= htmlspecialchars($breakLabels[$i-1]) ?></td>
                          <td><?= htmlspecialchars($start ?: '-') ?></td>
                          <td><?= htmlspecialchars($end ?: '-') ?></td>
                          <td><?= $workHourStr ?></td>
                          <td class="plan-output-cell"><?= $planOut ?></td>
                          <td class="plan-accu-cell"><?= $planAcc ?></td>
                          <td class="output-cell" data-break="<?= $i ?>"><div><?= $actOut ?></div></td>
                          <td class="actual-accu-cell"><?= $actAcc ?></td>
                          <td class="difference-cell"><?= ($diffBal===0?'-':$diffBal) ?></td>
                          <td class="diff-accu-cell"><?= ($diffAcc===0?'-':$diffAcc) ?></td>
                          <td class="reject-qty-cell"><?= $rejQty ?></td>
                          <td class="reject-accu-cell"><?= $accuReject ?></td>
                          <td><div class="small text-center remark-classification"><?= htmlspecialchars($classif) ?></div></td>
                          <td><div class="mt-1 small text-center remark-reason" ><?= htmlspecialchars($reason) ?></div></td>
                          <td><div class="mt-1 small text-center remark-countermeasure" ><?= htmlspecialchars($cm) ?></div></td>
                      </tr>
                      <?php endfor; ?>
                      </tbody>
                     
                      </table>
          <hr class="my-2">
          <div class="mt-1">
            <div class="d-flex justify-content-between align-items-center mb-1">
              <strong style="font-size:0.9rem;">Model Details</strong>
            </div>
            <div class="table-responsive">
              <?php
                $rawDrawingIds = (string)($prodRecord['Cdrawing_ID'] ?? '');
                $drawingIdArray = array_values(array_filter(array_map('trim', explode(',', $rawDrawingIds)), function($v){ return $v !== ''; }));
                $taktArray = [];
                $lenArray = [];
                $ttStr = trim((string)$takttimeString);
                if ($ttStr !== '') {
                  $parts = array_map('trim', explode(',', $ttStr));
                  foreach ($parts as $p) { if ($p !== '') $taktArray[] = $p; }
                }
                $lenStr = trim((string)($prodRecord['length'] ?? ''));
                if ($lenStr !== '') {
                  $parts = array_map('trim', explode(',', $lenStr));
                  foreach ($parts as $p) { if ($p !== '') $lenArray[] = $p; }
                }
                $maxModels = max(count($drawingIdArray), count($taktArray), count($lenArray));
              ?>
              <table class="table table-bordered text-center mb-0">
                <thead>
                  <tr>
                    <th style="width:8rem;">Model</th>
                    <th>Drawing Number</th>
                    <th>Takt Time</th>
                    <th>Length</th>
                  </tr>
                </thead>
                <tbody>
                  <?php if ($maxModels === 0): ?>
                    <tr>
                      <td colspan="4" class="text-center text-muted">No model details available</td>
                    </tr>
                  <?php else: ?>
                    <?php for ($i = 0; $i < $maxModels; $i++): ?>
                      <?php
                        $did = $drawingIdArray[$i] ?? '';
                        $drawLabel = '-';
                        if ($did !== '') {
                          try {
                            $row = $database->get('Cdrawingnumber', ['Cdrawingnum'], ['Cdrawing_ID' => $did]);
                            if ($row && isset($row['Cdrawingnum']) && $row['Cdrawingnum'] !== '') {
                              $drawLabel = $row['Cdrawingnum'];
                            } else { $drawLabel = $did; }
                          } catch (Exception $e) { $drawLabel = $did; }
                        }
                        $ttVal = $taktArray[$i] ?? '-';
                        $lnVal = $lenArray[$i] ?? '-';
                      ?>
                      <tr>
                        <td><?= 'Model '.($i+1) ?></td>
                        <td><?= htmlspecialchars($drawLabel) ?></td>
                        <td><?= htmlspecialchars($ttVal) ?></td>
                        <td><?= htmlspecialchars($lnVal) ?></td>
                      </tr>
                    <?php endfor; ?>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
    </div>
    </div>
    </div>
      
      <div class="col-12 col-lg-6">
        <div class="row g-3">
          <div class="col-12 col-lg-4">
            <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2 w-100">
              <div class="d-flex align-items-center justify-content-between w-100 mb-1">
                <strong style="font-size:1rem;">Past 3 Months Output</strong>
              </div>
              <div class="flex-grow-1" style="min-height: 220px;">
                <canvas id="output3MChart"></canvas>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-8">
            <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2 w-100">
              <div class="d-flex align-items-center justify-content-between w-100 mb-1">
                <strong style="font-size:1rem;">Daily Output (This Month)</strong>
                <span class="badge bg-secondary" id="daily-range-badge" style="font-size:0.7rem;">-</span>
              </div>
              <div class="flex-grow-1" style="min-height: 220px;">
                <canvas id="monthlyDailyOutputChart"></canvas>
              </div>
            </div>
          </div>
        </div>

        <!-- Row B: Operation Rates (4/8) -->
        <div class="row g-3 mt-1">
          <div class="col-12 col-lg-4">
            <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2 w-100">
              <div class="d-flex align-items-center justify-content-between w-100 mb-1">
                <strong style="font-size:1rem;">Operation Rate (Past 3 Months)</strong>
              </div>
              <div class="flex-grow-1" style="min-height: 220px;">
                <canvas id="opRate3MChart"></canvas>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-8">
            <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2 w-100">
              <div class="d-flex align-items-center justify-content-between w-100 mb-1">
                <strong style="font-size:1rem;">Operation Rate (This Months)</strong>
              </div>
              <div class="flex-grow-1" style="min-height: 220px;">
                <canvas id="opRateDailyChart"></canvas>
              </div>
            </div>
          </div>
        </div>

        <!-- Row C: Yield Rates (4/8) -->
        <div class="row g-3 mt-1">
          <div class="col-12 col-lg-4">
            <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2 w-100">
              <div class="d-flex align-items-center justify-content-between w-100 mb-1">
                <strong style="font-size:1rem;">Past 3 Months Yield Rate</strong>
                <span class="badge bg-secondary" id="oprate-daily-range" style="font-size:0.7rem;">-</span>
              </div>
              <div class="flex-grow-1" style="min-height: 220px;">
                <canvas id="yield3MChart"></canvas>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-8">
            <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2 w-100">
              <div class="d-flex align-items-center justify-content-between w-100 mb-1">
                <strong style="font-size:1rem;">Yield Rate (Daily, This Month)</strong>
                <span class="badge bg-secondary" id="yield-daily-range" style="font-size:0.7rem;">-</span>
              </div>
              <div class="flex-grow-1" style="min-height: 220px;">
                <canvas id="yieldDailyChart"></canvas>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
<script>window.READ_ONLY_VIEW = true;</script>
  <script src="../../JS/api.js"></script>
  <script src="../../JS/line1.js"></script>
  <script src="../../JS/lineview2.charts.js?v=20250920-1319"></script>
  <script src="../../JS/line1.view.js"></script>
  <script src="../../JS/realtime_view.js"></script>
  <script src="../../JS/group_photos.js"></script>

  <script>
    (function(){
      function updateClock(){
        const now = new Date();
        const dateStr = now.toLocaleDateString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
        const timeStr = now.toLocaleTimeString();
        const d = document.getElementById('current-date');
        const t = document.getElementById('current-time');
        if (d) d.textContent = dateStr;
        if (t) t.textContent = timeStr;
      }
      updateClock();
      setInterval(updateClock, 1000);
    })();
  </script>

  <?php
    $needsSnapshot = ($recordId && (!is_array($breaks) || count($breaks) !== 5));
    if ($needsSnapshot):
  ?>
  <script>
    (function(){
      try {
        $.post('../API/save_break_snapshot.php', { record_id: <?= json_encode((int)$recordId) ?> })
         .always(function(){
            setTimeout(function(){ location.reload(); }, 300);
         });
      } catch(e) { }
    })();
  </script>
  <?php endif; ?>

  <script>
    (function(){
      function detectShift(now){
        const h = now.getHours();
        return (h >= 6 && h < 18) ? 'Day Shift' : 'Night Shift';
      }
      function applyShift(){
        const now = new Date();
        const detected = detectShift(now);
        const shiftInput = document.querySelector('input[name="shift"]');
        const label = document.getElementById('shift-label');

        if (shiftInput && shiftInput.value) {
          if (label) label.textContent = shiftInput.value;
          return;
        }

       if (label) label.textContent = detected;
        if (shiftInput && shiftInput.value !== detected){
          shiftInput.value = detected;
          window.dispatchEvent(new Event('realtime_shift_changed'));
        }
      }
      applyShift();
      setInterval(applyShift, 60000);
    })();
  </script>

  </body>
  </html>
  <?php
  ?>
