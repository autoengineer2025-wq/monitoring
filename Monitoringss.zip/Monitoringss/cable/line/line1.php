<?php
include_once '../../database/init.php'; 


// Function to get current shift based on time
function getCurrentShift() {
    $currentHour = intval(date('H'));
    // Day Shift: 6am (06) to 6pm (18)
    // Night Shift: 6pm (18) to 6am (06)
    if ($currentHour >= 6 && $currentHour < 18) {
        return 'Day Shift';
    } else {
        return 'Night Shift';
    }
}

// Fetch production times
$prodTimes = $database->select("cproductiontime", "*");

// Fetch lines
$lines = $database->select("cline", "*");
$today = date('Y-m-d');
$selectedLine = $_GET['line'] ?? ($lines[0]['Cline_ID'] ?? '');
// Auto-detect shift if not specified in URL
$selectedShift = $_GET['shift'] ?? getCurrentShift();

// Fetch production records for today, selected line, and shift
$prodRecord = $database->get("cproduction_record", "*", [
    "production_date" => $today,
    "Cline_ID" => $selectedLine,
    "Shift" => $selectedShift,
    "ORDER" => ["created_at" => "DESC"]
]);

$planTarget = $prodRecord ? intval($prodRecord['plan_target']) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>MAS Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="../API/style.css">
<!-- Style CSS -->
<link rel="stylesheet" href="../../node_modules/bootstrap/dist/css/bootstrap.min.css">
<!-- Bootstrap Icons CSS -->
<link rel="stylesheet" href="../../node_modules/bootstrap-icons/font/bootstrap-icons.css">
<!-- jQuery -->
<script src="../../node_modules/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap JS Bundle -->
<script src="../../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- Chart.js -->
<script src="../../node_modules/chart.js/dist/chart.umd.js"></script>
<link rel="stylesheet" href="../API/style.css">
</head> 
<style>
h3 {
  font-size: 1.5rem;
}
.output-cell {
  cursor: pointer;
  transition: background-color 0.2s;
}
.output-cell:hover {
  background-color: #f8f9fa;
}
.output-cell.editable {
  background-color: #e3f2fd;
}
.analytics-table {
  font-size: 1.4rem;
}
.analytics-table th,
.analytics-table td {
  padding: 0.6rem 0.6rem; 
}
/* Fix Achievement chart height */
.achievement-chart-container {
  position: relative;
  width: 100%;
  height: 500px;
}
#achievementChart {
  width: 100% !important;
  height: 100% !important;
}
</style>
</head>

<body>
  <input type="hidden" 
         name="production_date" 
         value="<?= $today ?>">
  <input type="hidden" 
         name="line_id" 
         value="<?= htmlspecialchars($selectedLine) ?>">
  <input type="hidden" 
         name="shift" 
         value="<?= htmlspecialchars($selectedShift) ?>">
  <input type="hidden" 
         name="drawing_id" 
         value="<?= htmlspecialchars($prodRecord['Cdrawing_ID'] ?? '') ?>">
  <input type="hidden" 
         id="plan_target" 
         value="<?= $prodRecord ? intval($prodRecord['plan_target']) : 0 ?>">
  <input type="hidden" 
         id="takttime" 
         value="<?= $prodRecord ? htmlspecialchars($prodRecord['takttime'] ?? '') : '' ?>">
  <?php
  echo "<!-- DEBUG: Loading record ID: " . ($prodRecord['record_id'] ?? 'NULL') . " -->";
  echo "<!-- DEBUG: Shift: " . htmlspecialchars($selectedShift) . " -->";
  echo "<!-- DEBUG: Production Date: " . $today . " -->";
  ?>
  <?php for ($i = 1; $i <= 5; $i++): ?>
  <input type="hidden" 
         id="start_time_<?= $i ?>" 
         value="<?= $prodRecord ? htmlspecialchars($prodRecord["Cstart_Time$i"] ?? '') : '' ?>">
  <input type="hidden" 
         id="end_time_<?= $i ?>" 
         value="<?= $prodRecord ? htmlspecialchars($prodRecord["Cend_Time$i"] ?? '') : '' ?>">
  <?php
  if ($prodRecord) {
      echo "<!-- DEBUG: Break $i: " . htmlspecialchars($prodRecord["Cstart_Time$i"] ?? 'NULL') . " - " . htmlspecialchars($prodRecord["Cend_Time$i"] ?? 'NULL') . " -->";
  }
  ?>
  <?php endfor; ?>


  <div class="container-fluid p-4">
  <div class="d-flex justify-content-between align-items-center mb-4">
  <h4>MAS Dashboard</h4>
  <div class="d-flex align-items-center">
    <button type="button" 
            class="btn btn-primary" 
            onclick="window.location.href='line.php'">
            Reset
    </button>
  </div>
  </div>
  <div class="row mb-3">
  <div class="col-md-3 d-flex align-items-center">
  <span class="fw-bold me-2"><h3 style="margin: 0; display: inline;">Line Number:</h3></span>
  <span><h3 class="fw-bold me-2" style="margin: 0; display: inline;"><?= htmlspecialchars($selectedLine) ?></h3></span>
  </div>
  <div class="col-md-3 d-flex align-items-center">
    <span class="fw-bold me-2"><h3 style="margin: 0; display: inline;">Shift:</h3></span>
    <span><h3 style="margin: 0; display: inline;"><?= htmlspecialchars($selectedShift) ?></h3></span>  
  </div>
  <div class="col-md-3 d-flex align-items-center">
    <span class="fw-bold me-2"><i class="bi bi-calendar"></i></span>
    <span><h3 style="margin: 0; display: inline;" id="current-date"></h3></span>  
  </div>
  <div class="col-md-3 d-flex align-items-center justify-content-md-end">
  <span class="me-3"><i class="bi bi-clock"></i> <h3 style="margin: 0; display: inline;" id="current-time"></h3></span>
  </div>
  </div>

  <!-- Takttime and Drawing Number Row -->
  <div class="row mb-3">
  <div class="col-md-3 d-flex align-items-center">
    <span class="fw-bold me-2"><h3 style="margin: 0; display: inline;">Takttime:</h3></span>
    <span><h3 style="margin: 0; display: inline;"><?= htmlspecialchars($prodRecord ? $prodRecord['takttime'] ?? '-' : '-') ?></h3></span>  
  </div>
  <div class="col-md-3 d-flex align-items-center">
    <span class="fw-bold me-2"><h3 style="margin: 0; display: inline;">Drawing Number:</h3></span>
    <span><h3 style="margin: 0; display: inline;">
    <?php
      if ($prodRecord && !empty($prodRecord['Cdrawing_ID'])) {
        $drawingIds = array_map('trim', explode(',', $prodRecord['Cdrawing_ID']));
        $drawingNumbers = [];
        foreach ($drawingIds as $drawingId) {
          if (!empty($drawingId)) {
            $drawingRecord = $database->get('cdrawingnumber', 'cdrawingnum', ['Cdrawing_ID' => $drawingId]);
            if ($drawingRecord) {
              $drawingNumbers[] = $drawingRecord;
            }
          }
        }
        echo htmlspecialchars(implode(', ', $drawingNumbers) ?: '-');
      } else {
        echo '-';
      }
    ?>
    </h3></span>  
  </div>
  </div>


  <div class="row g-3 mb-3 justify-content-center">
  <div class="col-6 col-md-3">
  <div class="card-custom text-center h-100">
  <div class="card-header-small d-flex justify-content-between align-items-center"><h3 style="margin: 0;">PLAN</h3></div>
  <div class="card-value text-primary"><?= $planTarget ?></div>
</div>
  </div>
  <div class="col-6 col-md-3">
  <div class="card-custom text-center h-100">
  <div class="card-header-small d-flex justify-content-between align-items-center"><h3 style="margin: 0;">TARGET</h3></div>
  <div class="card-value text-success" id="real-time-target"><?= $prodRecord ? intval($prodRecord['target']) : 0 ?></div>
  </div>  
  </div>
  <div class="col-6 col-md-3">
  <div class="card-custom text-center h-100">
  <div class="card-title d-flex justify-content-between align-items-center">
  <span><h3 style="margin: 0;">ACTUAL</h3></span>
  </div>
  <div class="card-value text-dark" id="total-actual"><?= $prodRecord ? intval($prodRecord['total_actual']) : 0 ?></div>
  </div>
  </div>
  <div class="col-6 col-md-3">
  <div class="card-custom text-center h-100">
  <div class="card-header-small d-flex justify-content-between align-items-center"><h3 style="margin: 0;">DIFFERENCE</h3></div>
  <div class="card-value text-danger" id="real-time-difference"><?= $prodRecord ? (intval($prodRecord['total_actual']) - intval($prodRecord['target'])) : 0 ?></div>
  </div>
  </div>
  </div>

  <!-- 2nd Row: Achievement Rate, Past 3 Months Output, Data Analytics Board -->
<div class="row g-2 mb-2">
  <!-- Achievement Rate Card -->
  <div class="col-12 col-sm-6 col-md-3">
  <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2">
  <div class="d-flex align-items-center justify-content-between w-100 mb-1">
  <h3 style="margin: 0;">ACHIEVEMENT RATE</h3>
  <div class="d-flex flex-wrap gap-1 ms-2">
  <span class="badge bg-danger px-2 py-1">95%↓</span>
  <span class="badge bg-warning text-dark px-2 py-1">96-99%</span>
  <span class="badge bg-success px-2 py-1">100%</span>
          <span class="badge bg-primary px-2 py-1">101%↑</span>
        </div>
      </div>
      <div class="d-flex justify-content-center w-100 mt-auto">
        <div class="achievement-chart-container w-100">
          <canvas id="achievementChart"></canvas>
        </div>
      </div>
    </div>
  </div>

   <!-- DATA ANALYTICS BOARD -->
   <div class="col-12 col-sm-6 col-lg-9">
    <div class="card-custom h-100 d-flex flex-column px-2 py-1">
        <div class="d-flex justify-content-between align-items-center mb-1">
            <h3 style="margin: 0;">Data Analytics Board</h3>
        </div>
        <div class="table-responsive flex-grow-1">
          
        <?php
        function computeWorkingHours($start, $end, $takttime) {
            if (!$start || !$end || !$takttime) return '-';
            $start_ts = strtotime($start);
            $end_ts = strtotime($end);
            if ($end_ts <= $start_ts) return '-';
            $total_hours = ($end_ts - $start_ts) / 3600;
            $result = ($total_hours * 3600) / $takttime; 
            return round($result, 2);
        }

         $takttime = 0;
         $takttimeString = $prodRecord['takttime'] ?? '';
         $modelCount = 1; 
         
         if (strpos($takttimeString, ',') !== false) {
             $takttimeArray = array_map('trim', explode(',', $takttimeString));
             $takttime = floatval($takttimeArray[0] ?? 0);
             $modelCount = count($takttimeArray);
         } else {
             $takttime = floatval($takttimeString);
         }

        $shifts = ["1ST", "2ND", "3RD", "4TH", "5TH"];
        ?>
            <table class="table table-bordered text-center mb-0 analytics-table">
                <tr>
                    <th colspan="2" rowspan="2" style="text-align: center; vertical-align: middle;">
                      Break
                    </th>
                    <th colspan="2" rowspan="">Time</th>
                    <th rowspan="2" style="text-align: center; vertical-align: middle;">
                      WORK HR
                    </th>                    
                    <th colspan="2">PLAN</th>
                    <th colspan="2">RESULT</th>
                    <th colspan="2">DIFF</th>
                    <th colspan="2">REJECT</th>
                    <th colspan="5"  style="text-align: center; vertical-align: middle;">REMARKS</th>
                </tr>
                <tr>
                    <th>Start</th>
                    <th>End</th>
                    <th>Output</th> 
                    <th>Accu</th>
                    <th>Output</th>
                    <th>Accu</th>
                    <th>Balanced</th>
                    <th>Accu</th>
                    <th>Qty</th>
                    <th>Accu</th>
                    <th>Classification</th>
                    <th>Reason</th>
                    <th>Countermeasure</th>
                </tr>
                      <tbody>
                      <?php
                      // Load saved remarks for persistence across refresh
                      $remarksByBreak = [];
                      try {
                          $remarksRows = $database->select('cproduction_remarks', '*', [
                              'Cline_ID' => $selectedLine,
                              'Shift' => $selectedShift,
                              'production_date' => $today
                          ]);
                          foreach ($remarksRows as $r) {
                              $bn = (int)($r['break_number'] ?? 0);
                              if ($bn >= 1 && $bn <= 5) { $remarksByBreak[$bn] = $r; }
                          }
                      } catch (Exception $e) {
                          $remarksByBreak = [];
                      }
                      ?>
                      <?php
                      $qty = isset($prodRecord['qty']) ? intval($prodRecord['qty']) : 0;

                      $planTarget = isset($prodRecord['plan_target']) ? intval($prodRecord['plan_target']) : 0;

                         // `Cdrawing_ID` may be a comma-separated list when multiple models
                         $rawTopDrawingIds = $prodRecord['Cdrawing_ID'] ?? '';
                         $drawingIdArrayTop = array_values(array_filter(array_map('trim', explode(',', $rawTopDrawingIds)), function($v){ return $v !== ''; }));
                         $drawingDetails = [];
                         foreach ($drawingIdArrayTop as $did) {
                           try {
                             $row = $database->get('cdrawingnumber', '*', ['Cdrawing_ID' => $did]);
                             if ($row) $drawingDetails[] = $row;
                           } catch (Exception $e) {
                             // ignore individual lookup failures
                           }
                         }
                         $modelQty = (!empty($drawingDetails) && isset($drawingDetails[0]['qty'])) ? intval($drawingDetails[0]['qty']) : 1;
                       
                       $takttimeString = $prodRecord['takttime'] ?? '';
                       if (strpos($takttimeString, ',') !== false) {
                           $takttimeArray = array_map('trim', explode(',', $takttimeString));
                           $takttime = floatval($takttimeArray[0] ?? 0);
                       } else {
                           $takttime = floatval($takttimeString);
                       }

                      $takttimeArray = [];
                      if (!empty($takttimeString) && strpos($takttimeString, ',') !== false) {
                          $takttimeArray = array_values(array_filter(array_map(function($v){
                              $f = (float)trim($v);
                              return $f > 0 ? $f : null;
                          }, explode(',', $takttimeString))));
                      } elseif (!empty($takttimeString)) {
                          $single = (float)$takttimeString;
                          if ($single > 0) { $takttimeArray = [$single]; }
                      }

                      $modelPlanTotals = [];
                      $modelQtyPerPress = [];
                      if (!empty($prodRecord['record_id'])) {
                          try {
                              $progressRows = $database->select('cproduction_model_progress', '*', [
                                  'record_id' => $prodRecord['record_id'],
                                  'ORDER' => ['model_index' => 'ASC']
                              ]);
                              foreach ($progressRows as $row) {
                                  $modelPlanTotals[] = (int)($row['model_plan_total'] ?? 0);
                                  $modelQtyPerPress[] = max(1, (int)($row['model_qty_per_press'] ?? 1));
                              }
                          } catch (Exception $e) {
                              $modelPlanTotals = [];
                              $modelQtyPerPress = [];
                          }
                      }

                      $modelCount = max(count($takttimeArray), count($modelPlanTotals));
                      if ($modelCount === 0) {
                          $planOutputs = [];
                          $remainingPlan = $planTarget;
                          foreach ($shifts as $i => $label) {
                              $start = $prodRecord["Cstart_Time".($i+1)] ?? '';
                              $end = $prodRecord["Cend_Time".($i+1)] ?? '';
                              $output = 0;
                              if ($start && $end && $takttime > 0) {
                                  $start_ts = strtotime($start);
                                  $end_ts = strtotime($end);
                                  $seconds = max(0, $end_ts - $start_ts);
                                  $possibleOutput = $seconds > 0 ? floor($seconds / $takttime) : 0;
                                  $output = min($possibleOutput, $remainingPlan);
                                  $remainingPlan -= $output;
                              }
                              $planOutputs[$i] = $output;
                          }
                      } else {
                          for ($k = 0; $k < $modelCount; $k++) {
                              if (!isset($takttimeArray[$k]) || $takttimeArray[$k] <= 0) {
                                  $takttimeArray[$k] = PHP_FLOAT_MAX;
                              }
                              if (!isset($modelPlanTotals[$k])) {
                                  $modelPlanTotals[$k] = null;
                              }
                              if (!isset($modelQtyPerPress[$k]) || $modelQtyPerPress[$k] <= 0) {
                                  $modelQtyPerPress[$k] = 1;
                              }
                          }

                          $remainingPerModel = $modelPlanTotals;
                          $remainingTotalPlan = (int)$planTarget;

                          $planOutputs = [];
                          $planOutputsByModel = [];

                          foreach ($shifts as $i => $label) {
                              $start = $prodRecord["Cstart_Time".($i+1)] ?? '';
                              $end   = $prodRecord["Cend_Time".($i+1)] ?? '';
                              $breakTotal = 0;
                              $breakByModel = array_fill(0, $modelCount, 0);

                              if ($start && $end) {
                                  $start_ts = strtotime($start);
                                  $end_ts   = strtotime($end);
                                  $seconds  = max(0, $end_ts - $start_ts);

                                  if ($seconds > 0 && $remainingTotalPlan > 0) {
                                      $secondsLeft = $seconds;
                                      for ($m = 0; $m < $modelCount && $secondsLeft > 0 && $remainingTotalPlan > 0; $m++) {
                                          $tt = $takttimeArray[$m];
                                          if (!($tt > 0 && $tt < PHP_FLOAT_MAX)) { continue; }
                                          $modelRemain = $remainingPerModel[$m];
                                          if ($modelRemain === null) { $modelRemain = PHP_INT_MAX; }
                                          $maxByTime = (int)floor($secondsLeft / $tt);
                                          if ($maxByTime <= 0) { break; }
                                          $allocUnits = min($maxByTime, (int)$modelRemain, (int)$remainingTotalPlan);
                                          if ($allocUnits <= 0) { continue; }
                                          $breakByModel[$m] += $allocUnits;
                                          $breakTotal += $allocUnits;
                                          $secondsLeft -= $allocUnits * $tt;
                                          if ($remainingPerModel[$m] !== null) {
                                              $remainingPerModel[$m] = max(0, (int)$remainingPerModel[$m] - $allocUnits);
                                          }
                                          $remainingTotalPlan = max(0, (int)$remainingTotalPlan - $allocUnits);
                                      }
                                  }
                              }

                              $planOutputs[$i] = (int)$breakTotal;
                              $planOutputsByModel[$i] = $breakByModel;
                          }
                      }

                       $rawDrawingIds = $prodRecord['Cdrawing_ID'] ?? '';
                      $drawingIdArray = array_values(array_filter(array_map('trim', explode(',', $rawDrawingIds)), function($v){ return $v !== ''; }));
                      $drawingQtyPerModel = [];
                      foreach ($drawingIdArray as $did) {
                          $qtyVal = 1;
                          try {
                              $row = $database->get('cdrawingnumber', ['qty'], ['Cdrawing_ID' => $did]);
                              if (is_array($row) && array_key_exists('qty', $row)) {
                                  $qtyVal = max(1, (int)$row['qty']);
                              }
                          } catch (Exception $e) {
                              $qtyVal = 1;
                          }
                          $drawingQtyPerModel[] = $qtyVal;
                      }

                      // Load manual rejects from table for this record
                      $rejectsByBreak = [];
                      try {
                          if (!empty($prodRecord['record_id'])) {
                              $rejRows = $database->select('cproduction_rejects', '*', [
                                  'record_id' => $prodRecord['record_id']
                              ]);
                              foreach ($rejRows as $rj) {
                                  $bn = (int)($rj['break_number'] ?? 0);
                                  if ($bn >= 1 && $bn <= 5) { $rejectsByBreak[$bn] = (int)($rj['qty'] ?? 0); }
                              }
                          }
                      } catch (Exception $e) { $rejectsByBreak = []; }

                      $accuPlan = 0;
                      $accuReject = 0; // running total for rejects
                      foreach ($shifts as $i => $label):
                          $start = $prodRecord["Cstart_Time".($i+1)] ?? '';
                          $end = $prodRecord["Cend_Time".($i+1)] ?? '';

                          $workHour = '-';
                          $workSec = '-';
                          if ($start && $end) {
                              $start_ts = strtotime($start);
                              $end_ts = strtotime($end);
                              if ($end_ts > $start_ts) {
                                  $seconds = $end_ts - $start_ts;
                                  $hours = round($seconds / 3600, 2);
                                  $workHour = "{$hours} HR";
                                  $workSec = number_format($seconds) . " SEC";
                              }
                          }

                          $accuPlan += $planOutputs[$i];
                          
                          $actualOutput = $prodRecord["actual".($i+1)] ?? 0;
                          
                          $accuActual = 0;
                          for ($j = 1; $j <= $i+1; $j++) {
                              $accuActual += intval($prodRecord["actual{$j}"] ?? 0);
                          }
                          
                          // Difference per break and accumulated (Accu = cumulative result - cumulative plan)
                          $diffBalanced = (int)$actualOutput - (int)$planOutputs[$i];
                          $diffAccu = (int)$accuActual - (int)$accuPlan;

                          // Reject qty: manual input only (from cproduction_rejects)
                          $rejectQty = (int)($rejectsByBreak[$i+1] ?? 0);
                          $accuReject += $rejectQty;
                      ?>
                      <tr>
                          <td colspan="2"><?= htmlspecialchars($label) ?></td>
                          <td><?= htmlspecialchars($start ?: '-') ?></td>
                          <td><?= htmlspecialchars($end ?: '-') ?></td>
                          <td><?= $workHour ?> | <?= $workSec ?></td>
                          <td class="plan-output-cell"><?= $planOutputs[$i] ?></td>
                          <td class="plan-accu-cell"><?= $accuPlan ?></td>
                          <?php
                            // Determine per-press increment for this break. Default to 1.
                            $increment = 1;
                            $breakByModel = $planOutputsByModel[$i] ?? [];
                            $currentModelIdx = null;
                            if (!empty($breakByModel)) {
                                $cum = 0;
                                for ($mi = 0; $mi < count($breakByModel); $mi++) {
                                    $cum += (int)$breakByModel[$mi];
                                    if ((int)$actualOutput < $cum) { $currentModelIdx = $mi; break; }
                                }
                            }
                            if ($currentModelIdx !== null) {
                                $increment = $drawingQtyPerModel[$currentModelIdx] ?? ($modelQtyPerPress[$currentModelIdx] ?? 1);
                            } elseif (!empty($drawingQtyPerModel) && count($drawingQtyPerModel) === 1) {
                                $increment = $drawingQtyPerModel[0] ?? 1;
                            } elseif (!empty($modelQtyPerPress) && count($modelQtyPerPress) === 1) {
                                $increment = $modelQtyPerPress[0] ?? 1;
                            }
                          ?>
                          <td class="output-cell" data-break="<?= $i+1 ?>" data-record="<?= $prodRecord['record_id'] ?? '' ?>" data-increment="<?= $increment ?>" style="cursor: pointer;">
                            <div><?= $prodRecord["actual".($i+1)] ?? 0 ?></div>
                            <?php 
                              $breakByModel = $planOutputsByModel[$i] ?? [];
                              $currentModelIdx = null;
                              if (!empty($breakByModel)) {
                                  $cum = 0;
                                  for ($mi = 0; $mi < count($breakByModel); $mi++) {
                                      $cum += (int)$breakByModel[$mi];
                                      if ((int)$actualOutput < $cum) { $currentModelIdx = $mi; break; }
                                  }
                              }
                              $hint = '';
                              if ($currentModelIdx !== null) {
                                  $curDrawing = $drawingIdArray[$currentModelIdx] ?? '';
                                  $curQty = $drawingQtyPerModel[$currentModelIdx] ?? 1;
                                  $label = $curDrawing ?: ('Model '.($currentModelIdx+1));
                                  $hint = $label.' qty '.$curQty;
                              } elseif (is_array($breakByModel) && array_sum($breakByModel) > 0 && (int)$actualOutput >= (int)$planOutputs[$i]) {
                                  $hint = 'Break slice complete';
                              }
                              if (!empty($hint)):
                            ?>
                            <?php endif; ?>
                          </td>
                          <td class="actual-accu-cell"><?= $accuActual ?></td>
                          <td class="difference-cell"><?= ($diffBalanced === 0 ? '-' : $diffBalanced) ?></td>
                          <td class="diff-accu-cell"><?= ($diffAccu === 0 ? '-' : $diffAccu) ?></td>
                          <td class="reject-qty-cell">
                            <input type="number" min="0" class="form-control form-control-sm reject-input"
                                   style="max-width:90px;"
                                   data-break="<?= $i+1 ?>"
                                   data-record="<?= htmlspecialchars($prodRecord['record_id'] ?? '') ?>"
                                   value="<?= $rejectQty ?>">
                          </td>
                          <td class="reject-accu-cell" data-break="<?= $i+1 ?>"><?= $accuReject ?></td>
                          <?php $savedRemark = $remarksByBreak[$i+1] ?? null; ?>
                          <td>
                            <div class="d-flex align-items-center justify-content-center">
                              <select class="form-select form-select-sm w-auto remark-classification-select" data-break="<?= $i+1 ?>">
                                <option value="">Select classification</option>
                                <?php
                                  $classes = [
                                    'Parts problem',
                                    'Machine problem',
                                    'Change model',
                                    'Lack of man power'
                                  ];
                                  foreach ($classes as $cls) {
                                    $sel = ($savedRemark && ($savedRemark['classification'] ?? '') === $cls) ? 'selected' : '';
                                    echo '<option value="'.htmlspecialchars($cls).'" '.$sel.'>'.htmlspecialchars($cls).'</option>';
                                  }
                                ?>
                              </select>
                            </div>
                          </td>
                          <td>
                            <div class="mt-1 small text-center remark-reason" data-break="<?= $i+1 ?>"><?= htmlspecialchars($savedRemark['reason'] ?? '') ?></div>
                          </td>
                          <td>
                            <div class="mt-1 small text-center remark-countermeasure" data-break="<?= $i+1 ?>"><?= htmlspecialchars($savedRemark['countermeasure'] ?? '') ?></div>
                          </td>
                      </tr>
                      <?php endforeach; ?>
                      </tbody>
                      </table>
    </div>
    </div>
</div>
</div>
</div>

<!-- Remarks Modal -->  
<div class="modal" id="remarksModal" tabindex="-1" aria-labelledby="remarksModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header py-2">
        <h6 class="modal-title" id="remarksModalLabel">Please specify reason and countermeasure</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="remarksBreak" value="">
        <input type="hidden" id="remarksClassification" value="">
        <div class="mb-2">
          <label class="form-label mb-1">Classification</label>
          <input type="text" class="form-control form-control-sm" id="remarksClassificationView" readonly>
        </div>
        <div class="mb-2">
          <label class="form-label mb-1">Reason</label>
          <textarea class="form-control form-control-sm" id="remarksReason" rows="3" placeholder="Enter specific reason..."></textarea>
        </div>
        <div class="mb-0">
          <label class="form-label mb-1">Countermeasure</label>
          <textarea class="form-control form-control-sm" id="remarksCountermeasure" rows="3" placeholder="Enter countermeasure..."></textarea>
        </div>
      </div>
      <div class="modal-footer py-2">
        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-sm" id="saveRemarksBtn">Save</button>
      </div>
    </div>
  </div>
 </div>

<!-- Bootstrap Bundle -->
<script src="../JS/api.js"></script>
<script src="../JS/line1.js"></script>
<script src="../JS/line1.view.js"></script>

<script>
  (function(){
    function updateClock(){
      const now = new Date();
      const dateStr = now.toLocaleDateString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
      const timeStr = now.toLocaleTimeString();
      const d = document.getElementById('current-date');
      const t = document.getElementById('current-time');
      if (d) d.textContent = dateStr;
      if (t) t.textContent = timeStr;
    }
    updateClock();
    setInterval(updateClock, 1000);
  })();
  </script>

</body>
</html>
<?php
?>








