<?php
require_once __DIR__ . '/database/init.php';

echo "=== Dates with data in FEEDER ===\n";
$result = $database->select('fproduction_breaks', ['production_date'], [
    'GROUP' => 'production_date',
    'ORDER' => ['production_date' => 'DESC'],
    'LIMIT' => 10
]);
if ($result) {
    foreach ($result as $row) {
        echo $row['production_date'] . "\n";
    }
} else {
    echo "No records found\n";
}

echo "\n=== Dates with data in CABLE ===\n";
$result = $database->select('cproduction_breaks', ['production_date'], [
    'GROUP' => 'production_date',
    'ORDER' => ['production_date' => 'DESC'],
    'LIMIT' => 10
]);
if ($result) {
    foreach ($result as $row) {
        echo $row['production_date'] . "\n";
    }
} else {
    echo "No records found\n";
}

echo "\n=== Sample from latest date ===\n";
$latest = $database->get('fproduction_breaks', ['production_date'], ['ORDER' => ['production_date' => 'DESC']]);
if ($latest) {
    $date = $latest['production_date'];
    echo "Latest date: $date\n";
    $records = $database->select('fproduction_breaks', ['Fline_ID', 'Shift', 'plan_accu', 'actual_accu'], [
        'production_date' => $date,
        'LIMIT' => 5
    ]);
    if ($records) {
        foreach ($records as $rec) {
            echo "  Line {$rec['Fline_ID']}, Shift: {$rec['Shift']}, Plan: {$rec['plan_accu']}, Actual: {$rec['actual_accu']}\n";
        }
    }
}
?>
