<?php
include 'database/init.php';

try {
    echo "Fixing record_id column to add AUTO_INCREMENT...\n";
    
    // First, make sure there's no record with record_id = 0 that could cause conflicts
    $database->delete('cproduction_record', ['record_id' => 0]);
    
    // Alter the table to add AUTO_INCREMENT to record_id
    $result = $database->query("ALTER TABLE cproduction_record MODIFY COLUMN record_id INT(11) NOT NULL AUTO_INCREMENT");
    
    if ($result) {
        echo "Successfully added AUTO_INCREMENT to record_id column.\n";
        
        // Reset the auto-increment counter to the next available value
        $maxId = $database->max('cproduction_record', 'record_id');
        if ($maxId) {
            $database->query("ALTER TABLE cproduction_record AUTO_INCREMENT = " . ($maxId + 1));
            echo "Auto-increment counter set to: " . ($maxId + 1) . "\n";
        }
        
        // Verify the change
        $columns = $database->query("SHOW COLUMNS FROM cproduction_record WHERE Field = 'record_id'");
        foreach ($columns as $column) {
            echo "Updated record_id column: " . $column['Field'] . " - " . $column['Type'] . " - " . $column['Extra'] . "\n";
        }
        
    } else {
        echo "Failed to modify column. Error: " . json_encode($database->error) . "\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
