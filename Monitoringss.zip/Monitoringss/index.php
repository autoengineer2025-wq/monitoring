<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="node_modules/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/central.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .btn-group5 {
            display: inline-block;
            margin-left: 10px;
        }
        .btn-group5 .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            font-weight: 600;
            padding: 10px 20px;
            border-radius: 5px;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .btn-group5 .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
            color: white;
        }
        #rankingChart {
            min-height: 600px;
            padding: 20px;
        }
        .modal-dialog {
            max-width: 90%;
        }
    </style>
</head>
<body>
<header class="topbar">
    <div class="topbar-content">
        <h1 class="center-text">CENTRAL OUTPUT MONITORING | v.0.0.2</h1>
        <div class="nav-right">
            <div class="dropdown">
                <button class="dropbtn"><i class="bi bi-gear"></i></button>
                <div class="dropdown-content">
                    <a href="linestatus.php">Line Status</a>
                    <a href="#">About</a>
                </div>
            </div>
        </div>
    </div>
</header>

<div class="button-container">
    <div class="btn-group1" role="group" aria-label="Basic example">
        <button type="button" class="btn">95%</button>
    </div>
    <div class="btn-group2" role="group" aria-label="Basic example">
        <button type="button" class="btn">96% - 99%</button>
    </div>
    <div class="btn-group3" role="group" aria-label="Basic example">
        <button type="button" class="btn">100%</button>
    </div>
    <div class="btn-group4" role="group" aria-label="Basic example">
        <button type="button" class="btn">100% above</button>
    </div>
    <div class="btn-group5" role="group" aria-label="Ranking">
        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#rankingModal"><i class="bi bi-bar-chart"></i> TOP PERFORMERS</button>
    </div>
</div>

<!-- Ranking Modal -->
<div class="modal fade" id="rankingModal" tabindex="-1" aria-labelledby="rankingModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none;">
                <h5 class="modal-title" id="rankingModalLabel"><i class="bi bi-trophy"></i> TOP PERFORMERS - Total Output (Real-time)</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <canvas id="rankingChart"></canvas>
            </div>
        </div>
    </div>
</div>

<section class="cards-container container-fluid" id="cards-container">
    <!-- Rendered dynamically -->
    <div class="row g-3" id="cards-root"></div>
    <div class="mt-2 text-end">
        <small class="text-muted" ></small>
    </div>
</section>

<section class="table-container">
    <table>
        <thead>
            <tr>
                <th>Line No</th>
                <th>Target</th>
                <th>Actual</th>
                <th>Difference</th>
                <th>Achievement Rate</th>
                <th>Reject Qty</th>
                <th>Reject PPM</th>

            </tr>
        </thead>
        <tbody id="data-table">
        </tbody>
    </table>
    <div class="footer">
        <p>Auto-Department MinebeaMitsumi Philippines</p>
    </div>
<script>
// Global fmt function to avoid scoping issues
function fmt(n){
  const v = Number(n || 0);
  if (Number.isNaN(v)) return '0';
  return v.toLocaleString();
}

(function(){
  const tbody = document.getElementById('data-table');
  const sectionOrder = ['CABLE','FEEDER','USB'];
  const shifts = ['Day', 'Night'];
  let currentShift = 'All';
  let lastJson = null;
  let rankingChart = null;

  // Function to determine current shift based on time
  function getCurrentShiftByTime() {
    const now = new Date();
    const hour = now.getHours();
    
    // Day Shift: 6am (06) to 6pm (18)
    // Night Shift: 6pm (18) to 6am (06)
    if (hour >= 6 && hour < 18) {
      return 'Day';
    } else {
      return 'Night';
    }
  }

  function getSortedLineKeys(sectionData){
    const keys = Object.keys(sectionData || {});
    keys.sort((a,b) => {
      const na = parseInt(String(a).replace(/\D/g,'')) || 0;
      const nb = parseInt(String(b).replace(/\D/g,'')) || 0;
      return na - nb;
    });
    return keys;
  }

  function renderRankingChart(data) {
    // Collect all lines with their total output
    const allLines = [];
    
    sectionOrder.forEach(section => {
      const sectionData = (data.sections && data.sections[section]) || {};
      const lineKeys = getSortedLineKeys(sectionData);
      
      lineKeys.forEach(label => {
        let totalOutput = 0;
        shifts.forEach(shift => {
          const m = (sectionData[label] && sectionData[label][shift]) || {actual: 0};
          totalOutput += Number(m.actual || 0);
        });
        
        allLines.push({
          label: `${section} - ${label}`,
          output: totalOutput,
          section: section
        });
      });
    });
    
    // Sort by output descending and get top 10
    allLines.sort((a, b) => b.output - a.output);
    const topLines = allLines.slice(0, 10);
    
    // Prepare data for chart
    const labels = topLines.map(line => line.label);
    const outputs = topLines.map(line => line.output);
    
    // Vibrant colors based on section
    const colors = topLines.map(line => {
      if (line.section === 'CABLE') return 'rgba(54, 114, 165, 1)';        // Deep Steel Blue
      if (line.section === 'FEEDER') return 'rgba(255, 140, 0, 1)';        // Dark Orange
      return 'rgba(60, 179, 113, 1)';                                       // Medium Sea Green
    });
    
    const canvas = document.getElementById('rankingChart');
    if (!canvas) return;
    
    // Destroy existing chart if it exists
    if (rankingChart) {
      rankingChart.destroy();
    }
    
    rankingChart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Total Output',
          data: outputs,
          backgroundColor: colors,
          borderColor: colors,
          borderWidth: 3,
          borderRadius: 6,
          barPercentage: 0.8,
          categoryPercentage: 0.9
        }]
      },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            backgroundColor: 'rgba(0,0,0,0.8)',
            padding: 15,
            titleFont: { size: 14, weight: 'bold' },
            bodyFont: { size: 13 },
            callbacks: {
              label: function(context) {
                return 'Total Output: ' + fmt(context.parsed.x);
              }
            }
          },
          datalabels: {
            display: true
          }
        },
        scales: {
          y: {
            ticks: {
              font: { size: 13, weight: 'bold' },
              color: '#333'
            },
            grid: {
              display: false
            }
          },
          x: {
            beginAtZero: true,
            ticks: {
              font: { size: 12 },
              callback: function(value) {
                return fmt(value);
              }
            },
            grid: {
              color: 'rgba(200, 200, 200, 0.3)',
              drawBorder: true
            }
          }
        }
      },
      plugins: [{
        id: 'datalabels',
        afterDatasetsDraw(chart) {
          const { ctx, data, chartArea: { left, top, width, height } } = chart;
          ctx.font = 'bold 13px Arial';
          ctx.fillStyle = '#333';
          ctx.textAlign = 'end';
          ctx.textBaseline = 'middle';
          
          chart.getDatasetMeta(0).data.forEach((bar, index) => {
            const value = data.datasets[0].data[index];
            if (value === 0) return;
            
            const x = bar.x - 10;
            const y = bar.y;
            ctx.fillText(fmt(value), x, y);
          });
        }
      }]
    });
  }

  function render(data){
    lastJson = data;
    if (!tbody) return;
    tbody.innerHTML = '';
    sectionOrder.forEach(section => {
      const sectionData = (data.sections && data.sections[section]) || {};
      const lineKeys = getSortedLineKeys(sectionData);
      const shiftLoop = currentShift === 'All' ? shifts : [currentShift];
      shiftLoop.forEach(shift => {
        tbody.insertAdjacentHTML('beforeend', `<tr style="background:#f8f9fa;font-weight:bold;"><td colspan="7">${section} — ${shift} Shift</td></tr>`);
        lineKeys.forEach(label => {
          const m = (sectionData[label] && sectionData[label][shift]) || {target:0, actual:0, difference:0, achievement_rate:0, reject_qty:0, reject_ppm:0};
          tbody.insertAdjacentHTML('beforeend', `
            <tr>
              <td>${label}</td>
              <td>${fmt(m.target)}</td>
              <td>${fmt(m.actual)}</td>
              <td>${fmt(m.difference)}</td>
              <td>${fmt(m.achievement_rate)}%</td>
              <td>${fmt(m.reject_qty)}</td>
              <td>${fmt(m.reject_ppm)}</td>
            </tr>
          `);
        });
      });
    });
    renderCards(data);
    renderRankingChart(data);
  }

  function statusClass(pct){
    if (pct >= 101) return 'over';
    if (pct === 100) return 'good';
    if (pct >= 95.5) return 'warn';
    return 'bad';
  }
  function renderCards(data){
    const root = document.getElementById('cards-root');
    if (!root) return;
    root.innerHTML = '';

    sectionOrder.forEach(section => {
      const sectionData = (data.sections && data.sections[section]) || {};
      const lineKeys = getSortedLineKeys(sectionData);
      const shiftLoop = currentShift === 'All' ? shifts : [currentShift];

      shiftLoop.forEach(shift => {
        // Section + Shift header row
        const header = document.createElement('div');
        header.className = 'col-12';
        header.innerHTML = `<div class="section-summary p-1"><h5 class="m-0">${section} — ${shift} Shift</h5></div>`;
        root.appendChild(header);

        lineKeys.forEach(label => {
          const m = (sectionData[label] && sectionData[label][shift]) || {target:0, actual:0, difference:0, achievement_rate:0, reject_qty:0, reject_ppm:0};
          const pct = Number(m.achievement_rate || 0);
          const badge = statusClass(pct);
          const achRing = Math.max(0, Math.min(100, pct));
          const rejRing = Math.max(0, Math.min(100, (Number(m.actual || 0) > 0 ? (Number(m.reject_qty || 0) / Number(m.actual || 1)) * 100 : 0)));

          // Check for no production data
          const hasData = (Number(m.target || 0) > 0 || Number(m.actual || 0) > 0 || Number(m.reject_qty || 0) > 0);
          
          console.log(`${section} ${label} ${shift}:`, {hasData, target: m.target, actual: m.actual, reject: m.reject_qty});

          const col = document.createElement('div');
          col.className = 'col-12 col-sm-6 col-md-4 col-lg-2';
          col.innerHTML = `
            <div class="line-card card h-100">
              <div class="card-header">
                <div class="line-title"><i class="bi bi-diagram-3 me-1"></i> ${label.toUpperCase()}</div>
                <div class="rates-labels">
                  <span class="achievement-rate ${pct > 100 ? 'bg-blue' : pct >= 95 ? 'bg-green' : 'bg-red'}">Achievement - ${pct.toFixed ? pct.toFixed(0) : pct}%</span>
                  <span class="reject-rate bg-red">Reject- ${rejRing.toFixed ? rejRing.toFixed(0) : rejRing}%</span>
                </div>
              </div>  
              <div class="card-body">
                ${hasData ? `
                  <div class="metrics-and-chart">
                    <div class="kpi-list">
                      <div class="metric">PLAN:  <span>${fmt(m.target)}</span></div>
                      <div class="metric">OUTPUT: <span>${fmt(m.actual)}</span></div>
                      <div class="metric">DIFFERENCE: <span>${fmt(m.difference)}</span></div>
                      <div class="metric">REJECT: <span>${fmt(m.reject_qty)}</span></div>
                      <div class="metric">REJECT PPM: <span>${fmt(m.reject_ppm)}</span></div>
                    </div>
                    <div class="donut-wrap">
                      <div class="dual-donut" style="--ach:${Math.round(achRing*10)/10}; --rej:${Math.round(rejRing*10)/10}; --size:200px;">
                        <div class="ring outer"></div>
                        <div class="ring inner"></div>
                      </div>

                    </div>
                  </div>
                ` : `
                  <div class="no-production">
                    <i class="bi bi-exclamation-triangle text-warning me-2"></i>
                    No Production
                  </div>
                `}
              </div>
            </div>`;
          root.appendChild(col);
        });
      });
    });
  }

  async function load(dateStr){
    // Automatically set currentShift based on time
    currentShift = getCurrentShiftByTime();

    // Update the dropdown to reflect the current shift
    const shiftSel = document.getElementById('shiftFilter');
    if (shiftSel) {
      shiftSel.value = currentShift;
    }

    // If no dateStr provided, first fetch to get server's date
    if (!dateStr) {
      try {
        const serverRes = await fetch('central_monitoring_api.php?date=', { cache: 'no-store' });
        const serverJson = await serverRes.json();
        if (serverJson && serverJson.date) {
          dateStr = serverJson.date;
        }
      } catch (e) {
        // Fallback to browser date if server date fetch fails
        dateStr = new Date().toISOString().slice(0,10);
      }
    }

    const url = 'central_monitoring_api.php?date=' + encodeURIComponent(dateStr);
    try{
      const res = await fetch(url, { cache: 'no-store' });
      const text = await res.text();
      let json;
      try { json = JSON.parse(text); } catch(parseErr) {
        throw new Error(`HTTP ${res.status} ${res.statusText} | Response: ${text.slice(0,200)}`);
      }
      if (!json || json.success !== true) {
        const msg = json && (json.message || json.error) ? ` | ${json.message || json.error}` : '';
        throw new Error(`API error${msg}`);
      }
      console.log('Loaded data:', json);
      console.log('Current shift for display:', currentShift);
      console.log('Using date:', dateStr);
      render(json);
    }catch(err){
      console.error('Failed to load monitoring data:', err);
      if (tbody) tbody.innerHTML = `<tr><td colspan="7" style="color:#dc3545;">Failed to load data. ${String(err.message || err).slice(0,300)}</td></tr>`;
    }
  }

  function updateClock(){
    const now = new Date();
    const d = document.getElementById('currentDate');
    const t = document.getElementById('currentTime');
    if (d) d.textContent = now.toLocaleDateString();
    if (t) t.textContent = now.toLocaleTimeString();
  }

  // Init
  updateClock();
  setInterval(updateClock, 1000);
  load();
  setInterval(() => load(), 30000);

  // Optional: backup button hook placeholder
  const backupBtn = document.getElementById('backupButton');
  if (backupBtn) {
    backupBtn.addEventListener('click', function(){
      alert('Backup feature not implemented yet.');
    });
  }

  // Shift filter
  const shiftSel = document.getElementById('shiftFilter');
  if (shiftSel) {
    shiftSel.addEventListener('change', function(){
      currentShift = shiftSel.value;
      if (lastJson) { render(lastJson); } else { load(); }
    });
  }
})();
</script>
</body>
</html>
