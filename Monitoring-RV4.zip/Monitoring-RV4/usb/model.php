<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Simple Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../node_modules/bootstrap-icons/font/bootstrap-icons.css">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
    }
    .sidebar {
      background-color: #fff;
      color: #222;
      border-right: 1px solid #e3f0ff;
      box-shadow: 0 0 8px rgba(163, 201, 247, 0.08);
      min-height: 100vh;
    }
    .sidebar .nav-link {
      color: #222;
      font-weight: 500;
      border-radius: 8px;
      margin-bottom: 8px;
      transition: background 0.2s, color 0.2s;
    }
    .sidebar .nav-link.active,
    .sidebar .nav-link:hover {
      background-color: #a3c9f7;
      color: #222;
    }
    .sidebar h4 {
      color: #222;
      font-weight: 700;
    }
    .content-area {
      padding: 2rem;
    }
    .navbar {
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>
<div class="content-area">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Model Number Data</h2>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
      <i class="bi bi-plus-lg"></i> Add Model
    </button>
  </div>
  <table class="table table-hover table-bordered align-middle">
    <thead class="table-primary">
      <tr>
        <th scope="col"> ID</th>
        <th scope="col"><i class="bi bi-list-ol"></i> Model number</th>
        <th scope="col"><i class="bi bi-gear"></i> Actions</th>
      </tr>
    </thead>
    <tbody>
      <!-- Table rows go here -->
    </tbody>
  </table>
</div>

<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">
  <div class="modal-header">
  <h1 class="modal-title fs-5" id="staticBackdropLabel">Add Model Number</h1>
  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
  </div>
  <div class="modal-body">
  <div> 
  <label for="modelNumber" class="form-label">Model Number</label>
  <input type="text" class="form-control" id="modelNumber" name="modelNumber" placeholder="Enter model number">
  </div>
  </div>
  <div class="modal-footer">
  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
  <button type="button" class="btn btn-primary">Save</button>
  </div> 
  </div>
  </div>
</div>

<script src="../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>