<?php
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');

include 'database/init.php';

// Function to get latest production data for all lines
function getLatestData($database) {
    $sections = [
        'CABLE' => ['record_table' => 'cproduction_record', 'breaks_table' => 'cproduction_breaks', 'line_table' => 'cable_line'],
        'FEEDER' => ['record_table' => 'fproduction_record', 'breaks_table' => 'fproduction_breaks', 'line_table' => 'feeder_line']
    ];

    $result = [];

    foreach ($sections as $section => $tables) {
        // Get all lines for this section
        $lines = $database->select($tables['line_table'], 'Cline_name', [
            'ORDER' => ['Cline_ID' => 'ASC']
        ]);

        foreach ($lines as $lineRow) {
            $line = $lineRow['Cline_name'];
            $shifts = ['Day', 'Night'];

            foreach ($shifts as $shift) {
                $data = getProductionData($database, $section, $line, $shift);

                if ($data) {
                    $result["{$section}_{$line}_{$shift}"] = $data;
                }
            }
        }
    }

    return $result;
}

// Main SSE loop
$lastData = [];
while (true) {
    $currentData = getLatestData($database);

    // Only send updates if data has changed
    if (json_encode($currentData) !== json_encode($lastData)) {
        echo "data: " . json_encode($currentData) . "\n\n";
        ob_flush();
        flush();
        $lastData = $currentData;
    }

    // Sleep for 5 seconds before next check
    sleep(5);
}
?>
