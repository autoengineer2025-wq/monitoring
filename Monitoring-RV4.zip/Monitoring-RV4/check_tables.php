<?php
include 'database/init.php';

// Get all tables
$tables = $database->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

echo "<h2>Database Tables</h2>";
echo "<pre>";
print_r($tables);
echo "</pre>";

// For each table, show structure
foreach ($tables as $table) {
    echo "<h3>Table: $table</h3>";
    $columns = $database->query("DESCRIBE `$table`")->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' cellpadding='5' cellspacing='0'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($column['Field']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Type']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Null']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Key']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Default'] ?? 'NULL') . "</td>";
        echo "<td>" . htmlspecialchars($column['Extra']) . "</td>";
        echo "</tr>";
    }
    echo "</table><br>";
}
?>
