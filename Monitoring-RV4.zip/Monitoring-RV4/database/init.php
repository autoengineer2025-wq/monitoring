<?php
include __DIR__ . '/../vendor/autoload.php';

use Medoo\Medoo;

// Database Connection

    $database = new Medoo([
        'type' => 'mysql',
        'host' => 'localhost',
        'database' => 'monitoring',
        'username' => 'root',
        'password' =>'',
    ]);


