<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Central Monitoring</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../node_modules/bootstrap-icons/font/bootstrap-icons.css">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
    }
    .sidebar {
      background-color: #fff;
      color: #222;
      border-right: 1px solid #e3f0ff;
      box-shadow: 0 0 8px rgba(163, 201, 247, 0.08);
      min-height: 100vh;
    }
    .sidebar .nav-link {
      color: #222;
      font-weight: 500;
      border-radius: 8px;
      margin-bottom: 8px;
      transition: background 0.2s, color 0.2lies;
    }
    .sidebar .nav-link:hover {
      background-color: #a3c9f7;
      color: #222;
    }
    .sidebar h4 {
      color: #222;
      font-weight: 700;
    }
    .content-area {
      padding: 2rem;
    }
    .navbar {
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <nav class="sidebar col-lg-2 col-md-3 d-flex flex-column p-3">
      <h4 class="mb-5 text-center">Central monitoring - Cable</h4>
      <ul class="nav flex-column">
        <li class="mb-2 nav-item">
          <a href="cable.php" class="nav-link">
            <i class="bi bi-speedometer2 me-2"></i> Dashboard
          </a>
        </li>
        <li class="mb-2 nav-item">
          <a href="model.php" class="nav-link">
            <i class="bi bi-cpu me-2"></i> Model Number
          </a>
        </li>
        <li class="mb-2 nav-item">
          <a href="drawing.php" class="nav-link active">
            <i class="bi bi-file-earmark-text me-2"></i> Drawing Number
          </a>
        </li>
        <li class="mb-2 nav-item">
          <a href="production.php" class="nav-link">
            <i class="bi bi-clock-history me-2"></i> Production Time
          </a>
        </li>
        <li class="nav-item mb-2">
          <a href="line.php" class="nav-link">
            <i class="bi bi-bar-chart-steps me-2"></i> Line
          </a>
        </li>
      </ul>
    </nav>

    <!-- Main Content -->
    <main class="col-lg-10 col-md-9 content-area">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Model Number Data</h2>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addModelModal">
          <i class="bi bi-plus-lg"></i> Add Model
        </button>
      </div>

      <table class="table table-hover table-bordered align-middle">
        <thead class="table-primary">
          <tr>
            <th scope="col">ID</th>
            <th scope="col"><i class="bi bi-list-ol"></i> Model number</th>
            <th scope="col"><i class="bi bi-gear"></i> Actions</th>
          </tr>
        </thead>
        <tbody id="modelTableBody">
            <!-- Rows will be inserted by JS -->
      </tbody>
      </table>
    </main>
  </div>
</div>

<!-- Modal: Add Model -->
<div class="modal fade" id="addModelModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="addModelModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form method="post" class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="addModelModalLabel">Add Model Number</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <label for="modelNumber" class="form-label">Model Number</label>
        <input type="text" class="form-control" id="modelNumber" name="modelNumber" placeholder="Enter model number" required>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Edit Model -->
<div class="modal fade" id="editModelModal" tabindex="-1" aria-labelledby="editModelModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form class="modal-content" id="editModelForm">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="editModelModalLabel">Edit Model Number</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="editModelId">
        <label for="editModelNumber" class="form-label">Model Number</label>
        <input type="text" class="form-control" id="editModelNumber" required>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </div>
    </form>
  </div>
</div>

<script src="../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script>
function fetchModels() {
  fetch('API/model_api.php')
    .then(res => res.json())
    .then(models => {
      const tbody = document.getElementById('modelTableBody');
      tbody.innerHTML = '';
      models.forEach(model => {
        tbody.innerHTML += `
          <tr>
            <td>${model.Cmodel_ID}</td>
            <td>${model.Cmodel}</td>
            <td>
              <button class="btn btn-sm btn-warning edit-btn" data-id="${model.Cmodel_ID}" data-model="${model.Cmodel}"><i class="bi bi-pencil-square"></i></button>
              <button class="btn btn-sm btn-danger delete-btn" data-id="${model.Cmodel_ID}"><i class="bi bi-trash"></i></button>
            </td>
          </tr>
        `;
      });
      addEventListeners();
    });
}

function addEventListeners() {
  // Edit
  document.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      document.getElementById('editModelId').value = this.getAttribute('data-id');
      document.getElementById('editModelNumber').value = this.getAttribute('data-model');
      var editModal = new bootstrap.Modal(document.getElementById('editModelModal'));
      editModal.show();
    });
  });
  // Delete
  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      if (confirm('Delete this model number?')) {
        fetch('API/model_api.php', {
          method: 'DELETE',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({id: this.getAttribute('data-id')})
        })
        .then(res => res.json())
        .then(data => {
          if (data.success) fetchModels();
          else alert(data.error || 'Delete failed');
        });
      }
    });
  });
}

// Add Model
document.querySelector('#addModelModal form').addEventListener('submit', function(e) {
  e.preventDefault();
  const modelNumber = document.getElementById('modelNumber').value.trim();
  if (!modelNumber) return;
  fetch('API/model_api.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({modelNumber})
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      bootstrap.Modal.getInstance(document.getElementById('addModelModal')).hide();
      fetchModels();
    } else {
      alert(data.error || 'Failed to add model number');
    }
  });
});

// Edit Model
document.getElementById('editModelForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const id = document.getElementById('editModelId').value;
  const modelNumber = document.getElementById('editModelNumber').value.trim();
  if (!id || !modelNumber) return;
  fetch('API/model_api.php', {
    method: 'PUT',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({id, modelNumber})
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) {
      bootstrap.Modal.getInstance(document.getElementById('editModelModal')).hide();
      fetchModels();
    } else {
      alert(data.error || 'Failed to update');
    }
  });
});

// Initial fetch
fetchModels();
</script>
</body>
</html>
