<?php
include_once '../../../database/init.php';
header('Content-Type: application/json');
$id = $_GET['id'] ?? '';
if ($id) {
    $row = $database->get("cproductiontime", "*", ["Cprod_ID" => $id]);

    if ($row) {
        $result = [];
        if (isset($row['Cprod_hours'])) {
            $result['Cprod_hours'] = $row['Cprod_hours'];
        }
        if (isset($row['Cshift'])) {
            $result['Cshift'] = $row['Cshift'];
        }

        for ($i = 1; $i <= 5; $i++) {
            $result["Cstart_Time$i"] = $row["Cstart_Time$i"] ?? '';
            $result["Cend_Time$i"] = $row["Cend_Time$i"] ?? '';
        }
        echo json_encode($result);
        exit;
    }
}
echo json_encode([]);