<?php
include __DIR__ . '/../../../database/init.php';
header('Content-Type: application/json');
$drawing_number = $_GET['cdrawing_number'] ?? '';
if (!$drawing_number) {
  echo json_encode([]);
  exit;
}
$row = $database->get("cdrawingnumber", "*", ["Cdrawing_ID" => $drawing_number]);
if ($row) {
  echo json_encode([
    "takttime" => $row['takttime'],
    "length" => $row['length'],
    "qty" => $row['qty']
  ]);
} else {
  echo json_encode([]);
}