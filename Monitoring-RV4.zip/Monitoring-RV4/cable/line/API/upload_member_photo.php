<?php
header('Content-Type: application/json');

try { include_once '../../../database/init.php'; } catch (Exception $e) {}

function jres($ok, $data = [], $code = 200) {
  http_response_code($code);
  echo json_encode(array_merge([ 'success' => (bool)$ok ], $data));
  exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  jres(false, [ 'error' => 'Method not allowed' ], 405);
}

$lineId = isset($_POST['line_id']) ? intval($_POST['line_id']) : 0;
$group  = isset($_POST['group']) ? strtoupper(trim((string)$_POST['group'])) : '';
$role   = isset($_POST['role']) ? strtolower(trim((string)$_POST['role'])) : '';

if ($lineId <= 0 || !$group || !$role) {
  jres(false, [ 'error' => 'Missing parameters' ], 400);
}

if (!isset($_FILES['file']) || !is_array($_FILES['file'])) {
  jres(false, [ 'error' => 'No file uploaded' ], 400);
}

$file = $_FILES['file'];
if ($file['error'] !== UPLOAD_ERR_OK) {
  jres(false, [ 'error' => 'Upload error' ], 400);
}

$allowed = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $file['tmp_name']);
$ext  = $allowed[$mime] ?? '';
if (!$ext) { jres(false, [ 'error' => 'Unsupported file type' ], 400); }

$maxBytes = 2 * 1024 * 1024; // 2 MB
if (($file['size'] ?? 0) > $maxBytes) { jres(false, [ 'error' => 'File too large (max 2MB)' ], 400); }

$uploadDir = __DIR__ . '/../uploads';
if (!is_dir($uploadDir)) {
  if (!mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) {
    jres(false, [ 'error' => 'Failed to create upload directory' ], 500);
  }
}

$base = 'line' . $lineId . '_' . strtoupper($group) . '_' . strtolower($role) . '_' . date('Ymd_His');
$filename = $base . '.' . $ext;
$targetFs = $uploadDir . '/' . $filename;

if (!move_uploaded_file($file['tmp_name'], $targetFs)) {
  jres(false, [ 'error' => 'Failed to move uploaded file' ], 500);
}

// Build URL relative to the VIEW directory context: VIEW/ -> ../uploads/
$publicUrl = '../uploads/' . $filename;

jres(true, [ 'url' => $publicUrl ]);
