<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');
include __DIR__ . '/../../../database/init.php';

// Debug log
file_put_contents('debug.txt', "RAW POST DATA:\n" . print_r($_POST, true) . "\n", FILE_APPEND);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $production_date = $_POST['production_date'] ?? '';
    $Cline_ID        = $_POST['Cline_ID'] ?? '';
    $Cprod_ID        = $_POST['Cprod_ID'] ?? '';
    $shift           = $_POST['shift'] ?? '';
    $mCount          = intval($_POST['mCount'] ?? 0);

    if (!$production_date || !$Cline_ID || !$Cprod_ID || !$shift || $mCount <= 0) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        exit;
    }

    $normalizedShift = $shift;
    try {
        if (!empty($Cprod_ID)) {
            $pt = $database->get('Cproductiontime', ['Cshift','Cprod_name'], ['Cprod_ID' => $Cprod_ID]);
            if ($pt) {
                if (isset($pt['Cshift']) && ($pt['Cshift'] === 'Night' || $pt['Cshift'] === 'Day')) {
                    $normalizedShift = ($pt['Cshift'] === 'Night') ? 'Night Shift' : 'Day Shift';
                } elseif (isset($pt['Cprod_name'])) {
                    $name = strtolower(trim($pt['Cprod_name']));
                    $normalizedShift = (strpos($name, 'night') !== false) ? 'Night Shift' : 'Day Shift';
                }
            }
        }
    } catch (Exception $e) {
        // fallback to posted shift if lookup fails
        $normalizedShift = $shift ?: 'Day Shift';
    }

    $shiftGroup = (stripos($normalizedShift, 'night') !== false) ? 'Night' : 'Day';
    $existing = $database->get("cproduction_record", "*", [
        "production_date" => $production_date,
        "Cline_ID"        => $Cline_ID,
        "Shift[~]"        => $shiftGroup
    ]);
    if ($existing) {
        echo json_encode(['success' => false, 'message' => 'Record already exists for this line, shift, and date']);
        exit;
    }

    // Initialize consolidated data
    $totalPlanTarget = 0;
    $totalWorkingHours = 0;
    $takttimeValues = [];
    $lengthValues = [];
    $drawingIds = [];
    $quantities = [];
    $modelPlanTargets = [];
    
    // Collect data from all models
    for ($i = 1; $i <= $mCount; $i++) {
        $Cdrawing_ID  = $_POST["Cdrawing_ID$i"] ?? '';
        $qty          = intval($_POST["qty$i"] ?? 0);
        $workingHours = floatval($_POST["workingHours$i"] ?? 0);
        $takttime     = floatval($_POST["takttime$i"] ?? 0);
        $length       = floatval($_POST["length$i"] ?? 0);

        if (!$Cdrawing_ID || $qty <= 0) continue;

        // Calculate plan target for this model
        $modelPlanTarget = ($takttime > 0 && $workingHours > 0) ? (int)floor(($workingHours * 3600) / $takttime) : 0;
        
        // Accumulate totals
        $totalPlanTarget += $modelPlanTarget;
        $totalWorkingHours += $workingHours;
        
        // Store individual values for multi-model support
        $takttimeValues[] = $takttime;
        $lengthValues[] = $length;
        $drawingIds[] = $Cdrawing_ID;
        $quantities[] = $qty;
        $modelPlanTargets[] = $modelPlanTarget;
    }

    // Create comma-separated strings for multi-model data
    $takttimeString = implode(', ', $takttimeValues);
    $lengthString = implode(', ', $lengthValues);
    $drawingIdString = implode(', ', $drawingIds);

    // Use the first drawing ID as the primary one (for compatibility)
    $primaryDrawingId = !empty($drawingIds) ? $drawingIds[0] : '';

    // Create single consolidated record
    $data = [
        "production_date" => $production_date,
        "Shift"           => $normalizedShift,
        "Cline_ID"        => $Cline_ID,
        "Cprod_ID"        => $Cprod_ID,
        "Cdrawing_ID"     => $drawingIdString, // Comma-separated drawing IDs for multi-model support
        "plan_target"     => $totalPlanTarget,
        "target"          => 0,
        "working_hours"   => $totalWorkingHours,
        "actual1"         => 0,
        "actual2"         => 0,
        "actual3"         => 0,
        "actual4"         => 0,
        "actual5"         => 0,
        "total_actual"    => 0,
        "takttime"        => $takttimeString,
        "reject_count"    => 0,
        "reject_ppm"      => null,
        "length"          => $lengthString,
        "Cstart_Time1"    => $_POST['Cstart_Time1'] ?? null,
        "Cend_Time1"      => $_POST['Cend_Time1'] ?? null,
        "Cstart_Time2"    => $_POST['Cstart_Time2'] ?? null,
        "Cend_Time2"      => $_POST['Cend_Time2'] ?? null,
        "Cstart_Time3"    => $_POST['Cstart_Time3'] ?? null,
        "Cend_Time3"      => $_POST['Cend_Time3'] ?? null,
        "Cstart_Time4"    => $_POST['Cstart_Time4'] ?? null,
        "Cend_Time4"      => $_POST['Cend_Time4'] ?? null,
        "Cstart_Time5"    => $_POST['Cstart_Time5'] ?? null,
        "Cend_Time5"      => $_POST['Cend_Time5'] ?? null,
        "created_at"      => date('Y-m-d H:i:s')
        // Note: model_info column may not exist in database, so we'll handle multi-model logic differently
    ];

    file_put_contents('debug.txt', "CONSOLIDATED INSERT DATA:\n" . print_r($data, true) . "\n", FILE_APPEND);
    // Insert into cable table
    $result = $database->insert("cproduction_record", $data);
    $newRecordId = $database->id();
    
    // Create per-model progress rows for sequencing (one row per model)
    if ($newRecordId && count($drawingIds) > 0) {
        for ($i = 0; $i < count($drawingIds); $i++) {
            $database->insert('cproduction_model_progress', [
                'record_id' => $newRecordId,
                'model_index' => $i + 1,
                'Cdrawing_ID' => $drawingIds[$i],
                'model_qty_per_press' => intval($quantities[$i] ?? 0),
                'model_plan_total' => intval($modelPlanTargets[$i] ?? 0),
                'produced_units' => 0,
                'created_at' => date('Y-m-d H:i:s')
            ]);
        }
    }

    if ($result) {
        echo json_encode([
            'success' => true,
            'Cline_ID' => $Cline_ID,
            'shift'    => $normalizedShift,
            'record_id' => $newRecordId ?: $result,
            'plan_target' => $totalPlanTarget,
            'model_count' => $mCount
        ]);
    } else {
        echo json_encode([
            'success' => false, 
            'message' => 'Insert failed: ' . json_encode($database->error)
        ]);
    }
    exit;
}
