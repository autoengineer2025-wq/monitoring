<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Drawing Number</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../node_modules/bootstrap-icons/font/bootstrap-icons.css">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
    }
    .sidebar {
      background-color: #fff;
      color: #222;
      border-right: 1px solid #e3f0ff;
      box-shadow: 0 0 8px rgba(163, 201, 247, 0.08);
      min-height: 100vh;
    }
    .sidebar .nav-link {
      color: #222;
      font-weight: 500;
      border-radius: 8px;
      margin-bottom: 8px;
      transition: background 0.2s, color 0.2s;
    }
    .sidebar .nav-link.active,
    .sidebar .nav-link:hover {
      background-color: #a3c9f7;
      color: #222;
    }
    .sidebar h4 {
      color: #222;
      font-weight: 700;
    }
    .content-area {
      padding: 2rem;
    }
    .table-pastel-green thead {
      background-color: #d4edda;
      color: #155724;
    }
    .table-pastel-green tbody tr:hover {
      background-color: #e9f7ef;
    }
    .card {
      border: none;
      border-radius: 8px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row">

    <!-- Sidebar -->
    <nav class="sidebar col-lg-2 col-md-3 d-flex flex-column p-3">
      <h4 class="mb-5 text-center">Central Monitoring - Cable</h4>
      <ul class="nav flex-column">
        <li class="mb-2 nav-item">
          <a href="cable.php" class="nav-link">
            <i class="bi bi-speedometer2 me-2"></i> Dashboard
          </a>
        </li>
        <li class="mb-2 nav-item">
          <a href="model.php" class="nav-link">
            <i class="bi bi-cpu me-2"></i> Model Number
          </a>
        </li>
        <li class="mb-2 nav-item">
          <a href="drawing.php" class="nav-link active">
            <i class="bi bi-file-earmark-text me-2"></i> Drawing Number
          </a>
        </li>
        <li class="mb-2 nav-item">
          <a href="production.php" class="nav-link">
            <i class="bi bi-clock-history me-2"></i> Production Time
          </a>
        </li>
        <li class="nav-item mb-2">
          <a href="line.php" class="nav-link">
            <i class="bi bi-bar-chart-steps me-2"></i> Line
          </a>
        </li>
      </ul>
    </nav>

    <!-- Main Content -->
    <main class="content-area col-lg-10 col-md-9">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Drawing Number Data</h2>
        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
          <i class="bi bi-plus-lg"></i> Add Drawing
        </button>
      </div>

      <!-- Card with Table -->
      <div class="card">
        <div class="card-body p-0">
          <table class="table table-hover table-bordered align-middle mb-0 table-pastel-green">
            <thead>
              <tr>
                <th>ID</th>
                <th>Model Number</th>
                <th>Drawing Number</th>
                <th>Takt Time</th>
                <th>Length</th>
                <th>Quantity</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody id="drawingTableBody">
              <!-- Data will be loaded here -->
            </tbody>
          </table>
        </div>
      </div>
    </main>

  </div>
</div>

<!-- ADD Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" id="drawingForm">
      <div class="modal-header">
        <h1 class="modal-title fs-5">Add Drawing Number</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
       <div class="mb-3">
          <label for="modelNumber" class="form-label">Model Number</label>
          <select class="form-control" id="modelNumber" name="modelNumber">
            <option value="">Select model number</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="drawingNumber" class="form-label">Drawing Number</label>
          <input type="text" class="form-control" id="drawingNumber" name="drawingNumber">
        </div>
        <div class="mb-3">
          <label for="taktTime" class="form-label">Takt Time</label>
          <input type="text" class="form-control" id="taktTime" name="taktTime">
        </div>
        <div class="mb-3">
          <label for="length" class="form-label">Length</label>
          <input type="text" class="form-control" id="length" name="length">
        </div>
        <div class="mb-3">
          <label for="quantity" class="form-label">Quantity</label>
          <input type="text" class="form-control" id="quantity" name="quantity">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-success">Save</button>
      </div>
    </form>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" id="editDrawingForm">
      <div class="modal-header">
        <h1 class="modal-title fs-5">Edit Drawing Number</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="editDrawingId" name="Cdrawing_ID">
        <div class="mb-3">
          <label for="editModelNumber" class="form-label">Model Number</label>
          <select class="form-control" id="editModelNumber" name="modelNumber"></select>
        </div>
        <div class="mb-3">
          <label for="editDrawingNumber" class="form-label">Drawing Number</label>
          <input type="text" class="form-control" id="editDrawingNumber" name="drawingNumber">
        </div>
        <div class="mb-3">
          <label for="editTaktTime" class="form-label">Takt Time</label>
          <input type="text" class="form-control" id="editTaktTime" name="taktTime">
        </div>
        <div class="mb-3">
          <label for="editLength" class="form-label">Length</label>
          <input type="text" class="form-control" id="editLength" name="length">
        </div>
        <div class="mb-3">
          <label for="editQuantity" class="form-label">Quantity</label>
          <input type="text" class="form-control" id="editQuantity" name="quantity">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Update</button>
      </div>
    </form>
  </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" id="deleteDrawingForm">
      <div class="modal-header">
        <h1 class="modal-title fs-5">Delete Drawing Number</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="deleteDrawingId" name="Cdrawing_ID">
        <p>Are you sure you want to delete this drawing number?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-danger">Delete</button>
      </div>
    </form>
  </div>
</div>

<script src="../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
  // Load models for both add and edit forms
  function loadModels(selectId, selectedValue = '') {
    fetch('API/drawing_api.php?action=get_models')
      .then(res => res.json())
      .then(data => {
        const select = document.getElementById(selectId);
        select.innerHTML = '<option value="">Select model number</option>';
        data.forEach(model => {
          const opt = document.createElement('option');
          opt.value = model.Cmodel_ID;
          opt.textContent = model.Cmodel;
          if (model.Cmodel_ID == selectedValue) opt.selected = true;
          select.appendChild(opt);
        });
      });
  }
  loadModels('modelNumber');

  // Load drawing numbers
  function loadDrawings() {
    fetch('API/drawing_api.php?action=get_drawings')
      .then(res => res.json())
      .then(data => {
        const tbody = document.getElementById('drawingTableBody');
        tbody.innerHTML = '';
        data.forEach(row => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td>${row.Cdrawing_ID}</td>
            <td>${row.Cmodel}</td>
            <td>${row.Cdrawingnum}</td>
            <td>${row.takttime}</td>
            <td>${row.length}</td>
            <td>${row.qty}</td>
            <td>
              <button class="btn btn-sm btn-primary me-1 edit-btn" data-id="${row.Cdrawing_ID}"><i class="bi bi-pencil"></i></button>
              <button class="btn btn-sm btn-danger delete-btn" data-id="${row.Cdrawing_ID}"><i class="bi bi-trash"></i></button>
            </td>
          `;
          tbody.appendChild(tr);
        });

        // Attach event listeners for edit and delete buttons
        document.querySelectorAll('.edit-btn').forEach(btn => {
          btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const row = data.find(r => r.Cdrawing_ID == id);
            document.getElementById('editDrawingId').value = row.Cdrawing_ID;
            loadModels('editModelNumber', row.Cmodel_ID);
            document.getElementById('editDrawingNumber').value = row.Cdrawingnum;
            document.getElementById('editTaktTime').value = row.takttime;
            document.getElementById('editLength').value = row.length;
            document.getElementById('editQuantity').value = row.qty;
            new bootstrap.Modal(document.getElementById('editModal')).show();
          });
        });
        document.querySelectorAll('.delete-btn').forEach(btn => {
          btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            document.getElementById('deleteDrawingId').value = id;
            new bootstrap.Modal(document.getElementById('deleteModal')).show();
          });
        });
      });
  }
  loadDrawings();

  // Submit add form
  document.getElementById('drawingForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('API/drawing_api.php?action=create', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(resp => {
      if (resp.success) {
        alert('Drawing added!');
        location.reload();
      } else {
        alert('Error: ' + resp.message);
      }
    });
  });

  // Submit edit form
  document.getElementById('editDrawingForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('API/drawing_api.php?action=edit', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(resp => {
      if (resp.success) {
        alert('Drawing updated!');
        location.reload();
      } else {
        alert('Error: ' + resp.message);
      }
    });
  });

  // Submit delete form
  document.getElementById('deleteDrawingForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('API/drawing_api.php?action=delete', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(resp => {
      if (resp.success) {
        alert('Drawing deleted!');
        location.reload();
      } else {
        alert('Error: ' + resp.message);
      }
    });
  });
});
</script>
</body>
</html>
