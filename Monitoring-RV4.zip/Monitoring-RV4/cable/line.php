<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>CABLE Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../node_modules/bootstrap-icons/font/bootstrap-icons.css">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
    }
    .sidebar {
      background-color: #fff;
      border-right: 1px solid #e3f0ff;
      box-shadow: 0 0 8px rgba(163, 201, 247, 0.08);
      min-height: 100vh;
    }
    .sidebar .nav-link {
      color: #222;
      font-weight: 500;
      border-radius: 8px;
      margin-bottom: 8px;
      transition: background 0.2s, color 0.2s;
    }
    .sidebar .nav-link:hover {
      background-color: #a3c9f7;
      color: #222; 
    }
    .sidebar h4 {
      font-weight: 700;
      text-align: center;
    }
    .content-area {
      padding: 2rem;
    }
    /* Pastel green table theme */
    .table-pastel-green thead {
      background-color: #d4edda; /* light pastel green */
      color: #155724; /* dark green text */
    }
    .table-pastel-green tbody tr:hover {
      background-color: #e9f7ef; /* lighter hover effect */
    }
    .card {
      border-radius: 8px;
      border: none;
      box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row">

    <!-- Sidebar -->
    <nav class="sidebar col-lg-2 col-md-3 p-3">
      <h4 class="mb-5">Central Monitoring - Cable</h4>
      <ul class="nav flex-column">
        <li class="nav-item mb-2">
          <a href="cable.php" class="nav-link">
            <i class="bi bi-speedometer2 me-2"></i> Dashboard
          </a>
        </li>
        <li class="nav-item mb-2">
          <a href="model.php" class="nav-link">
            <i class="bi bi-cpu me-2"></i> Model Number
          </a>
        </li>
        <li class="nav-item mb-2">
          <a href="drawing.php" class="nav-link active">
            <i class="bi bi-file-earmark-text me-2"></i> Drawing Number
          </a>
        </li>
        <li class="nav-item mb-2">
          <a href="production.php" class="nav-link">
            <i class="bi bi-clock-history me-2"></i> Production Time
          </a>
        </li>
        <li class="nav-item mb-2">
          <a href="line.php" class="nav-link">
            <i class="bi bi-bar-chart-steps me-2"></i> Line
          </a>
        </li>
      </ul>
    </nav>

    <!-- Main Content -->
    <main class="content-area col-lg-10 col-md-9">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Production Data</h2>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
          <i class="bi bi-plus-lg"></i> Add Line
        </button>
      </div>

      <!-- Card with Table -->
    <div class="card">
      <div class="card-body p-0">
        <table class="table table-hover table-bordered align-middle mb-0 table-pastel-green">
          <thead>
            <tr>
              <th>ID</th>
              <th>Line Number</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="lineTableBody">
            <!-- Dynamic rows here -->
          </tbody>
        </table>
      </div>
    </div>

    <!-- Add Line Modal -->
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1">
      <div class="modal-dialog">
        <form class="modal-content" id="addLineForm">
          <div class="modal-header">
            <h5 class="modal-title">Add Line</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="mb-3">
              <label for="Clinenumber" class="form-label">Line Number</label>
              <input type="text" class="form-control" id="Clinenumber" name="Clinenumber" required>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-success">Save</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Delete Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1">
      <div class="modal-dialog">
        <form class="modal-content" id="deleteLineForm">
          <div class="modal-header">
            <h5 class="modal-title">Delete Line</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <input type="hidden" id="deleteLineId" name="Cline_ID">
            <p>Are you sure you want to delete this line?</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-danger">Delete</button>
          </div>
        </form>
      </div>
    </div>

    </main>
  </div>
</div>

<script src="../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
  // Fetch and display lines
  function loadLines() {
    fetch('API/line_api.php?action=fetch')
      .then(res => res.json())
      .then(data => {
        const tbody = document.getElementById('lineTableBody');
        tbody.innerHTML = '';
        data.forEach(line => {
          const tr = document.createElement('tr');
          tr.innerHTML = `
            <td>${line.Cline_ID}</td>
            <td>${line.Clinenumber}</td>
            <td>
              <button class="btn btn-danger btn-sm delete-btn" data-id="${line.Cline_ID}"><i class="bi bi-trash"></i> Delete</button>
            </td>
          `;
          tbody.appendChild(tr);
        });
        // Attach delete event
        document.querySelectorAll('.delete-btn').forEach(btn => {
          btn.addEventListener('click', function() {
            document.getElementById('deleteLineId').value = this.getAttribute('data-id');
            new bootstrap.Modal(document.getElementById('deleteModal')).show();
          });
        });
      });
  }
  loadLines();

  // Add line
  document.getElementById('addLineForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('API/line_api.php?action=add', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(resp => {
      if (resp.success) {
        alert('Line added!');
        location.reload();
      } else {
        alert('Error: ' + resp.message);
      }
    });
  });

  // Delete line
  document.getElementById('deleteLineForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('API/line_api.php?action=delete', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(resp => {
      if (resp.success) {
        alert('Line deleted!');
        location.reload();
      } else {
        alert('Error: ' + resp.message);
      }
    });
  });
});
</script>
</body>
</html>
