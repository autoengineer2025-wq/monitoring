<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Production Time - Cable</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../node_modules/bootstrap-icons/font/bootstrap-icons.css">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
    }
    .sidebar {
      background-color: #fff;
      border-right: 1px solid #e3f0ff;
      box-shadow: 0 0 8px rgba(163, 201, 247, 0.08);
      min-height: 100vh;
    }
    .sidebar .nav-link {
      color: #222;
      font-weight: 500;
      border-radius: 8px;
      margin-bottom: 8px;
      transition: background 0.2s, color 0.2s;
    }
    .sidebar .nav-link:hover {
      background-color: #a3c9f7;
      color: #222; 
    }
    .sidebar h4 {
      font-weight: 700;
      text-align: center;
    }
    .content-area {
      padding: 2rem;
    }
    .table-pastel-green thead {
      background-color: #d4edda;
      color: #155724; 
    }
    .table-pastel-green tbody tr:hover {
      background-color: #e9f7ef;
    }
    .card {
      border-radius: 8px;
      border: none;
      box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row">

    <!-- Sidebar -->
    <nav class="sidebar col-lg-2 col-md-3 p-3">
      <h4 class="mb-5">Central Monitoring - Cable</h4>
      <ul class="nav flex-column">
        <li class="nav-item mb-2">
          <a href="cable.php" class="nav-link">
            <i class="bi bi-speedometer2 me-2"></i> Dashboard
          </a>
        </li>
        <li class="nav-item mb-2">
          <a href="model.php" class="nav-link">
            <i class="bi bi-cpu me-2"></i> Model Number
          </a>
        </li>
        <li class="nav-item mb-2">
          <a href="drawing.php" class="nav-link active">
            <i class="bi bi-file-earmark-text me-2"></i> Drawing Number
          </a>
        </li>
        <li class="nav-item mb-2">
          <a href="production.php" class="nav-link">
            <i class="bi bi-clock-history me-2"></i> Production Time  
          </a>
        </li>
        <li class="nav-item mb-2">
          <a href="line.php" class="nav-link">
            <i class="bi bi-bar-chart-steps me-2"></i> Line
          </a>
        </li>
      </ul>
    </nav>

    <!-- Main Content -->
    <main class="content-area col-lg-10 col-md-9">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Production Data</h2>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#productionModal">
          <i class="bi bi-plus-lg"></i> Add Production
        </button>
      </div>

      <!-- Card with Table -->
      <div class="card">
        <div class="card-body p-0">
          <table class="table table-hover table-bordered align-middle mb-0 table-pastel-green">
            <thead>
              <tr>
                    <th colspan="2" rowspan="2" style="text-align: center; vertical-align: middle;">
                      ID
                    </th>
                    <th colspan="2" rowspan="2" style="text-align: center; vertical-align: middle;">
                      Prodcution Name
                    </th>
                    <th colspan="2" rowspan="2" style="text-align: center; vertical-align: middle;">
                      Prodcution Hours
                    </th>                  
                    <th colspan="2" style="text-align: center; vertical-align: middle;">Prod Time 1</th>
                    <th colspan="2" style="text-align: center; vertical-align: middle;">Prod Time 2</th>
                    <th colspan="2" style="text-align: center; vertical-align: middle;">Prod Time 3</th>
                    <th colspan="2" style="text-align: center; vertical-align: middle;">Prod Time 4</th>
                    <th colspan="2" style="text-align: center; vertical-align: middle;">Prod Time 5</th>
                    <th rowspan="2" style="text-align: center; vertical-align: middle;">Action</th>
                </tr>
                <tr>
                    <th style="text-align: center; vertical-align: middle;">Start</th>
                    <th style="text-align: center; vertical-align: middle;">End</th>
                    <th style="text-align: center; vertical-align: middle;">Start</th>
                    <th style="text-align: center; vertical-align: middle;">End</th>
                    <th style="text-align: center; vertical-align: middle;">Start</th>
                    <th style="text-align: center; vertical-align: middle;">End</th>
                    <th style="text-align: center; vertical-align: middle;">Start</th>
                    <th style="text-align: center; vertical-align: middle;">End</th>
                    <th style="text-align: center; vertical-align: middle;"> Start</th>
                    <th style="text-align: center; vertical-align: middle;">End</th>
                </tr>
            </thead>
            <tbody id="productionTableBody">
              <!-- Dynamic rows will be inserted here -->
            </tbody>
          </table>
        </div>
      </div>
    </main>
  </div>
</div>

<!-- Add/Edit Modal -->
<div class="modal fade" id="productionModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" id="productionForm">
      <div class="modal-header">
        <h5 class="modal-title" id="productionModalLabel">Add Production</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="Cprod_ID" name="Cprod_ID">
        <div class="mb-3">
          <label for="productionName" class="form-label">Production Name</label>
          <input type="text" class="form-control" id="productionName" name="productionName" required>
        </div>
        <div class="mb-3">
          <label for="shiftSelect" class="form-label">Shift</label>
          <select class="form-select" id="shiftSelect" name="Fshift" required>
            <option value="Day">Day</option>
            <option value="Night">Night</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="productionHours" class="form-label">Hours</label>
          <input type="number" step="0.01" class="form-control" id="productionHours" name="productionHours" required>
        </div>
        <!-- Breaks -->
        <div class="row">
          <div class="col-6 mb-3">
            <label for="startTime1" class="form-label">Break 1 Start</label>
            <input type="time" class="form-control" id="startTime1" name="startTime1">
          </div>
          <div class="col-6 mb-3">
            <label for="endTime1" class="form-label">Break 1 End</label>
            <input type="time" class="form-control" id="endTime1" name="endTime1">
          </div>
          <div class="col-6 mb-3">
            <label for="startTime2" class="form-label">Break 2 Start</label>
            <input type="time" class="form-control" id="startTime2" name="startTime2">
          </div>
          <div class="col-6 mb-3">
            <label for="endTime2" class="form-label">Break 2 End</label>
            <input type="time" class="form-control" id="endTime2" name="endTime2">
          </div>
          <div class="col-6 mb-3">
            <label for="startTime3" class="form-label">Break 3 Start</label>
            <input type="time" class="form-control" id="startTime3" name="startTime3">
          </div>
          <div class="col-6 mb-3">
            <label for="endTime3" class="form-label">Break 3 End</label>
            <input type="time" class="form-control" id="endTime3" name="endTime3">
          </div>
          <div class="col-6 mb-3">
            <label for="startTime4" class="form-label">Break 4 Start</label>
            <input type="time" class="form-control" id="startTime4" name="startTime4">
          </div>
          <div class="col-6 mb-3">
            <label for="endTime4" class="form-label">Break 4 End</label>
            <input type="time" class="form-control" id="endTime4" name="endTime4">
          </div>
          <div class="col-6 mb-3">
            <label for="startTime5" class="form-label">Break 5 Start</label>
            <input type="time" class="form-control" id="startTime5" name="startTime5">
          </div>
          <div class="col-6 mb-3">
            <label for="endTime5" class="form-label">Break 5 End</label>
            <input type="time" class="form-control" id="endTime5" name="endTime5">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-success">Save</button>
      </div>
    </form>
  </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" id="deleteForm">
      <div class="modal-header">
        <h5 class="modal-title">Delete Production</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="deleteProdId" name="Cprod_ID">
        <p>Are you sure you want to delete this production record?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-danger">Delete</button>
      </div>
    </form>
  </div>
</div>

<script src="../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
  // Fetch and display productions
  function loadProductions() {
    fetch('API/prodtime_api.php?action=fetch')
      .then(res => res.json())
      .then(data => {
        const tbody = document.getElementById('productionTableBody');
        tbody.innerHTML = '';
        data.forEach(row => {
          tbody.innerHTML += `
            <tr>
              <td colspan="2" style="text-align: center; vertical-align: middle;">${row.Cprod_ID}</td>
              <td colspan="2" style="text-align: center; vertical-align: middle;">${row.Cprod_name}</td>
              <td colspan="2" style="text-align: center; vertical-align: middle;">${row.Cprod_hours}</td>
              <td style="text-align: center; vertical-align: middle;">${row.Cstart_Time1 || ''}</td>
              <td style="text-align: center; vertical-align: middle;">${row.Cend_Time1 || ''}</td>
              <td style="text-align: center; vertical-align: middle;">${row.Cstart_Time2 || ''}</td>
              <td style="text-align: center; vertical-align: middle;" >${row.Cend_Time2 || ''}</td>
              <td style="text-align: center; vertical-align: middle;">${row.Cstart_Time3 || ''}</td>
              <td style="text-align: center; vertical-align: middle;">${row.Cend_Time3 || ''}</td>
              <td style="text-align: center; vertical-align: middle;">${row.Cstart_Time4 || ''}</td>
              <td style="text-align: center; vertical-align: middle;">${row.Cend_Time4 || ''}</td>
              <td style="text-align: center; vertical-align: middle;">${row.Cstart_Time5 || ''}</td>
              <td style="text-align: center; vertical-align: middle;">${row.Cend_Time5 || ''}</td>
              <td>
                <button style="text-align: center; vertical-align: middle;" class="btn btn-primary btn-sm edit-btn" data-id="${row.Cprod_ID}"><i class="bi bi-pencil"></i></button>
                <button style="text-align: center; vertical-align: middle;" class="btn btn-danger btn-sm delete-btn" data-id="${row.Cprod_ID}"><i class="bi bi-trash"></i></button>
              </td>
            </tr>
          `;
        });

        // Edit button event
        document.querySelectorAll('.edit-btn').forEach(btn => {
          btn.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            const prod = data.find(r => r.Cprod_ID == id);
            document.getElementById('Cprod_ID').value = prod.Cprod_ID;
            document.getElementById('productionName').value = prod.Cprod_name;
            // Load shift from Fshift if present; else derive from name (fallback)
            const shiftSel = document.getElementById('shiftSelect');
            if (shiftSel) {
              if (typeof prod.Fshift !== 'undefined' && prod.Fshift) {
                shiftSel.value = (prod.Fshift === 'Night') ? 'Night' : 'Day';
              } else {
                const name = (prod.Cprod_name || '').toLowerCase();
                shiftSel.value = name.includes('night') ? 'Night' : 'Day';
              }
            }
            document.getElementById('productionHours').value = prod.Cprod_hours;
            document.getElementById('startTime1').value = prod.Cstart_Time1 || '';
            document.getElementById('endTime1').value = prod.Cend_Time1 || '';
            document.getElementById('startTime2').value = prod.Cstart_Time2 || '';
            document.getElementById('endTime2').value = prod.Cend_Time2 || '';
            document.getElementById('startTime3').value = prod.Cstart_Time3 || '';
            document.getElementById('endTime3').value = prod.Cend_Time3 || '';
            document.getElementById('startTime4').value = prod.Cstart_Time4 || '';
            document.getElementById('endTime4').value = prod.Cend_Time4 || '';
            document.getElementById('startTime5').value = prod.Cstart_Time5 || '';
            document.getElementById('endTime5').value = prod.Cend_Time5 || '';
            document.getElementById('productionModalLabel').textContent = 'Edit Production';
            new bootstrap.Modal(document.getElementById('productionModal')).show();
          });
        });

        // Delete button event
        document.querySelectorAll('.delete-btn').forEach(btn => {
          btn.addEventListener('click', function() {
            document.getElementById('deleteProdId').value = this.getAttribute('data-id');
            new bootstrap.Modal(document.getElementById('deleteModal')).show();
          });
        });
      });
  }
  loadProductions();

  // Open Add Modal
  document.querySelector('[data-bs-target="#productionModal"]').addEventListener('click', function() {
    document.getElementById('productionForm').reset();
    document.getElementById('Cprod_ID').value = '';
    // default new entries to Day shift
    const shiftSel = document.getElementById('shiftSelect');
    if (shiftSel) shiftSel.value = 'Day';
    document.getElementById('productionModalLabel').textContent = 'Add Production';
    new bootstrap.Modal(document.getElementById('productionModal')).show();
  });

  // Add/Edit submit
  document.getElementById('productionForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    // Optionally auto-compose name if left empty
    const name = (formData.get('productionName') || '').toString().trim();
    if (!name) {
      const sh = (formData.get('Fshift') === 'Night') ? 'Night Shift' : 'Day Shift';
      const hrs = (formData.get('productionHours') || '').toString().trim();
      if (hrs) formData.set('productionName', `${sh} (${hrs})`);
      else formData.set('productionName', sh);
    }
    let action = formData.get('Cprod_ID') ? 'edit' : 'add';
    fetch('API/prodtime_api.php?action=' + action, {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(resp => {
      if (resp.success) {
        alert('Saved!');
        location.reload();
      } else {
        alert('Error: ' + (resp.message || 'Failed'));
      }
    });
  });

  // Delete submit
  document.getElementById('deleteForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('API/prodtime_api.php?action=delete', {
      method: 'POST',
      body: formData
    })
    .then(res => res.json())
    .then(resp => {
      if (resp.success) {
        alert('Deleted!');
        location.reload();
      } else {
        alert('Error: ' + (resp.message || 'Failed'));
      }
    });
  });
});
</script>
</body>
</html>
