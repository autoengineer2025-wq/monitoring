<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include __DIR__ . '/../../database/init.php';

$action = $_GET['action'] ?? '';

if ($action === 'get_models') {
    $models = $database->select("cmodelnumber", ["Cmodel_ID", "Cmodel"]);
    echo json_encode($models);
    exit;
}

if ($action === 'create') {
    $model_ID   = $_POST['modelNumber'] ?? '';
    $drawingnum = $_POST['drawingNumber'] ?? '';
    $takttime   = $_POST['taktTime'] ?? '';
    $length     = $_POST['length'] ?? '';
    $qty        = $_POST['quantity'] ?? '';

    if (!$model_ID || !$drawingnum) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        exit;
    }

    try {
        $result = $database->insert("Cdrawingnumber", [
            "Cmodel_ID"   => $model_ID,
            "Cdrawingnum" => $drawingnum,
            "takttime"    => $takttime,
            "length"      => $length,
            "qty"         => $qty
        ]);
        if ($result->rowCount() > 0) {
            echo json_encode(['success' => true, 'id' => $database->id()]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Insert failed']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

if ($action === 'get_drawings') {
    // Join Cdrawingnumber and cmodelnumber to get model name
    $drawings = $database->select("Cdrawingnumber", [
        "[>]cmodelnumber" => ["Cmodel_ID" => "Cmodel_ID"]
    ], [
        "Cdrawingnumber.Cdrawing_ID",
        "Cdrawingnumber.Cmodel_ID",
        "cmodelnumber.Cmodel",
        "Cdrawingnumber.Cdrawingnum",
        "Cdrawingnumber.takttime",
        "Cdrawingnumber.length",
        "Cdrawingnumber.qty"
    ]);
    echo json_encode($drawings);
    exit;
}

if ($action === 'edit') {
    $id        = $_POST['Cdrawing_ID'] ?? '';
    $model_ID  = $_POST['modelNumber'] ?? '';
    $drawingnum= $_POST['drawingNumber'] ?? '';
    $takttime  = $_POST['taktTime'] ?? '';
    $length    = $_POST['length'] ?? '';
    $qty       = $_POST['quantity'] ?? '';

    if (!$id || !$model_ID || !$drawingnum) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        exit;
    }

    try {
        $result = $database->update("Cdrawingnumber", [
            "Cmodel_ID"   => $model_ID,
            "Cdrawingnum" => $drawingnum,
            "takttime"    => $takttime,
            "length"      => $length,
            "qty"         => $qty
        ], [
            "Cdrawing_ID" => $id
        ]);
        if ($result->rowCount() > 0) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Update failed or no changes']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

if ($action === 'delete') {
    $id = $_POST['Cdrawing_ID'] ?? '';
    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'Missing drawing ID']);
        exit;
    }
    try {
        $result = $database->delete("Cdrawingnumber", [
            "Cdrawing_ID" => $id
        ]);
        if ($result->rowCount() > 0) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Delete failed']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}