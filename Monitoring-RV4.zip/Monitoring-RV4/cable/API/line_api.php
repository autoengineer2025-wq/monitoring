<?php
    header('Content-type: application/json');
    include __DIR__ . '/../../database/init.php';
    
    $action = $_GET['action'];
    if ($action === 'fetch'){
        $lines = $database->select("cline", ['Cline_ID', 'Clinenumber']);
        echo json_encode($lines);
        exit;
    }
    
    if ($action === 'add'){
        $linenum = $_POST['Clinenumber'] ?? '';
        if (!$linenum){
            echo json_encode(['error' => 'Line number is required']);
            exit;
        }
        $result = $database->insert('cline', ['Clinenumber' => $linenum]);
        echo json_encode(['success' => (bool)$result, 'id' => $database->id()]);
        exit;
    }
    
    if ($action === 'delete'){
        $id = $_POST['Cline_ID'] ?? '';
        if (!$id){
            echo json_encode(['error' => 'Line ID is required']);
            exit;
        }
        $result = $database->delete("cline", ['Cline_ID' => $id]);
        echo json_encode(['success' => $result->rowCount() > 0]);
        exit;    
    }
    