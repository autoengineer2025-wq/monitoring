<?php
header('Content-Type: application/json');
include __DIR__ . '/../../database/init.php';

$action = $_GET['action'] ?? '';

if ($action === 'fetch') {
    $rows = $database->select("cproductiontime", "*");
    echo json_encode($rows);
    exit;
}

if ($action === 'add') {
    $data = [
        "Cprod_name"    => $_POST['productionName'] ?? '',
        "Cprod_hours"   => $_POST['productionHours'] ?? 0,
        "Cshift"        => $_POST['Cshift'] ?? 'Day',
        "Cstart_Time1"  => $_POST['startTime1'] ?? null,
        "Cend_Time1"    => $_POST['endTime1'] ?? null,
        "Cstart_Time2"  => $_POST['startTime2'] ?? null,
        "Cend_Time2"    => $_POST['endTime2'] ?? null,
        "Cstart_Time3"  => $_POST['startTime3'] ?? null,
        "Cend_Time3"    => $_POST['endTime3'] ?? null,
        "Cstart_Time4"  => $_POST['startTime4'] ?? null,
        "Cend_Time4"    => $_POST['endTime4'] ?? null,
        "Cstart_Time5"  => $_POST['startTime5'] ?? null,
        "Cend_Time5"    => $_POST['endTime5'] ?? null,
    ];
    $result = $database->insert("cproductiontime", $data);
    echo json_encode(['success' => (bool)$result, 'id' => $database->id()]);
    exit;
}

if ($action === 'edit') {
    $id = $_POST['Cprod_ID'] ?? '';
    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'Missing ID']);
        exit;
    }
    $data = [
        "Cprod_name"    => $_POST['productionName'] ?? '',
        "Cprod_hours"   => $_POST['productionHours'] ?? 0,
        "Cshift"        => $_POST['Cshift'] ?? 'Day',
        "Cstart_Time1"  => $_POST['startTime1'] ?? null,
        "Cend_Time1"    => $_POST['endTime1'] ?? null,
        "Cstart_Time2"  => $_POST['startTime2'] ?? null,
        "Cend_Time2"    => $_POST['endTime2'] ?? null,
        "Cstart_Time3"  => $_POST['startTime3'] ?? null,
        "Cend_Time3"    => $_POST['endTime3'] ?? null,
        "Cstart_Time4"  => $_POST['startTime4'] ?? null,
        "Cend_Time4"    => $_POST['endTime4'] ?? null,
        "Cstart_Time5"  => $_POST['startTime5'] ?? null,
        "Cend_Time5"    => $_POST['endTime5'] ?? null,
    ];
    $result = $database->update("cproductiontime", $data, ["Cprod_ID" => $id]);
    echo json_encode(['success' => $result->rowCount() > 0]);
    exit;
}

if ($action === 'delete') {
    $id = $_POST['Cprod_ID'] ?? '';
    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'Missing ID']);
        exit;
    }
    $result = $database->delete("cproductiontime", ["Cprod_ID" => $id]);
    echo json_encode(['success' => $result->rowCount() > 0]);
    exit;
}