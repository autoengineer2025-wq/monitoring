// Global variable for achievement chart
let achievementChart = null;

// Initialize Achievement Rate Doughnut Chart
function initializeAchievementChart() {
    const achievementCtx = document.getElementById('achievementChart');
    if (!achievementCtx) {
        console.log('Achievement chart canvas not found');
        return;
    }

    const chartData = getAchievementData();
    
    achievementChart = new Chart(achievementCtx, {
        type: 'doughnut',
        data: {
            labels: ['Achieved', 'Remaining'],
            datasets: [{
                data: chartData.data,
                backgroundColor: chartData.colors,
                borderWidth: 0
            }]
        },
        options: {
            cutout: '70%',
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 0 },
            transitions: { active: { animation: { duration: 0 } } },
            plugins: {
                legend: { 
                    display: false 
                },
                tooltip: { 
                    enabled: false 
                }
            }
        }
    });

    // Add percentage text in the center
    addAchievementPercentage(chartData.percentage);
}

// Get achievement data
function getAchievementData() {
    // Support read-only landing pages by computing from the table when needed
    if (window.READ_ONLY_VIEW) {
        // Actual = last RESULT Accu cell
        let actual = 0;
        try {
            const accuCells = document.querySelectorAll('.actual-accu-cell');
            if (accuCells && accuCells.length > 0) {
                actual = parseInt(accuCells[accuCells.length - 1].textContent) || 0;
            }
        } catch(e) {}

        // Target = calculateRealTimeTarget() if available, else last PLAN Accu, else plan_target input
        let target = 0;
        try {
            if (typeof calculateRealTimeTarget === 'function') {
                target = parseInt(calculateRealTimeTarget()) || 0;
            } else {
                const planAccuCells = document.querySelectorAll('.plan-accu-cell');
                if (planAccuCells && planAccuCells.length > 0) {
                    target = parseInt(planAccuCells[planAccuCells.length - 1].textContent) || 0;
                } else {
                    const planTargetInput = document.getElementById('plan_target');
                    if (planTargetInput) target = parseInt(planTargetInput.value) || 0;
                }
            }
        } catch(e) {}

        let percentage = 0;
        if (target > 0) percentage = Math.round((actual / target) * 100);

        const displayPercentage = Math.min(100, percentage);
        const remaining = 100 - displayPercentage;

        let colors = ['#E9EFEC', '#E9EFEC'];
        if (percentage >= 101) {
            colors = ['#007bff', '#E9EFEC'];
        } else if (percentage === 100) {
            colors = ['#28a745', '#E9EFEC'];
        } else if (percentage >= 95.5 && percentage < 100) {
            colors = ['#ffc107', '#E9EFEC'];
        } else if (percentage < 95.5) {
            colors = ['#dc3545', '#E9EFEC'];
        }

        return {
            data: [displayPercentage, remaining],
            colors: colors,
            percentage: percentage
        };
    }

    // Default behavior for interactive pages
    const actualElement = document.getElementById('total-actual');
    const targetElement = document.getElementById('real-time-target');

    const actual = parseInt(actualElement?.textContent) || 0;
    // Prefer live computation if available to avoid stale DOM values
    let target = 0;
    if (typeof calculateRealTimeTarget === 'function') {
        try { target = parseInt(calculateRealTimeTarget()) || 0; } catch(e) { target = 0; }
    }
    if (!target) {
        target = parseInt(targetElement?.textContent) || 0;
    }
    
    console.log('Achievement data - Actual:', actual, 'Target:', target);
    
    let percentage = 0;
    if (target > 0) {
        percentage = Math.round((actual / target) * 100);
    }
    
    const displayPercentage = Math.min(100, percentage);
    const remaining = 100 - displayPercentage;
    
    let colors = ['#E9EFEC', '#E9EFEC'];
    if (percentage >= 101) {
        colors = ['#007bff', '#E9EFEC']; 
    } else if (percentage === 100) {
        colors = ['#28a745', '#E9EFEC']; 
    } else if (percentage >= 95.5 && percentage < 100) {
        colors = ['#ffc107', '#E9EFEC']; 
    } else if (percentage < 95.5) {
        colors = ['#dc3545', '#E9EFEC']; 
    }
    
    return {
        data: [displayPercentage, remaining],
        colors: colors,
        percentage: percentage
    };
}

function addAchievementPercentage(percentage) {
    let percentageElement = document.getElementById('achievement-percentage');
    if (!percentageElement) {
        const canvas = document.getElementById('achievementChart');
        if (!canvas) return;
        
        const container = canvas.parentElement;
        container.style.position = 'relative';
        
        percentageElement = document.createElement('div');
        percentageElement.id = 'achievement-percentage';
        percentageElement.style.position = 'absolute';
        percentageElement.style.top = '50%';
        percentageElement.style.left = '50%';
        percentageElement.style.transform = 'translate(-50%, -50%)';
        percentageElement.style.fontSize = '80px';
        percentageElement.style.fontWeight = 'bold';
        percentageElement.style.color = '#333';
        percentageElement.style.pointerEvents = 'none';
        percentageElement.style.zIndex = '10';
        
        container.appendChild(percentageElement);
    }
    
    percentageElement.textContent = percentage + '%';
}

function updateAchievementChart() {
    if (!achievementChart) {
        console.log('Achievement chart not initialized');
        return;
    }
    
    console.log('Updating achievement chart');
    
    const chartData = getAchievementData();
    achievementChart.data.datasets[0].data = chartData.data;
    achievementChart.data.datasets[0].backgroundColor = chartData.colors;
    achievementChart.update('none');
    
    addAchievementPercentage(chartData.percentage);
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing achievement chart');
    initializeAchievementChart();
    
    // Real-time updates via BroadcastChannel (debounced)
    let _ach_update_pending = false;
    function scheduleAchievementUpdate(){
        if (_ach_update_pending) return;
        _ach_update_pending = true;
        setTimeout(function(){
            try { updateAchievementChart(); } finally { _ach_update_pending = false; }
        }, 300);
    }

    try {
        var _achChannel = new BroadcastChannel('monitoring-sync');
        _achChannel.addEventListener('message', function(ev){
            const msg = ev.data || {};
            if (msg.type === 'state_update') {
                // Only update if same line/shift to avoid unnecessary work
                const myLine = document.querySelector('input[name="line_id"]').value || '';
                const myShift = document.querySelector('input[name="shift"]').value || '';
                if (String(msg.line) === String(myLine) && String(msg.shift) === String(myShift)) {
                    scheduleAchievementUpdate();
                }
            }
        });
    } catch(e) {}
});

  $(function() {
    const accuSelect = $('#accuDrawing1');
    const accuInput = $('#planAccu1');
    const btnAdd = $('#btnAddAccu1');
    if (accuSelect.length && accuInput.length) {
      $.getJSON('../API/drawing_api.php?action=get_drawings', function(drawings) {
        accuSelect.empty();
        accuSelect.append('<option value="">Select drawing</option>');
        drawings.forEach(d => {
          const label = `${d.Cdrawingnum} (${d.qty ?? 0})`;
          accuSelect.append(`<option value="${d.Cdrawing_ID}" data-qty="${d.qty ?? 0}">${label}</option>`);
        });
      });

      function addSelectedQty() {
        const selected = accuSelect.find('option:selected');
        if (!selected.val()) return;
        const qty = parseInt(selected.data('qty')) || 0;
        const current = parseInt(accuInput.val()) || 0;
        accuInput.val(current + qty);
      }

      btnAdd.on('click', addSelectedQty);
      accuSelect.on('keydown', function(e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          addSelectedQty();
        }
      });
      accuInput.on('keydown', function(e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          addSelectedQty();
        }
      });
    }
  });

  // Make Output cells editable and handle Enter key
  $(function() {
    // Get drawing qty for the current production record
    let drawingQty = 0;
    const drawingId = $('input[name="drawing_id"]').val() || $('td:contains("Drawing")').next().text().trim();
    
    if (drawingId && drawingId !== '-') {
      $.getJSON('API/get_drawing.php', { drawing_number: drawingId }, function(data) {
        if (data && data.qty) {
          drawingQty = parseInt(data.qty) || 0;
        }
      });
    }

    // Make Output cells clickable and editable
    $('.output-cell').on('click', function() {
      const cell = $(this);
      const currentValue = cell.text().trim();
      const isEditable = cell.hasClass('editable');
      
      if (!isEditable) {
        cell.addClass('editable');
        const input = $('<input type="number" class="form-control form-control-sm" min="0" step="1">');
        input.val(currentValue === '-' ? '' : currentValue);
        
        input.on('keydown', function(e) {
          if (e.key === 'Enter') {
            e.preventDefault();
            const newValue = parseInt(input.val()) || 0;
            const addedValue = newValue + drawingQty;
            
            // Update the cell
            cell.text(addedValue);
            cell.removeClass('editable');
            input.remove();
            
            // Send to backend
            updateOutput(cell.data('break'), addedValue);
            
            // Update Accu and Difference
            updateAccuAndDifference();
          } else if (e.key === 'Escape') {
            e.preventDefault();
            cell.text(currentValue);
            cell.removeClass('editable');
            input.remove();
          }
        });
        
        input.on('blur', function() {
          cell.text(currentValue);
          cell.removeClass('editable');
          input.remove();
        });
        
        cell.html(input);
        input.focus();
      }
    });
  });

  function updateOutput(breakNumber, outputValue) {
    const data = {
      action: 'update_output',
      break_number: breakNumber,
      output_value: outputValue,
      production_date: $('input[name="production_date"]').val() || new Date().toISOString().split('T')[0],
      line_id: $('input[name="line_id"]').val() || '1',
      shift: $('input[name="shift"]').val() || 'Day'
    };
    
    $.post('API/update_output.php', data, function(response) {
      try {
        const result = typeof response === 'string' ? JSON.parse(response) : response;
        if (!result.success) {
          console.error('Update failed:', result.message);
        }
      } catch (e) {
        console.error('Invalid response:', response);
      }
    });
  }

  function updateAccuAndDifference() {
    // Calculate accumulated values
    let accuOutput = 0;
    $('.output-cell').each(function() {
      const value = parseInt($(this).text()) || 0;
      accuOutput += value;
    });
    
    // Update Accu cells
    $('.accu-output-cell').each(function(index) {
      let accu = 0;
      for (let i = 0; i <= index; i++) {
        const outputValue = parseInt($('.output-cell').eq(i).text()) || 0;
        accu += outputValue;
      }
      $(this).text(accu);
    });
    
    // Update Difference cells
    $('.difference-cell').each(function(index) {
      const planValue = parseInt($('.plan-output-cell').eq(index).text()) || 0;
      const actualValue = parseInt($('.output-cell').eq(index).text()) || 0;
      const difference = actualValue - planValue;
      $(this).text(difference);
    });
  }

$(document).ready(function() {
    // Listen for Enter or Space on the output cells
    $(document).on('keydown', '.accu-output-cell', function(e) {
        if (e.key === "Enter" || e.key === " " || e.keyCode === 13 || e.keyCode === 32) {
            e.preventDefault(); // prevent default scroll for space
            let $cell = $(this);
            let breakNum = $cell.data('break');
            let drawingId = $cell.data('drawing-id');

            // Fetch the qty from drawingnumber table (drawingList)
            const drawing = drawingList.find(d => d.Cdrawing_ID == drawingId);
            const qty = drawing ? parseInt(drawing.qty, 10) : 0;

            // Update cell value immediately
            $cell.text(qty);

            // Send to backend
            $.post('API/update_qty.php', {
                Cdrawing_ID: drawingId,
                breakNum: breakNum,
                actual1: qty,
                record_id: $('#recordId').val() // hidden input containing current record_id
            }, function(res) {
                let response = typeof res === 'string' ? JSON.parse(res) : res;
                if (response.success) {
                    console.log(`Saved actual1=${qty} for break ${breakNum}, drawing ${drawingId}`);
                } else {
                    alert(response.message || 'Failed to save actual output.');
                }
            });
        }
    });
});
