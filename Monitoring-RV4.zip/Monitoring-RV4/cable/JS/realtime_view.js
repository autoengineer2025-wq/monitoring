(function(){
  function toInt(v){ const n = parseInt(v, 10); return isNaN(n) ? 0 : n; }
  function textOf(el){ return (el?.textContent || '').trim(); }
  function setKpiValue(labelText, value){
    try {
      const norm = (s)=> String(s||'').trim().toLowerCase();
      const target = norm(labelText);
      // Find label elements that contain the KPI title
      const labelEls = Array.from(document.querySelectorAll('.card .fs-3, .card .card-header-small, .card .card-title, .card .fs-3.text-muted'));
      for (const lbl of labelEls){
        const t = norm(lbl.textContent);
        if (t === target){
          // Try to find a bold value element in the same card
          const card = lbl.closest('.card');
          if (!card) continue;
          let valEl = card.querySelector('.fw-bold');
          if (!valEl) {
            // Fallback to any second div inside card
            const divs = card.querySelectorAll('div');
            if (divs.length >= 2) valEl = divs[1];
          }
          if (valEl) {
            const num = (typeof value === 'number') ? value : toInt(value);
            valEl.textContent = Number(num).toLocaleString();
            return; // done
          }
        }
      }
    } catch(e) { /* ignore */ }
  }
  let __lastSnapshotAt = 0;
  const SNAPSHOT_THROTTLE_MS = 15000; // throttle actual snapshot calls to 15s to avoid overload

  function refreshView(){
    const date = document.querySelector('input[name="production_date"]').value || new Date().toISOString().split('T')[0];
    const line = document.querySelector('input[name="line_id"]').value || '1';
    const shift = document.querySelector('input[name="shift"]').value || 'Day Shift';

    const url = `../API/record_api.php?action=get_latest&production_date=${encodeURIComponent(date)}&line_id=${encodeURIComponent(line)}&shift=${encodeURIComponent(shift)}&strict=1`;

    fetch(url)
      .then(r => r.json())
      .then(res => {
        if (!res || !res.success || !res.data) return;
        const d = res.data;

        // expose server remarks for the auto-snapshot checker
        try { window.__serverRemarks = res.remarks || {}; } catch(e) {}
        try { window.__currentRecordId = d.record_id || document.getElementById('recordId')?.value || ''; } catch(e) {}

        // Update top totals if present
        const totalActualEl = document.getElementById('total-actual');
        const targetEl = document.getElementById('real-time-target');
        if (totalActualEl) totalActualEl.textContent = toInt(d.total_actual);

        // Default to server-provided target
        let targetVal = toInt(d.target);
        // If shift is over, clamp target to plan
        try {
          const planInput = document.getElementById('plan_target');
          const planVal = planInput ? parseInt(planInput.value, 10) || 0 : 0;
          const prodDate = (document.querySelector('input[name="production_date"]')?.value || '').trim();
          const shiftLabel = (document.querySelector('input[name="shift"]')?.value || '').toLowerCase();
          if (prodDate && planVal > 0) {
            const now = new Date();
            let cutoff;
            if (shiftLabel.includes('night')) {
              // 06:00 next day
              cutoff = new Date(prodDate + 'T06:00:00');
              cutoff.setDate(cutoff.getDate() + 1);
            } else {
              // 18:00 same day
              cutoff = new Date(prodDate + 'T18:00:00');
            }
            if (cutoff && now >= cutoff) {
              targetVal = planVal;
            }
          }
        } catch(e) {}
        if (targetEl) targetEl.textContent = targetVal;

        // Update per-break outputs in table
        const tbody = document.querySelector('table.analytics-table tbody');
        if (!tbody) return;
        const rows = tbody.querySelectorAll('tr');
        let accuActual = 0;
        let accuReject = 0;
        rows.forEach((row, idx) => {
          const breakNum = idx + 1;
          const actualVal = toInt(d[`actual${breakNum}`]);

          // Output cell
          const outCell = row.querySelector(`.output-cell[data-break="${breakNum}"] div`);
          if (outCell) outCell.textContent = actualVal;

          accuActual += actualVal;

          // Accumulated actual
          const accuActualCell = row.querySelector('.actual-accu-cell');
          if (accuActualCell) accuActualCell.textContent = accuActual;

          // Difference per break (actual - plan)
          const planCell = row.querySelector('.plan-output-cell');
          const diffCell = row.querySelector('.difference-cell');
          const planVal = toInt(planCell ? textOf(planCell) : '0');
          const diffVal = actualVal - planVal;
          if (diffCell) diffCell.textContent = (diffVal === 0 ? '-' : diffVal);

          // Accu difference (accuActual - accuPlan)
          const accuPlanCell = row.querySelector('.plan-accu-cell');
          const diffAccuCell = row.querySelector('.diff-accu-cell');
          const accuPlanVal = toInt(accuPlanCell ? textOf(accuPlanCell) : '0');
          const diffAccuVal = accuActual - accuPlanVal;
          if (diffAccuCell) diffAccuCell.textContent = (diffAccuVal === 0 ? '-' : diffAccuVal);

          // Rejects update
          if (res.rejects) {
            const rQty = toInt(res.rejects[String(breakNum)] || 0);
            const rejInput = row.querySelector('.reject-qty-cell input.reject-input');
            if (rejInput) rejInput.value = rQty;
            accuReject += rQty;
            const rejAccuCell = row.querySelector('.reject-accu-cell');
            if (rejAccuCell) rejAccuCell.textContent = accuReject;
          }
        });

        // Update achievement chart if available
        if (typeof updateAchievementChart === 'function') {
          try { updateAchievementChart(); } catch (e) {}
        }
        // Apply remarks (classification/reason/countermeasure) from server on read-only pages
        try {
          const remarks = window.__serverRemarks || {};
          for (let i=1;i<=5;i++){
            const srv = remarks[i];
            if (!srv) continue;
            const row = document.querySelector(`.output-cell[data-break="${i}"]`)?.closest('tr');
            if (!row) continue;
            const cls = row.querySelector('.remark-classification');
            const rsn = row.querySelector('.remark-reason');
            const ctr = row.querySelector('.remark-countermeasure');
            if (cls && !textOf(cls)) cls.textContent = (srv.classification || '').toString();
            if (rsn && !textOf(rsn)) rsn.textContent = (srv.reason || '').toString();
            if (ctr && !textOf(ctr)) ctr.textContent = (srv.countermeasure || '').toString();
          }
        } catch(e) {}

        try {
          const rmap = res.rejects || {};
          let rAccu = 0;
          for (let i=1;i<=5;i++){
            const qty = toInt(rmap[String(i)] || 0);
            const row = document.querySelector(`.output-cell[data-break="${i}"]`)?.closest('tr');
            if (!row) continue;
            const qtyCell = row.querySelector('.reject-qty-cell');
            if (qtyCell) qtyCell.textContent = String(qty);
            rAccu += qty;
            const rejAccCell = row.querySelector('.reject-accu-cell');
            if (rejAccCell) rejAccCell.textContent = String(rAccu);
          }
        } catch(e) {}

        try {
          if (typeof _monitoringChannel !== 'undefined' && _monitoringChannel) {
            _monitoringChannel.postMessage({ type: 'state_update', line: line, shift: shift, record_id: d.record_id || '', total_actual: d.total_actual || 0, actuals: [d.actual1||0,d.actual2||0,d.actual3||0,d.actual4||0,d.actual5||0], rejects: res.rejects || {}, start_times: [d.Fstart_Time1||'',d.Fstart_Time2||'',d.Fstart_Time3||'',d.Fstart_Time4||'',d.Fstart_Time5||''], end_times: [d.Fend_Time1||'',d.Fend_Time2||'',d.Fend_Time3||'',d.Fend_Time4||'',d.Fend_Time5||''] });
          }
        } catch(e){}
        try {
          const planAccuCells = tbody.querySelectorAll('.plan-accu-cell');
          let totalPlan = planAccuCells.length ? toInt(planAccuCells[planAccuCells.length - 1].textContent) : 0;
          if (!totalPlan) {
            const planInput = document.getElementById('plan_target');
            const planVal = planInput ? parseInt(planInput.value, 10) || 0 : 0;
            if (planVal > 0) totalPlan = planVal;
          }
          const totalResult = accuActual;
          let totalReject = 0;
          if (res.rejects && typeof res.rejects === 'object') {
            for (const k in res.rejects) { if (Object.hasOwn(res.rejects, k)) totalReject += toInt(res.rejects[k]); }
          } else {
            const rejAccCells = tbody.querySelectorAll('.reject-accu-cell');
            totalReject = rejAccCells.length ? toInt(rejAccCells[rejAccCells.length - 1].textContent) : 0;
          }
          const totalDifference = totalResult - totalPlan;

          setKpiValue('total plan', totalPlan);
          setKpiValue('total result', totalResult);
          setKpiValue('total difference', totalDifference);
          setKpiValue('total reject', totalReject);
        } catch(e) {}

      })
      .catch(() => {});
  }

  function maybeAutoSnapshot(){
    try {
      const remarks = window.__serverRemarks || {};
      if (!remarks || Object.keys(remarks).length === 0) return;

      // detect if table is missing remarks while server has them
      let mismatch = false;
      for (let i=1;i<=5;i++){
        const srv = remarks[i];
        if (!srv) continue;
        const hasSrv = (srv.classification||srv.reason||srv.countermeasure||'').toString().trim() !== '';
        if (!hasSrv) continue;
        const row = document.querySelector(`.output-cell[data-break="${i}"]`)?.closest('tr');
        if (!row) continue;
        const cls = row.querySelector('.remark-classification');
        const rsn = row.querySelector('.remark-reason');
        const ctr = row.querySelector('.remark-countermeasure');
        const clsTxt = textOf(cls);
        const rsnTxt = textOf(rsn);
        const ctrTxt = textOf(ctr);
        if (!clsTxt && !rsnTxt && !ctrTxt) { mismatch = true; break; }
      }

      if (!mismatch) return;
      const now = Date.now();
      if (now - __lastSnapshotAt < SNAPSHOT_THROTTLE_MS) return;
      __lastSnapshotAt = now;

      const recordId = window.__currentRecordId || document.getElementById('recordId')?.value || '';
      if (!recordId) return;

      // fire snapshot silently
      $.post('../API/save_break_snapshot.php', { record_id: recordId })
        .always(function(){ /* no-op; next refresh will reflect */ });
    } catch(e) {}
  }

  document.addEventListener('DOMContentLoaded', function(){
    // Initial run and then poll every 0.1 seconds
    refreshView();
    setInterval(refreshView, 100);
    setInterval(maybeAutoSnapshot, 100);
    window.addEventListener('realtime_shift_changed', refreshView);
    try {
      var _monitoringChannel = new BroadcastChannel('monitoring-sync');
      _monitoringChannel.addEventListener('message', function(ev){
        try {
          const msg = ev.data || {};
          if (msg.type === 'state_update') {
            // Only apply if same line & shift to avoid cross-line interference
            const myLine = document.querySelector('input[name="line_id"]').value || '';
            const myShift = document.querySelector('input[name="shift"]').value || '';
            if (String(msg.line) !== String(myLine) || String(msg.shift) !== String(myShift)) return;

            // Apply actuals and recompute differences immediately
            if (Array.isArray(msg.actuals)){
              let accuActual = 0;
              for (let i=0;i<msg.actuals.length;i++){
                const bn = i+1;
                const val = parseInt(msg.actuals[i]) || 0;
                const row = document.querySelector(`.output-cell[data-break="${bn}"]`)?.closest('tr');
                // Update output
                const outDiv = document.querySelector(`.output-cell[data-break="${bn}"] div`);
                if (outDiv) outDiv.textContent = val;

                // Update accumulated actual
                accuActual += val;
                if (row) {
                  const accuCell = row.querySelector('.actual-accu-cell');
                  if (accuCell) accuCell.textContent = accuActual;
                }

                // Recompute per-break difference: actual - plan
                if (row) {
                  const planCell = row.querySelector('.plan-output-cell');
                  const diffCell = row.querySelector('.difference-cell');
                  const planVal = parseInt((planCell?.textContent||'').trim(),10) || 0;
                  const diffVal = val - planVal;
                  if (diffCell) diffCell.textContent = (diffVal === 0 ? '-' : diffVal);

                  // Recompute accumulated difference: accuActual - accuPlan
                  const accuPlanCell = row.querySelector('.plan-accu-cell');
                  const diffAccuCell = row.querySelector('.diff-accu-cell');
                  const accuPlanVal = parseInt((accuPlanCell?.textContent||'').trim(),10) || 0;
                  const diffAccuVal = accuActual - accuPlanVal;
                  if (diffAccuCell) diffAccuCell.textContent = (diffAccuVal === 0 ? '-' : diffAccuVal);
                }
              }
              const totalEl = document.getElementById('total-actual'); if (totalEl) totalEl.textContent = accuActual;
            }

            // Apply rejects
            if (msg.rejects && typeof msg.rejects === 'object'){
              let rAccu = 0;
              for (const k of Object.keys(msg.rejects).sort()){
                const bn = parseInt(k,10);
                const v = parseInt(msg.rejects[k]) || 0;
                const inp = document.querySelector(`.reject-input[data-break="${bn}"]`);
                if (inp) inp.value = v;
                rAccu += v;
                const row = document.querySelector(`.reject-input[data-break="${bn}"]`)?.closest('tr');
                if (row){ const rejAcc = row.querySelector('.reject-accu-cell'); if (rejAcc) rejAcc.textContent = rAccu; }
              }
            }

            // Apply start/end times if present
            if (Array.isArray(msg.start_times)){
              for (let i=0;i<msg.start_times.length;i++){
                const s = msg.start_times[i] || '';
                const e = (msg.end_times && msg.end_times[i]) ? msg.end_times[i] : '';
                const si = document.getElementById(`start_time_${i+1}`);
                const ei = document.getElementById(`end_time_${i+1}`);
                if (si) si.value = s; if (ei) ei.value = e;
              }
              // update computed target using existing function if available
              if (typeof updateRealTimeTarget === 'function') {
                try { updateRealTimeTarget(); } catch(e){}
              }
            }
          }
        } catch(e){}
      });
    } catch(e) {}
  });
})();
