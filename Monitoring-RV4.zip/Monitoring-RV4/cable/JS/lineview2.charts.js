
(function(){
  // Render 6 charts: Daily (current month) and Past 3 Months
  let charts = {
    dailyOutput: null,
    dailyOpRate: null,
    dailyYield: null,
    m3Output: null,
    m3OpRate: null,
    m3Yield: null,
    lineReject: null,
    achievement: null
  };

  // Global plugin to draw centered text inside doughnut charts
  const centerTextPlugin = {
    id: 'centerTextPluginGlobal',
    afterDraw(chart) {
      try {
        const opts = chart?.options?.plugins?.centerText;
        if (!opts || !opts.text) return;
        const meta = chart.getDatasetMeta(0);
        if (!meta || !meta.data || meta.data.length === 0) return;
        const el = meta.data[0];
        const { ctx } = chart;
        const x = el.x;
        const y = el.y;
        const area = chart.chartArea || { width: 220, height: 220 };
        const base = Math.min(area.width, area.height);
        const fontSize = Math.max(12, Math.floor(base * 0.18));
        ctx.save();
        ctx.fillStyle = opts.color || '#212529';
        ctx.font = `${opts.fontWeight || 'bold'} ${fontSize}px ${opts.fontFamily || 'sans-serif'}`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(opts.text, x, y);
        ctx.restore();
      } catch(e) {}
    }
  };
  try { Chart.register(centerTextPlugin); } catch(e) {}

  // ACHIEVEMENT RATE CHART
  function renderAchievementRate() {
    const canvas = exists('achievementChart');
    if (!canvas) return;

    let planAccu = 0;
    let actualAccu = 0;
    try {
      const planAccuCells = document.querySelectorAll('.plan-accu-cell');
      const actualAccuCells = document.querySelectorAll('.actual-accu-cell');
      if (planAccuCells.length > 0) {
        planAccu = parseInt((planAccuCells[planAccuCells.length - 1].textContent || '0').trim(), 10) || 0;
      }
      if (actualAccuCells.length > 0) {
        actualAccu = parseInt((actualAccuCells[actualAccuCells.length - 1].textContent || '0').trim(), 10) || 0;
      }
      if (!planAccu) {
        const planInput = document.getElementById('plan_target');
        const planVal = planInput ? parseInt(planInput.value, 10) || 0 : 0;
        if (planVal > 0) planAccu = planVal;
      }
    } catch(e) {}

    const rawRate = planAccu > 0 ? (actualAccu / planAccu) * 100 : 0;
    const clamped = Math.min(200, Math.max(0, Math.round(rawRate * 10) / 10)); 

    const data = {
      labels: ['Achieved %', 'Remaining %'],
      datasets: [{
        data: [rawRate, Math.max(0, 100 - rawRate)],
        backgroundColor: [
          clamped < 96 ? 'rgba(220,53,69,0.9)' : (clamped < 100 ? 'rgba(255,193,7,0.9)' : (clamped === 100 ? 'rgba(25,135,84,0.9)' : 'rgba(13,110,253,0.9)')),
          'rgba(233,239,236,0.9)'
        ],
        borderWidth: 1
      }]
    };

    try {
      const parent = canvas.parentElement;
      if (parent) {
        parent.style.minHeight = '300px';
        parent.style.height = '300px';
      }
      canvas.style.width = '100%';
      canvas.style.height = '100%';
    } catch(e) {}

    if (charts.achievement) {
      charts.achievement.data = data;
      if (charts.achievement.options && charts.achievement.options.plugins) {
        charts.achievement.options.plugins.centerText = { text: `${clamped.toFixed(1)}%` };
      }
      charts.achievement.update('none');
    } else {
      charts.achievement = new Chart(canvas, {
        type: 'doughnut',
        data,
        options: {
          responsive: true,
          maintainAspectRatio: false,
          animation: { duration: 0 },
          transitions: { active: { animation: { duration: 0 } } },
          plugins: {
            legend: { display: false },
            centerText: { text: `${clamped.toFixed(1)}%` }
          },
          cutout: '60%'
        },
        plugins: []
      });
    }
  }

  const valueLabelPlugin = {
    id: 'valueLabelPluginGlobal',
    afterDatasetsDraw(chart) {
      try {
        const cfg = chart?.options?.plugins?.valueLabels;
        if (!cfg || cfg.enabled === false || !Array.isArray(cfg.targets)) return;
        const { ctx } = chart;
        const datasets = chart.data.datasets || [];
        ctx.save();
        for (const t of cfg.targets) {
          const dsIndex = typeof t.index === 'number' ? t.index : 0;
          const meta = chart.getDatasetMeta(dsIndex);
          if (!meta || !meta.data) continue;
          const decimals = typeof t.decimals === 'number' ? t.decimals : 0;
          const orientation = t.orientation || (t.diagonal ? 'diagonal' : '');
          const prefix = t.prefix || '';
          const suffix = t.suffix || '';
          const fontSize = t.fontSize || 12;
          const fontWeight = t.fontWeight || '700';
          const color = t.color || '#111';
          meta.data.forEach((el, i) => {
            const raw = datasets[dsIndex] && datasets[dsIndex].data ? datasets[dsIndex].data[i] : undefined;
            const val = typeof raw === 'number' ? raw : parseFloat(raw);
            if (!isFinite(val)) return;
            const pos = (typeof el.tooltipPosition === 'function') ? el.tooltipPosition() : { x: el.x, y: el.y };
            const label = `${prefix}${val.toFixed(decimals)}${suffix}`;
            let x = pos.x;
            let y = pos.y - 8;
            ctx.save();
            ctx.textAlign = (orientation === 'diagonal' || orientation === 'vertical') ? 'left' : 'center';
            ctx.textBaseline = 'bottom';
            if (orientation === 'diagonal') {
              ctx.translate(x + 6, y);
              ctx.rotate(-Math.PI/4);
            } else if (orientation === 'vertical') {
              ctx.translate(x, y);
              ctx.rotate(-Math.PI/2);
            } else {
              ctx.translate(x, y);
            }
            ctx.font = `${fontWeight} ${fontSize}px sans-serif`;
            ctx.lineWidth = 3;
            ctx.strokeStyle = 'rgba(255,255,255,0.9)';
            ctx.strokeText(label, 0, 0);
            ctx.fillStyle = color;
            ctx.fillText(label, 0, 0);
            ctx.restore();
          });
        }
        ctx.restore();
      } catch(e) {}
    }
  };
  try { Chart.register(valueLabelPlugin); } catch(e) {}

  function qs(sel){ return document.querySelector(sel); }
  function exists(id){ return document.getElementById(id); }

  async function fetchChartData(viewType) {
    const lineIdEl = document.querySelector('input[name="line_id"]');
    const shiftEl = document.querySelector('input[name="shift"]');
    const lineId = lineIdEl ? lineIdEl.value : '';
    const shift = shiftEl ? shiftEl.value : '';

    // From VIEW/ to API/ is one level up
    const url = `../API/get_chart_data.php?view=${encodeURIComponent(viewType)}&line=${encodeURIComponent(lineId)}&shift=${encodeURIComponent(shift)}`;
    const resp = await fetch(url);
    const result = await resp.json();
    if (result && result.success) {
      return {
        labels: result.data.map(it => it.label),
        outputData: result.data.map(it => it.output),
        operationRate: result.data.map(it => it.operationRate),
        yieldRate: result.data.map(it => it.yieldRate),
        planDaily: result.data.map(it => (it.plan != null ? it.plan : (it.planTarget != null ? it.planTarget : 0))),
        title: result.title
      };
    }
    console.warn('Chart data (view2) fallback used:', result && result.error);
    return generateFallbackData(viewType);
  }

  function buildBar(ctx, label, data, options) {
    return new Chart(ctx, {
      type: 'bar',
      data: { labels: data.labels, datasets: [{ label, data: data.values, backgroundColor: options.bg || 'rgba(54,162,235,0.7)', borderColor: options.border || 'rgba(54,162,235,1)', borderWidth: 1 }] },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 0 },
        transitions: { active: { animation: { duration: 0 } } },
        plugins: { 
          title: { display: true, text: options.title || '' }, 
          legend: { display: false },
          valueLabels: options.valueLabels || { enabled: false }
        },
        scales: options.scales || {}
      }
    });
  }


  //LINE REJECTION RATE CHART
  function renderLineRejectionRate() {
    const canvas = exists('lineRejectionChart');
    if (!canvas) return;

    // Compute from table when in read-only view
    let actualAccu = 0;
    let rejectAccu = 0;
    try {
      const actualCells = document.querySelectorAll('.actual-accu-cell');
      const rejectCells = document.querySelectorAll('.reject-accu-cell');
      if (actualCells.length > 0) {
        const raw = (actualCells[actualCells.length - 1].textContent || '0').trim().replace(/,/g, '');
        actualAccu = parseInt(raw, 10) || 0;
      }
      if (rejectCells.length > 0) {
        const raw = (rejectCells[rejectCells.length - 1].textContent || '0').trim().replace(/,/g, '');
        rejectAccu = parseInt(raw, 10) || 0;
      }
    } catch(e) {}

    // Fallback to hidden totals if table values are not present or zero
    try {
      if (!actualAccu) {
        const totalResEl = document.getElementById('total_result_accu');
        if (totalResEl) {
          const v = String(totalResEl.value || '').trim().replace(/,/g, '');
          const n = parseInt(v, 10);
          if (isFinite(n)) actualAccu = n;
        }
      }
      if (!rejectAccu) {
        const totalRejEl = document.getElementById('total_reject_accu');
        if (totalRejEl) {
          const v = String(totalRejEl.value || '').trim().replace(/,/g, '');
          const n = parseInt(v, 10);
          if (isFinite(n)) rejectAccu = n;
        }
      }
    } catch(e) {}

   const totalActual = actualAccu;
    let rateRaw = totalActual > 0 ? (rejectAccu / totalActual) * 100 : 0;
    if (!isFinite(rateRaw) || rateRaw > 100 || rejectAccu > totalActual) {
      const denom = (totalActual + rejectAccu);
      rateRaw = denom > 0 ? (rejectAccu / denom) * 100 : 0;
    }
    const rate = Math.min(100, Math.max(0, Math.round(rateRaw * 10) / 10)); 
    try {
      const labelEl = document.getElementById('lineRejectionValue');
      if (labelEl) labelEl.textContent = `${rate.toFixed(1)}%`;
    } catch(e) {}

    const data = {
      labels: ['Reject %', 'OK %'],
      datasets: [{
        data: [rateRaw, 100 - rateRaw],
        backgroundColor: [
          rate >= 5 ? 'rgba(220,53,69,0.9)' : 'rgba(255,193,7,0.9)',
          'rgba(233,239,236,0.9)'
        ],
        borderWidth: 1
      }]
    };

    try {
      const parent = canvas.parentElement;
      if (parent) {
        if (!parent.style.minHeight) parent.style.minHeight = '300px';
        if (!parent.style.height) parent.style.height = '300px';
        if (getComputedStyle(parent).display === 'inline') {
          parent.style.display = 'block';
        }
      }
      if (!canvas.style.width) canvas.style.width = '100%';
      if (!canvas.style.height) canvas.style.height = '100%';
      // Fallback if computed height is still 0 (hidden due to layout)
      const rect = canvas.getBoundingClientRect();
      if (rect.height === 0) {
        canvas.width = 300;
        canvas.height = 300;
      }
    } catch(e) {}

    if (charts.lineReject) {
      charts.lineReject.data = data;
      try {
        if (charts.lineReject.options && charts.lineReject.options.plugins) {
          if (charts.lineReject.options.plugins.title) {
            charts.lineReject.options.plugins.title.text = `Line Rejection Rate: ${rate.toFixed(1)}%`;
          }
          charts.lineReject.options.plugins.centerText = { text: `${rate.toFixed(1)}%` };
        }
      } catch(e) {}
      charts.lineReject.update('none');
    } else {
      charts.lineReject = new Chart(canvas, {
        type: 'doughnut',
        data,
        options: {
          responsive: true,
          maintainAspectRatio: false,
          animation: { duration: 0 },
          transitions: { active: { animation: { duration: 0 } } },
          plugins: {
            legend: { display: false },
            title: { display: true, text: `Line Rejection Rate: ${rate.toFixed(1)}%` },
            centerText: { text: `${rate.toFixed(1)}%` }
          },
          cutout: '60%'
        },
        plugins: []
      });
    }
  }

  function hasDataChanged(oldData, newData) {
    if (!oldData) return true;
    return (
      JSON.stringify(oldData.labels) !== JSON.stringify(newData.labels) ||
      JSON.stringify(oldData.values) !== JSON.stringify(newData.values) ||
      oldData.title !== newData.title
    );
  }

  async function renderDaily() {
    const data = await fetchChartData('daily');
    // Daily Output
    const c1 = exists('monthlyDailyOutputChart');
    if (c1) {
      const labels = data.labels;
      const planDaily = Array.isArray(data.planDaily) ? data.planDaily : new Array(labels.length).fill(0);
      const actualDaily = data.outputData || new Array(labels.length).fill(0);

      if (charts.dailyOutput) {
        charts.dailyOutput.data.labels = labels;
        if (charts.dailyOutput.data.datasets.length < 2) {
          charts.dailyOutput.data.datasets = [
            { type: 'bar', label: 'Plan Target', data: planDaily, backgroundColor: 'rgba(13,110,253,0.35)', borderColor: 'rgba(13,110,253,0.9)', borderWidth: 1 },
            { type: 'line', label: 'Actual Output', data: actualDaily, borderColor: 'rgb(241, 78, 78)', backgroundColor: 'rgba(25,135,84,0.2)', borderWidth: 2, pointRadius: 2, tension: 0.2 }
          ];
        } else {
          charts.dailyOutput.data.datasets[0].data = planDaily;
          charts.dailyOutput.data.datasets[1].data = actualDaily;
        }
        // Hide title for Daily Output
        if (charts.dailyOutput.options && charts.dailyOutput.options.plugins && charts.dailyOutput.options.plugins.title) {
          charts.dailyOutput.options.plugins.title.display = false;
        }
        // Enable diagonal value labels for Actual Output (dataset index 1)
        if (charts.dailyOutput.options.plugins) {
          charts.dailyOutput.options.plugins.valueLabels = {
            enabled: true,
            targets: [{ index: 1, decimals: 0, orientation: 'diagonal' }]
          };
        }
        charts.dailyOutput.update('none');
      } else {
        charts.dailyOutput = new Chart(c1, {
          type: 'bar',
          data: {
            labels: labels,
            datasets: [
              { type: 'bar', label: 'Plan Target', data: planDaily, backgroundColor: 'rgba(13,110,253,0.35)', borderColor: 'rgba(13,110,253,0.9)', borderWidth: 1 },
              { type: 'line', label: 'Actual Output', data: actualDaily, borderColor: 'rgb(241, 78, 78)', backgroundColor: 'rgba(126, 20, 20, 0.2)', borderWidth: 2, pointRadius: 2, tension: 0.2 }
            ]
          },
          options: {  
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 0 },
            transitions: { active: { animation: { duration: 0 } } },
            plugins: {
              title: { display: false, text: '' },
              legend: { display: true },
              valueLabels: { enabled: true, targets: [{ index: 1, decimals: 0, orientation: 'diagonal' }] },
              tooltip: {
                callbacks: {
                  afterBody: (items) => {
                    if (!items || items.length === 0) return '';
                    const idx = items[0].dataIndex;
                    const plan = planDaily[idx] || 0;
                    const actual = actualDaily[idx] || 0;
                    return `Plan: ${plan.toLocaleString()}\nOutput: ${actual.toLocaleString()}`;
                  }
                }
              }
            },
            scales: {
              y: { beginAtZero: true }
            }
          }
        });
      }
    }
    // Daily Operation Rate
    const c2 = exists('opRateDailyChart');
    if (c2) {
      const dataset = { labels: data.labels, values: data.operationRate, title: 'Operation Rate (Daily)' };
      if (charts.dailyOpRate) {
        charts.dailyOpRate.data.labels = dataset.labels;
        charts.dailyOpRate.data.datasets[0].data = dataset.values;
        // Hide title for Daily Operation Rate
        if (charts.dailyOpRate.options && charts.dailyOpRate.options.plugins && charts.dailyOpRate.options.plugins.title) {
          charts.dailyOpRate.options.plugins.title.display = false;
        }
        if (charts.dailyOpRate.options.plugins) { charts.dailyOpRate.options.plugins.valueLabels = { enabled: true, targets: [{ index: 0, decimals: 1, suffix: '%', orientation: 'diagonal' }] }; }
        charts.dailyOpRate.update('none');
      } else {
        charts.dailyOpRate = buildBar(c2, 'Operation Rate (%)', dataset, {
          bg: 'rgba(255,99,132,0.7)',
          border: 'red',
          scales: { y: { min: 0, max: 100, ticks: { callback: v => v + '%' } } },
          valueLabels: { enabled: true, targets: [{ index: 0, decimals: 1, suffix: '%', orientation: 'diagonal' }] },
          title: ''
        });
        // Hide title after creation
        try {
          if (charts.dailyOpRate.options && charts.dailyOpRate.options.plugins && charts.dailyOpRate.options.plugins.title) {
            charts.dailyOpRate.options.plugins.title.display = false;
          }
        } catch(e) {}
      }
    }

    
    // Daily Yield Rate
    const c3 = exists('yieldDailyChart');
    if (c3) {
      const dataset = { labels: data.labels, values: data.yieldRate, title: 'Yield Rate (Daily)' };
      // Compute dynamic min: if any value < 99, show full range down to floor(min) (not less than 90), else 99
      const vals = Array.isArray(dataset.values) ? dataset.values.map(v => parseFloat(v)).filter(v => isFinite(v)) : [];
      const minVal = vals.length ? Math.min(...vals) : 99;
      const dynMin = (isFinite(minVal) && minVal < 99) ? Math.max(90, Math.floor(minVal)) : 99;
      if (charts.dailyYield) {
        charts.dailyYield.data.labels = dataset.labels;
        charts.dailyYield.data.datasets[0].data = dataset.values;
        // Hide title for Daily Yield Rate
        if (charts.dailyYield.options && charts.dailyYield.options.plugins && charts.dailyYield.options.plugins.title) {
          charts.dailyYield.options.plugins.title.display = false;
        }
        charts.dailyYield.options.scales = { y: { min: dynMin, max: 100, ticks: { callback: v => Number(v).toFixed(2) + '%' } } };
        if (charts.dailyYield.options.plugins) { charts.dailyYield.options.plugins.valueLabels = { enabled: true, targets: [{ index: 0, decimals: 2, suffix: '%', orientation: 'diagonal' }] }; }
        charts.dailyYield.update('none');
      } else {
        charts.dailyYield = buildBar(c3, 'Yield Rate (%)', dataset, {
          bg: 'rgba(75,192,192,0.7)',
          border: 'green',
          scales: { y: { min: dynMin, max: 100, ticks: { callback: v => Number(v).toFixed(2) + '%' } } },
          valueLabels: { enabled: true, targets: [{ index: 0, decimals: 2, suffix: '%', orientation: 'diagonal' }] },
          title: ''
        });
        // Hide title after creation
        try {
          if (charts.dailyYield.options && charts.dailyYield.options.plugins && charts.dailyYield.options.plugins.title) {
            charts.dailyYield.options.plugins.title.display = false;
          }
        } catch(e) {}
      }
    }
  }

  async function render3M() {
    const data = await fetchChartData('monthly');
    // 3M Output
    const m1 = exists('output3MChart');
    if (m1) {
      const dataset = { labels: data.labels, values: data.outputData, title: 'Past 3 Months Output' };
      if (charts.m3Output) {
        charts.m3Output.data.labels = dataset.labels;
        charts.m3Output.data.datasets[0].data = dataset.values;
        // Do not set a title for the 3M Output chart
        if (charts.m3Output.options && charts.m3Output.options.plugins && charts.m3Output.options.plugins.title) {
          charts.m3Output.options.plugins.title.display = false;
        }
        charts.m3Output.update('none');
      } else {
        charts.m3Output = buildBar(m1, 'Output', dataset, { title: 'Past 3 Months Output', bg: 'rgba(54,162,235,0.6)', border: 'blue', scales: { y: { beginAtZero: true } } });
        // Disable title after creation
        try {
          if (charts.m3Output.options && charts.m3Output.options.plugins && charts.m3Output.options.plugins.title) {
            charts.m3Output.options.plugins.title.display = false;
            charts.m3Output.update('none');
          }
        } catch(e) {}
      }
    }
    // 3M Operation Rate
    const m2 = exists('opRate3MChart');
    if (m2) {
      const dataset = { labels: data.labels, values: data.operationRate, title: 'Past 3 Months Operation Rate' };
      if (charts.m3OpRate) {
        charts.m3OpRate.data.labels = dataset.labels;
        charts.m3OpRate.data.datasets[0].data = dataset.values;
        // Hide title for 3M Operation Rate
        if (charts.m3OpRate.options && charts.m3OpRate.options.plugins && charts.m3OpRate.options.plugins.title) {
          charts.m3OpRate.options.plugins.title.display = false;
        }
        charts.m3OpRate.update('none');
      } else {
        charts.m3OpRate = buildBar(m2, 'Operation Rate (%)', dataset, { title: 'Past 3 Months Operation Rate', bg: 'rgba(255,99,132,0.6)', border: 'red', scales: { y: { min: 0, max: 100, ticks: { callback: v => v + '%' } } } });
        // Disable title after creation
        try {
          if (charts.m3OpRate.options && charts.m3OpRate.options.plugins && charts.m3OpRate.options.plugins.title) {
            charts.m3OpRate.options.plugins.title.display = false;
            charts.m3OpRate.update('none');
          }
        } catch(e) {}
      }
    }
    // 3M Yield Rate
    const m3 = exists('yield3MChart');
    if (m3) {
      const dataset = { labels: data.labels, values: data.yieldRate, title: 'Past 3 Months Yield Rate' };
      if (charts.m3Yield) {
        charts.m3Yield.data.labels = dataset.labels;
        charts.m3Yield.data.datasets[0].data = dataset.values;
        // Hide title for 3M Yield Rate
        if (charts.m3Yield.options && charts.m3Yield.options.plugins && charts.m3Yield.options.plugins.title) {
          charts.m3Yield.options.plugins.title.display = false;
        }
        charts.m3Yield.update('none');
      } else {
        charts.m3Yield = buildBar(m3, 'Yield Rate (%)', dataset, { title: 'Past 3 Months Yield Rate', bg: 'rgba(75,192,192,0.6)', border: 'green', scales: { y: { min: 0, max: 100, ticks: { callback: v => v + '%' } } } });
        // Disable title after creation
        try {
          if (charts.m3Yield.options && charts.m3Yield.options.plugins && charts.m3Yield.options.plugins.title) {
            charts.m3Yield.options.plugins.title.display = false;
            charts.m3Yield.update('none');
          }
        } catch(e) {}
      }
    }
  }

  function hasDataChanged(oldData, newData) {
    if (!oldData) return true; // retained for compatibility if needed elsewhere
    return false;
  }

  function generateFallbackData(viewType) {
    const today = new Date();
    let labels = [];
    const zeros = (n) => new Array(n).fill(0);

    if (viewType === 'daily') {
      const first = new Date(today.getFullYear(), today.getMonth(), 1);
      const last = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      const cur = new Date(first);
      while (cur <= last) {
        const dayName = cur.toLocaleDateString('en-US', { weekday: 'short' });
        const dayDate = cur.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
        labels.push(`${dayName} ${dayDate}`);
        cur.setDate(cur.getDate() + 1);
      }
      return { labels, outputData: zeros(labels.length), operationRate: zeros(labels.length), yieldRate: zeros(labels.length), title: 'Daily Production Performance (No Data)' };
    }

    if (viewType === 'weekly') {
      const first = new Date(today.getFullYear(), today.getMonth(), 1);
      const last = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      const cur = new Date(first);
      let weekNumber = 1;
      let weekStart = new Date(cur);
      while (cur <= last) {
        const dow = cur.getDay();
        if (dow === 1 || cur.getDate() === 1) weekStart = new Date(cur);
        if (dow === 0 || cur.getDate() === last.getDate()) {
          const weekEnd = new Date(cur);
          const label = `Week ${weekNumber} (${weekStart.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${weekEnd.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })})`;
          labels.push(label);
          weekNumber++;
        }
        cur.setDate(cur.getDate() + 1);
      }
      return { labels, outputData: zeros(labels.length), operationRate: zeros(labels.length), yieldRate: zeros(labels.length), title: 'Weekly Production Performance (No Data)' };
    }

    // 3 months
    const curMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const threeAgo = new Date(today.getFullYear(), today.getMonth() - 3, 1);
    const cur = new Date(threeAgo);
    while (cur <= curMonth) {
      labels.push(cur.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }));
      cur.setMonth(cur.getMonth() + 1);
    }
    return { labels, outputData: zeros(labels.length), operationRate: zeros(labels.length), yieldRate: zeros(labels.length), title: '3 Months Production Performance (No Data)' };
  }

  document.addEventListener('DOMContentLoaded', function(){
    renderDaily();
    render3M();
    renderLineRejectionRate();
    renderAchievementRate();

    // Debounced updater for real-time refresh without page reload
    let _lv2_update_pending = false;
    function scheduleChartsUpdate(){
      if (_lv2_update_pending) return;
      _lv2_update_pending = true;
      setTimeout(() => {
        try {
          renderDaily();
          render3M();
          renderLineRejectionRate();
          renderAchievementRate();
        } finally {
          _lv2_update_pending = false;
        }
      }, 500);
    }

    // Update charts in real-time when other tabs/pages broadcast state changes
    try {
      const ch = new BroadcastChannel('monitoring-sync');
      ch.addEventListener('message', (ev) => {
        const msg = ev.data || {};
        if (msg.type === 'state_update') {
          // Only update if same line/shift to avoid unnecessary API calls
          const myLine = document.querySelector('input[name="line_id"]').value || '';
          const myShift = document.querySelector('input[name="shift"]').value || '';
          if (String(msg.line) === String(myLine) && String(msg.shift) === String(myShift)) {
            scheduleChartsUpdate();
          }
        }
      });
    } catch(e) {}

    // Also refresh when shift is auto-adjusted
    window.addEventListener('realtime_shift_changed', scheduleChartsUpdate);

    // Expose for realtime_view.js integration
    try { window.updateAchievementChart = renderAchievementRate; } catch(e) {}
  });
})();
