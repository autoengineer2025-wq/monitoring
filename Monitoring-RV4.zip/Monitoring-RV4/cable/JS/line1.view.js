if (typeof window !== 'undefined' && window.READ_ONLY_VIEW) {
    function calculateRealTimeTarget() {
        // Global debug flag - set window.DEBUG_RT_TARGET = true in console to enable detailed logging
        if (typeof window.DEBUG_RT_TARGET === 'undefined') {
            window.DEBUG_RT_TARGET = false;
        }
        const planTarget = parseInt(document.getElementById('plan_target').value) || 0;
        const takttimeString = document.getElementById('takttime').value;
        let takttime = 0;
        if (takttimeString.includes(',')) {
            const arr = takttimeString.split(',').map(t => parseFloat(t.trim()));
            takttime = arr[0] || 0;
        } else {
            takttime = parseFloat(takttimeString) || 0;
        }

    console.log('=== Real-time Target Debug ===');
    console.log('Plan target:', planTarget);
    console.log('Takttime string:', takttimeString);
    console.log('Takttime:', takttime);
    // Debug: Check what break times are actually loaded in the HTML
    console.log('Break times from HTML inputs:');
    for (let i = 1; i <= 5; i++) {
        const startEl = document.getElementById(`start_time_${i}`);
        const endEl = document.getElementById(`end_time_${i}`);
        console.log(`Break ${i} input:`, startEl ? startEl.value : 'null', '-', endEl ? endEl.value : 'null');
    }

    console.log('Current time (local):', new Date().toLocaleString());
    console.log('Current time (UTC):', new Date().toISOString());
    if (!(takttime > 0)) {
        console.log('Early return: invalid takttime value');
        return 0;
    }

    const now = new Date();
    console.log('Parsed takttime:', takttime);
    console.log('Current time:', now.toISOString());

    // Get the production date from hidden input instead of always using today
    const prodDateInput = document.querySelector('input[name="production_date"]');
    const productionDate = (prodDateInput && prodDateInput.value) ? prodDateInput.value : now.toISOString().split('T')[0];

    // Check if this is a night shift
    const shiftInput = document.querySelector('input[name="shift"]');
    const shiftValue = (shiftInput && shiftInput.value) ? shiftInput.value.toLowerCase() : '';
    const isNightShift = shiftValue.includes('night');

    console.log('Production date:', productionDate);
    console.log('Shift value:', shiftValue);
    console.log('Is night shift:', isNightShift);
    console.log('Current time:', now.toISOString());

    try {
        if (productionDate) {
            let cutoff;
            if (isNightShift) {
                // Local time: 06:00 next day
                cutoff = new Date(productionDate + 'T06:00:00');
                cutoff.setDate(cutoff.getDate() + 1);
                console.log('Night shift cutoff (local):', cutoff.toISOString(), 'Current time:', now.toISOString(), 'Is past cutoff:', now >= cutoff);
            } else {
                // Local time: 18:00 same day
                cutoff = new Date(productionDate + 'T18:00:00');
                console.log('Day shift cutoff (local):', cutoff.toISOString(), 'Current time:', now.toISOString(), 'Is past cutoff:', now >= cutoff);
            }
            if (cutoff && now >= cutoff) {
                console.log('Shift is over, returning plan target:', planTarget);
                return planTarget;
            }
        }
    } catch(e) {
        console.error('Error in cutoff calculation:', e);
    }

    const windows = [];
    console.log('\n=== Break Windows Debug ===');
    for (let i = 1; i <= 5; i++) {
        const s = document.getElementById(`start_time_${i}`).value;
        const e = document.getElementById(`end_time_${i}`).value;
        console.log(`Break ${i}: start=${s}, end=${e}`);

        if (!s || !e) {
            console.log(`Break ${i}: No start/end time, skipping`);
            continue;
        }

        const start = new Date(`${productionDate}T${s}`);
        let end = new Date(`${productionDate}T${e}`);

        if (isNightShift) {
            console.log(`Break ${i}: Processing night shift - start: ${s}, end: ${e}`);

            if (end <= start) {
                end.setDate(end.getDate() + 1);
                console.log(`Break ${i}: Cross-midnight detected, adjusted end to:`, end.toISOString());
            }

            const startHour = parseInt(s.split(':')[0]);
            const endHour = parseInt(e.split(':')[0]);
            console.log(`Break ${i}: Hours - start: ${startHour}, end: ${endHour}`);

            if (startHour >= 22 && endHour <= 6 && endHour >= 0 && end <= start) {
                end.setDate(end.getDate() + 1);
                console.log(`Break ${i}: True overnight break, adjusted end to:`, end.toISOString());
            }

        } else {
            if (end <= start) {
                end.setDate(end.getDate() + 1);
                console.log(`Break ${i}: Day shift cross-midnight, adjusted end to:`, end.toISOString());
            }
        }

        windows.push({ index: i, start, end });
        console.log(`Break ${i}: Final window - start: ${start.toISOString()}, end: ${end.toISOString()}`);
    }
    console.log(`Total windows: ${windows.length}`);
    if (windows.length === 0) {
        console.log('No valid windows found, returning 0');
        return 0;
    }

    let shiftStart = null;
    const TWELVE_HOURS_MS = 12 * 60 * 60 * 1000;

    console.log('\n=== Shift Start Calculation ===');
    for (const w of windows) {
        if (w.start <= now && (now - w.start) <= TWELVE_HOURS_MS) {
            if (!shiftStart || w.start < shiftStart) {
                shiftStart = new Date(w.start);
            }
        }
    }

    if (!shiftStart) {
        // Fallback: use the earliest break start
        shiftStart = new Date(Math.min(...windows.map(w => +w.start)));
    }

    if (isNightShift && !shiftStart) {
        // For night shift, if no valid shift start found, use the first break that ends after now
        for (const w of windows) {
            if (w.end > now) {
                shiftStart = new Date(w.start);
                break;
            }
        }
    }

    console.log('Calculated shift start:', shiftStart ? shiftStart.toISOString() : 'null');

    function elapsedClamped(start, end) {
        if (now <= start) return 0;
        const efCstart = start < shiftStart ? shiftStart : start;
        const efCend = now < end ? now : end;
        if (efCend <= efCstart) return 0;
        return Math.floor((efCend - efCstart) / 1000);
    }

    console.log('=== Cumulative Target Calculation ===');
    console.log('Shift start:', shiftStart ? shiftStart.toISOString() : 'null');
    console.log('Current time:', now.toISOString());
    console.log('Current time (local):', now.toLocaleString());
    console.log('Takttime:', takttime, 'seconds per unit');

    // Debug current time in relation to each break
    console.log('\n=== Break Status Analysis ===');
    for (const w of windows) {
        const isActive = now >= w.start && now <= w.end;
        const elapsed = elapsedClamped(w.start, w.end);
        const contribution = elapsed > 0 ? Math.floor(elapsed / takttime) : 0;

        console.log(`Break ${w.index}:`);
        console.log(`  Window: ${w.start.toLocaleString()} to ${w.end.toLocaleString()}`);
        console.log(`  Current time: ${now.toLocaleString()}`);
        console.log(`  Is active: ${isActive}`);
        console.log(`  Elapsed: ${elapsed} seconds`);
        console.log(`  Would contribute: ${contribution} units`);
    }

    let cumulativeTarget = 0;
    const debugInfo = [];

    for (const w of windows) {
        const isActive = now >= w.start && now <= w.end;
        const elapsed = elapsedClamped(w.start, w.end);
        const contribution = elapsed > 0 ? Math.floor(elapsed / takttime) : 0;

        if (contribution > 0) {
            cumulativeTarget += contribution;
        }

        debugInfo.push({
            break: w.index,
            start: w.start.toISOString(),
            end: w.end.toISOString(),
            isActive: isActive,
            elapsed: elapsed,
            contribution: contribution
        });
    }

    if (window.DEBUG_RT_TARGET && debugInfo.length > 0) {
        console.log('Night Shift Target Debug:', {
            isNightShift,
            productionDate,
            now: now.toISOString(),
            cumulativeTarget,
            planTarget,
            windows: windows.map(w => ({ break: w.index, start: w.start.toISOString(), end: w.end.toISOString() })),
            calculations: debugInfo
        });
    }

    const finalTarget = Math.min(cumulativeTarget, planTarget);
    console.log('Final calculation - Cumulative target:', cumulativeTarget, 'Plan target:', planTarget, 'Final result:', finalTarget);

    return finalTarget;
}

function updateRealTimeTarget() {
    const targetElement = document.getElementById('real-time-target');
    const differenceElement = document.getElementById('real-time-difference');
    const actualElement = document.getElementById('total-actual');
    
    if (targetElement) {
        const realTimeTarget = calculateRealTimeTarget();
        targetElement.textContent = realTimeTarget;
        
        if (differenceElement && actualElement) {
            const actualValue = parseInt(actualElement.textContent) || 0;
            const difference = actualValue - realTimeTarget;
            const val = parseInt(difference, 10) || 0;
            differenceElement.textContent = (val === 0 ? '-' : val);
            differenceElement.classList.remove('text-success','text-danger');
            if (val > 0) differenceElement.classList.add('text-success');
            if (val < 0) differenceElement.classList.add('text-danger');
        }
    }
}

}

document.addEventListener('DOMContentLoaded', function() {
    $(document).on('change', '.remark-classification-select', function() {
        const classification = $(this).val();
        const breakNum = $(this).data('break');
        if (!classification) return;
        $('#remarksBreak').val(breakNum);
        $('#remarksClassification').val(classification);
        $('#remarksClassificationView').val(classification);
        const existingReason = $(`.remark-reason[data-break="${breakNum}"]`).text().trim();
        const existingCounter = $(`.remark-countermeasure[data-break="${breakNum}"]`).text().trim();
        $('#remarksReason').val(existingReason);
        $('#remarksCountermeasure').val(existingCounter);
        const modal = new bootstrap.Modal(document.getElementById('remarksModal'));
        modal.show();
    });

    $('#saveRemarksBtn').on('click', function() {
        const breakNum = $('#remarksBreak').val();
        const classification = $('#remarksClassification').val();
        const reason = $('#remarksReason').val().trim();
        const countermeasure = $('#remarksCountermeasure').val().trim();

        if (!reason || !countermeasure) {
            alert('Please fill in both Reason and Countermeasure.');
            return;
        }

        const recordId = $('#recordId').val() || $('input[name="record_id"]').val() || '';
        let lineId = $('input[name="line_id"]').val() || $('#lineNumber').val() || '';
        let shift = $('input[name="shift"]').val() || $('#shift').val() || '';
        const urlParams = new URLSearchParams(window.location.search);
        if (!lineId && urlParams.get('line')) lineId = urlParams.get('line');
        if (!shift && urlParams.get('shift')) shift = urlParams.get('shift');
        const productionDate = $('input[name="production_date"]').val() || $('#prodDate').val() || new Date().toISOString().split('T')[0];

        $.ajax({
            url: 'API/save_remarks.php',
            method: 'POST',
            dataType: 'json',
            data: {
                record_id: recordId,
                line_id: lineId,
                shift: shift,
                production_date: productionDate,
                break_number: breakNum,
                classification: classification,
                reason: reason,
                countermeasure: countermeasure
            },
            success: function(res) {
                if (res && res.success) {
                    const $select = $(`.remark-classification-select[data-break="${breakNum}"]`);
                    $select.val(classification);
                    $(`.remark-reason[data-break="${breakNum}"]`).text(reason);
                    $(`.remark-countermeasure[data-break="${breakNum}"]`).text(countermeasure);
                    bootstrap.Modal.getInstance(document.getElementById('remarksModal')).hide();
                    try { if (typeof persistBreakSnapshot === 'function') persistBreakSnapshot(recordId); } catch(e){}
                        try { publishState(); } catch(e){}
                } else {
                    alert(res && res.message ? res.message : 'Failed to save remarks.');
                }
            },
            error: function(xhr) {
                alert('Error saving remarks.');
            }
        });
    });

    $(document).on('input change', '.reject-input', function() {
        const $inp = $(this);
        const breakNum = parseInt($inp.data('break')) || 0;
        const recordId = $inp.data('record') || '';
        const qty = parseInt($inp.val()) || 0;
        if (!recordId || breakNum <= 0) return;

        $.ajax({
            url: 'API/save_reject.php',
            method: 'POST',
            dataType: 'json',
            data: { record_id: recordId, break_number: breakNum, qty: qty },
            success: function(res){
                if (typeof updateRejectAccumulated === 'function') {
                    updateRejectAccumulated();
                }
                if (typeof updateAllDifferences === 'function') {
                    updateAllDifferences();
                }
                try { if (typeof persistBreakSnapshot === 'function') persistBreakSnapshot(recordId); } catch(e){}
                    try { publishState(); } catch(e){}
            }
        });
    });
});

function initializeCharts() {
  updateRealTimeTarget();
  setInterval(updateRealTimeTarget, 60000);
  initializeDailyChart();
  
  setTimeout(function() {
    if (typeof renderLineRejectionRate === 'function') {
      renderLineRejectionRate();
    }
  }, 500);
}

document.addEventListener('DOMContentLoaded', function() {
  // Debounced real-time refresh instead of fixed intervals
  let _lv1_update_pending = false;
    function scheduleRealtimeChartsUpdate(){
        if (_lv1_update_pending) return;
        _lv1_update_pending = true;
        setTimeout(function(){
            try {
                if (typeof refreshChartData === 'function') refreshChartData();
                if (typeof updateAchievementPerBreakChart === 'function') updateAchievementPerBreakChart();
            } finally { _lv1_update_pending = false; }
        }, 400);
    }
    // Listen for broadcast updates from other tabs/pages
    try {
        var _lv1Channel = new BroadcastChannel('monitoring-sync');
        _lv1Channel.addEventListener('message', function(ev){
            const msg = ev.data || {};
            if (msg.type === 'state_update') {
                const myLine = document.querySelector('input[name="line_id"]').value || '';
                const myShift = document.querySelector('input[name="shift"]').value || '';
                if (String(msg.line) === String(myLine) && String(msg.shift) === String(myShift)) {
                    scheduleRealtimeChartsUpdate();
                }
            }
        });
    } catch(e) {}
        try { publishState(); } catch(e){}
        // Ensure table DIFF cells styled after initial render
        try { if (typeof updateAllDifferences === 'function') updateAllDifferences(); } catch(e){}
});

// BroadcastChannel: publish local state so other tabs/views update immediately
try {
    var _monitoringChannel = new BroadcastChannel('monitoring-sync');
} catch(e) { var _monitoringChannel = null; }

function publishState() {
    if (!_monitoringChannel) return;
    try {
        const lineId = document.querySelector('input[name="line_id"]').value || '';
        const shift = document.querySelector('input[name="shift"]').value || '';
        const recordId = document.getElementById('recordId')?.value || '';
        const planTarget = parseInt(document.getElementById('plan_target')?.value) || 0;
        const takttime = document.getElementById('takttime')?.value || '';
        const totalActual = parseInt(document.getElementById('total-actual')?.textContent) || 0;
        const actuals = [];
        for (let i=1;i<=5;i++) actuals.push(parseInt(document.getElementById('actual'+i)?.value || document.querySelector(`.output-cell[data-break="${i}"] div`)?.textContent || 0));
        const start_times = [];
        const end_times = [];
        for (let i=1;i<=5;i++){
            start_times.push(document.getElementById(`start_time_${i}`)?.value || '');
            end_times.push(document.getElementById(`end_time_${i}`)?.value || '');
        }
        // collect reject values
        const rejects = {};
        document.querySelectorAll('.reject-input').forEach(inp => { 
            const bn = inp.dataset.break; 
            if (bn) rejects[bn] = parseInt(inp.value)||0; 
        });

        _monitoringChannel.postMessage({
            type: 'state_update',
            line: lineId,
            shift: shift,
            record_id: recordId,
            plan_target: planTarget,
            takttime: takttime,
            total_actual: totalActual,
            actuals: actuals,
            start_times: start_times,
            end_times: end_times,
            rejects: rejects
        });
    } catch(e) {}
}

document.addEventListener('DOMContentLoaded', function() {
    updateRealTimeTarget();
    setInterval(updateRealTimeTarget, 60000);
    
    initializeDailyChart();
    
    setTimeout(function() {
        if (typeof renderLineRejectionRate === 'function') {
            renderLineRejectionRate();
        }
    }, 500);
    
    setTimeout(publishState, 300);
});

var dailyChart = window.dailyChart || null;
var lastChartData = window.lastChartData || null; 

async function initializeDailyChart() {
    const ctx = document.getElementById('dailyChart');
    if (!ctx) return;
    
    
    const selectedView = document.querySelector('input[name="chartView"]:checked').value;
    ctx.style.opacity = '0.5';
    
    const loadingDiv = document.createElement('div');
    loadingDiv.id = 'chart-loading';
    loadingDiv.innerHTML = '<small class="text-muted"></small>';
    loadingDiv.style.position = 'absolute';
    loadingDiv.style.top = '50%';
    loadingDiv.style.left = '50%';
    loadingDiv.style.transform = 'translate(-50%, -50%)';
    loadingDiv.style.zIndex = '10';
    
    const chartContainer = ctx.parentElement;
    chartContainer.style.position = 'relative';
    chartContainer.appendChild(loadingDiv);
    
    try {
        const chartData = await fetchChartData(selectedView);
        
        if (dailyChart) {
            dailyChart.destroy();
        }
        lastChartData = chartData;

        const rateValueLabels = {
            id: 'rateValueLabels',
            afterDatasetsDraw(chart, args, pluginOptions) {
                const { ctx } = chart;
                const datasets = chart.data.datasets || [];
                const metaOut = chart.getDatasetMeta(0); 
                const metaOp  = chart.getDatasetMeta(1); 
                const metaYd  = chart.getDatasetMeta(2); 
                const drawForMeta = (meta, dsIndex, formatFn, rotateDiagonal=false) => {
                    if (!meta || !meta.data) return;
                    const ds = datasets[dsIndex];
                    if (!ds) return;
                    const data = ds.data || [];
                    for (let i = 0; i < meta.data.length; i++) {
                        const el = meta.data[i];
                        const raw = typeof data[i] === 'number' ? data[i] : parseFloat(data[i]);
                        if (!isFinite(raw)) continue;
                        const pos = (typeof el.tooltipPosition === 'function') ? el.tooltipPosition() : { x: el.x, y: el.y };
                        const label = formatFn(raw);
                        const x = pos.x;
                        const y = pos.y - 8;
                        ctx.save();
                        ctx.textBaseline = 'bottom';
                        ctx.textAlign = rotateDiagonal ? 'left' : 'center';
                        if (rotateDiagonal) {
                            ctx.translate(x + 6, y);
                            ctx.rotate(-Math.PI / 4); 
                        } else {
                            ctx.translate(x, y);
                        }
                        const fontSize = (pluginOptions && pluginOptions.fontSize) || 12;
                        const fontWeight = (pluginOptions && pluginOptions.fontWeight) || '700';
                        ctx.font = `${fontWeight} ${fontSize}px sans-serif`;
                        ctx.lineWidth = 3;
                        ctx.strokeStyle = 'rgba(255,255,255,0.9)';
                        ctx.strokeText(label, 0, 0);
                        ctx.fillStyle = (pluginOptions && pluginOptions.color) || '#111';
                        ctx.fillText(label, 0, 0);
                        ctx.restore();
                    }
                };
                ctx.save();
                try { drawForMeta(metaOut, 0, (v)=> String(v), true); } catch(e) {}
                try { drawForMeta(metaOp,  1, (v)=> `${Number(v).toFixed(1)}%`, false); } catch(e) {}
                try { drawForMeta(metaYd,  2, (v)=> `${Number(v).toFixed(2)}%`, false); } catch(e) {}
                ctx.restore();
            }
        };

        dailyChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: chartData.labels,
                datasets: [
                    {
                    label: 'Daily Output',
                    data: chartData.outputData,
                    backgroundColor: 'rgba(54, 162, 235, 0.7)',
                    borderColor: 'blue',
                    borderWidth: 1,
                    yAxisID: 'y'
                },
                {
                    label: 'Operation Rate (%)',
                    data: chartData.operationRate,
                    backgroundColor: 'rgba(255, 99, 132, 0.7)',
                    borderColor: 'red',
                    borderWidth: 1,
                    yAxisID: 'y1'
                },
                {
                    label: 'Yield Rate (%)',
                    data: chartData.yieldRate,
                    backgroundColor: 'rgba(75, 192, 192, 0.7)',
                    borderColor: 'green',
                    borderWidth: 1,
                    yAxisID: 'y2'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { 
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        padding: 10,
                        font: {
                            size: 11
                        }
                    }
                },
                title: {
                    display: true,
                    text: chartData.title,
                    font: {
                        size: 14,
                        weight: 'bold'
                    }
                }
            },
            scales: {
                x: {
                    ticks: {
                        maxRotation: 45,
                        minRotation: 0,
                        font: {
                            size: 10
                        }
                    }
                },
                y: { 
                    type: 'linear',
                    position: 'left',
                    title: { 
                        display: true, 
                        text: 'Output (units)',
                        font: {
                            size: 11
                        }
                    },
                    ticks: {
                        font: {
                            size: 10
                        }
                    }
                },
                y1: { 
                    type: 'linear',
                    position: 'right',
                    min: 0,
                    max: 100,
                    ticks: { 
                        callback: v => v + "%",
                        font: {
                            size: 10
                        }
                    },
                    title: { 
                        display: true, 
                        text: 'Rate (%)',
                        font: {
                            size: 11
                        }
                    },
                    grid: { drawOnChartArea: false }
                },
                y2: { 
                    type: 'linear',
                    position: 'right',
                    min: 99,
                    max: 100,
                    ticks: {
                        callback: v => Number(v).toFixed(2) + '%',
                        stepSize: 0.1,
                        font: { size: 10 }
                    },
                    title: { display: true, text: 'Yield (%)', font: { size: 11 } },
                    grid: { drawOnChartArea: false },
                    offset: true
                }
            }
        },
        plugins: [rateValueLabels]
    });
    
    ctx.style.opacity = '1';
    const loadingDiv = document.getElementById('chart-loading');
    if (loadingDiv) {
        loadingDiv.remove();
    }
    
    } catch (error) {
        console.error('Error initializing chart:', error);
        ctx.style.opacity = '1';
        
        const loadingDiv = document.getElementById('chart-loading');
        if (loadingDiv) {
            loadingDiv.remove();
        }
        
        const ctx2d = ctx.getContext('2d');
        ctx2d.clearRect(0, 0, ctx.width, ctx.height);
        ctx2d.fillStyle = '#666';
        ctx2d.font = '14px Arial';
        ctx2d.textAlign = 'center';
        ctx2d.fillText('Error loading chart data', ctx.width / 2, ctx.height / 2);
    }
}

async function fetchChartData(viewType) {
    try {
        const lineId = document.querySelector('input[name="line_id"]').value;
        const shift = document.querySelector('input[name="shift"]').value;
        
        const response = await fetch(`API/get_chart_data.php?view=${viewType}&line=${lineId}&shift=${shift}`);
        const result = await response.json();
        
        if (result.success) {
            return {
                labels: result.data.map(item => item.label),
                outputData: result.data.map(item => item.output),
                operationRate: result.data.map(item => item.operationRate),
                yieldRate: result.data.map(item => item.yieldRate),
                title: result.title
            };
        } else {
            console.error('Error fetching chart data:', result.error);
            return generateFallbackData(viewType);
        }
    } catch (error) {
        console.error('Error fetching chart data:', error);
        return generateFallbackData(viewType);
    }
}

async function refreshChartData() {
    if (!dailyChart) return;
    
    try {
        // Get the selected view
        const selectedView = document.querySelector('input[name="chartView"]:checked').value;
        
        // Fetch new data using AJAX
        const lineId = document.querySelector('input[name="line_id"]').value;
        const shift = document.querySelector('input[name="shift"]').value;
        
        const response = await fetch(`API/get_chart_data.php?view=${selectedView}&line=${lineId}&shift=${shift}`);
        const result = await response.json();
        
        if (result.success) {
            const newData = {
                labels: result.data.map(item => item.label),
                outputData: result.data.map(item => item.output),
                operationRate: result.data.map(item => item.operationRate),
                yieldRate: result.data.map(item => item.yieldRate),
                title: result.title
            };
            
            if (!lastChartData || hasDataChanged(lastChartData, newData)) {
                dailyChart.data.labels = newData.labels;
                dailyChart.data.datasets[0].data = newData.outputData;
                dailyChart.data.datasets[1].data = newData.operationRate;
                dailyChart.data.datasets[2].data = newData.yieldRate;
                dailyChart.options.plugins.title.text = newData.title;
                
                dailyChart.update('none');
                lastChartData = newData;
                showChartUpdateIndicator();
            }
        }
    } catch (error) {
        console.error('Error refreshing chart data:', error);
    }
}

function hasDataChanged(oldData, newData) {
    if (!oldData) return true;
    
    if (JSON.stringify(oldData.outputData) !== JSON.stringify(newData.outputData)) return true;
    if (JSON.stringify(oldData.operationRate) !== JSON.stringify(newData.operationRate)) return true;
    if (JSON.stringify(oldData.yieldRate) !== JSON.stringify(newData.yieldRate)) return true;
    return false;
}

function showChartUpdateIndicator() {
    const ctx = document.getElementById('dailyChart');
    const statusElement = document.getElementById('chart-status');
    
    if (!ctx) return;
    
    ctx.style.transition = 'opacity 0.2s';
    ctx.style.opacity = '0.8';
    
    if (statusElement) {
        statusElement.textContent = '';
        statusElement.className = 'text-success';
        
        setTimeout(() => {
            statusElement.textContent = '';
        }, 1000);
    }
    
    setTimeout(() => {
        ctx.style.opacity = '1';
    }, 200);
}

function generateFallbackData(viewType) {
    const today = new Date();
    let labels = [];
    let outputData = [];
    let operationRate = [];
    let yieldRate = [];
    let title = '';
    
    if (viewType === 'daily') {
        const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        const currentDate = new Date(firstDayOfMonth);
        
        while (currentDate <= lastDayOfMonth) {
            const dayName = currentDate.toLocaleDateString('en-US', { weekday: 'short' });
            const dayDate = currentDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            labels.push(`${dayName} ${dayDate}`);
            currentDate.setDate(currentDate.getDate() + 1);
        }
        
        outputData = new Array(labels.length).fill(0);
        operationRate = new Array(labels.length).fill(0);
        yieldRate = new Array(labels.length).fill(0);
        title = 'Daily Production Performance (No Data)';
        
    } else if (viewType === 'weekly') {
        const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        const currentDate = new Date(firstDayOfMonth);
        
        let weekNumber = 1;
        let weekStart = new Date(currentDate);
        
        while (currentDate <= lastDayOfMonth) {
            const dayOfWeek = currentDate.getDay(); 
            
            if (dayOfWeek === 1 || currentDate.getDate() === 1) {
                weekStart = new Date(currentDate);
            }
            
            if (dayOfWeek === 0 || currentDate.getDate() === lastDayOfMonth.getDate()) {
                const weekEnd = new Date(currentDate);
                const weekLabel = `Week ${weekNumber} (${weekStart.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${weekEnd.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })})`;
                labels.push(weekLabel);
                weekNumber++;
            }
            
            currentDate.setDate(currentDate.getDate() + 1);
        }
        
        // Fallback data
        outputData = new Array(labels.length).fill(0);
        operationRate = new Array(labels.length).fill(0);
        yieldRate = new Array(labels.length).fill(0);
        title = 'Weekly Production Performance (No Data)';
        
    } else {
        // 3 Months view: Past 3 months
        const currentMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        const threeMonthsAgo = new Date(today.getFullYear(), today.getMonth() - 3, 1);
        const currentDate = new Date(threeMonthsAgo);
        
        while (currentDate <= currentMonth) {
            const monthLabel = currentDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
            labels.push(monthLabel);
            currentDate.setMonth(currentDate.getMonth() + 1);
        }
        
        // Fallback data
        outputData = new Array(labels.length).fill(0);
        operationRate = new Array(labels.length).fill(0);
        yieldRate = new Array(labels.length).fill(0);
        title = '3 Months Production Performance (No Data)';
    }
    
    return {
        labels: labels,
        outputData: outputData,
        operationRate: operationRate,
        yieldRate: yieldRate,
        title: title
    };
}

document.addEventListener('DOMContentLoaded', function() {
    const radioButtons = document.querySelectorAll('input[name="chartView"]');
    radioButtons.forEach(radio => {
        radio.addEventListener('change', function() {
            lastChartData = null;
            initializeDailyChart();
        });
    });
    
    initializeAchievementPerBreakChart();
});

// Same guard for the secondary chart instance
var achievementPerBreakChart = window.achievementPerBreakChart || null;

function initializeAchievementPerBreakChart() {
    const ctx = document.getElementById('achievementPerBreakChart');
    if (!ctx) return;
    
    const chartData = getAchievementPerBreakData();
    
    // Custom plugin to draw percentage labels at the end of each bar
    const barValueLabels = {
        id: 'barValueLabels',
        afterDatasetsDraw(chart, args, pluginOptions) {
            const { ctx } = chart;
            try {
                const ds = chart.data.datasets[0];
                const meta = chart.getDatasetMeta(0);
                if (!ds || !meta || !meta.data) return;
                ctx.save();
                const area = chart.chartArea || { right: 0 };
                ctx.fillStyle = (pluginOptions && pluginOptions.color) || '#212529';
                const fontSize = (pluginOptions && pluginOptions.fontSize) || 11;
                const fontWeight = (pluginOptions && pluginOptions.fontWeight) || '600';
                ctx.font = `${fontWeight} ${fontSize}px sans-serif`;
                ctx.textBaseline = 'middle';
                ctx.textAlign = 'left';
                meta.data.forEach((barEl, idx) => {
                    const val = (ds.data && typeof ds.data[idx] !== 'undefined') ? ds.data[idx] : '';
                    if (val === '' || val === null) return;
                    const pos = (typeof barEl.tooltipPosition === 'function') ? barEl.tooltipPosition() : { x: barEl.x, y: barEl.y };
                    let x = pos.x + 8;
                    const y = pos.y;
                    // Keep within chart area
                    if (area && x > area.right - 4) x = area.right - 4;
                    ctx.fillText(`${val}%`, x, y);
                });
                ctx.restore();
            } catch(e) {}
        }
    };

    achievementPerBreakChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartData.labels,
            datasets: [{
                label: 'Achievement %',
                data: chartData.achievements,
                backgroundColor: chartData.colors,
                borderColor: chartData.borderColors,
                borderWidth: 1,
                borderRadius: 3
            }]
        },
        options: {
            indexAxis: 'y', 
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                title: {
                    display: false
                },
                // Styling for value labels (optional overrides)
                barValueLabels: { color: '#212529', fontSize: 11, fontWeight: '600' }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        },
                        font: {
                            size: 10
                        }
                    },
                    title: {
                        display: false
                    }
                },
                y: {
                    ticks: {
                        font: {
                            size: 10
                        }
                    },
                    title: {
                        display: false
                    }
                }
            }
        }
    ,
        plugins: [barValueLabels]
    });
}

function getAchievementPerBreakData() {
    const labels = ['1ST', '2ND', '3RD', '4TH', '5TH'];
    const achievements = [];
    const colors = [];
    const borderColors = [];
    
    for (let i = 1; i <= 5; i++) {
        const planOutput = parseInt($(`.output-cell[data-break="${i}"]`).siblings('.plan-output-cell').text()) || 0;
        const actualOutput = parseInt($(`.output-cell[data-break="${i}"]`).text()) || 0;
        
        let achievement = 0;
        if (planOutput > 0) {
            achievement = Math.round((actualOutput / planOutput) * 100);
        }
        
        achievements.push(achievement);
        
        if (achievement >= 101) {
        colors.push('rgba(0, 123, 255, 0.7)');   
        borderColors.push('rgb(1, 48, 99)');
        } else if (achievement === 100) {
            colors.push('rgba(40, 167, 69, 0.7)');  
            borderColors.push('rgb(1, 87, 21)');
        } else if (achievement >= 95.5 && achievement < 100) {
            colors.push('rgba(255, 193, 7, 0.7)');   
            borderColors.push('rgb(104, 78, 2)');  
        } else {
            colors.push('rgba(220, 53, 69, 0.7)');   
            borderColors.push('rgb(114, 0, 11)');
        }

    }
    
    return {
        labels: labels,
        achievements: achievements,
        colors: colors,
        borderColors: borderColors
    };
}

function updateAchievementPerBreakChart() {
    if (!achievementPerBreakChart) return;
    
    const chartData = getAchievementPerBreakData();
    achievementPerBreakChart.data.datasets[0].data = chartData.achievements;
    achievementPerBreakChart.data.datasets[0].backgroundColor = chartData.colors;
    achievementPerBreakChart.data.datasets[0].borderColor = chartData.borderColors;
    achievementPerBreakChart.update('none');
}
