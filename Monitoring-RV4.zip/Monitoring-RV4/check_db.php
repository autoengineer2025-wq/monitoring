<?php
include 'database/init.php';
$today = date('Y-m-d');
echo "Today: $today\n";

try {
    $records = $database->select('fproduction_record', '*', [
        'production_date' => $today,
        'Fline_ID' => 1
    ]);

    echo "Records found: " . count($records) . "\n";

    foreach($records as $record) {
        echo "Record ID: " . $record['record_id'] . "\n";
        echo "Shift: " . $record['Shift'] . "\n";
        echo "Plan Target: " . $record['plan_target'] . "\n";
        echo "Break Times:\n";
        for($i=1; $i<=5; $i++) {
            echo "  Break $i: " . ($record["Fstart_Time$i"] ?? 'NULL') . " - " . ($record["Fend_Time$i"] ?? 'NULL') . "\n";
        }
        echo "---\n";
    }
} catch(Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
