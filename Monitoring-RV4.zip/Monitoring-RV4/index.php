<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="node_modules/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/central.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
</head>
<body>
<header class="topbar">
    <div class="topbar-content">
        <h1 class="center-text">CENTRAL OUTPUT MONITORING | v.0.0.2</h1>
        <div class="nav-right">
            <div class="dropdown">
                <button class="dropbtn"><i class="bi bi-gear"></i></button>
                <div class="dropdown-content">
                    <a href="linestatus.php">Line Status</a>
                    <a href="#">About</a>
                </div>
            </div>
        </div>
    </div>
</header>

<div class="button-container">
    <div class="btn-group1" role="group" aria-label="Basic example">
        <button type="button" class="btn">95%</button>
    </div>
    <div class="btn-group2" role="group" aria-label="Basic example">
        <button type="button" class="btn">96% - 99%</button>
    </div>
    <div class="btn-group3" role="group" aria-label="Basic example">
        <button type="button" class="btn">100%</button>
    </div>
    <div class="btn-group4" role="group" aria-label="Basic example">
        <button type="button" class="btn">100% above</button>
    </div>
</div>

<section class="cards-container container-fluid" id="cards-container">
    <!-- Rendered dynamically -->
    <div class="row g-3" id="cards-root"></div>
    <div class="mt-2 text-end">
        <small class="text-muted" >Auto-refreshes every 30s</small>
    </div>
</section>

<section class="table-container">
    <table>
        <thead>
            <tr>
                <th>Line No</th>
                <th>Target</th>
                <th>Actual</th>
                <th>Difference</th>
                <th>Achievement Rate</th>
                <th>Reject Qty</th>
                <th>Reject PPM</th>

            </tr>
        </thead>
        <tbody id="data-table">
        </tbody>
    </table>
    <div class="footer">
        <p>Auto-Department MinebeaMitsumi Philippines</p>
    </div>
<script>
// Global fmt function to avoid scoping issues
function fmt(n){
  const v = Number(n || 0);
  if (Number.isNaN(v)) return '0';
  return v.toLocaleString();
}

(function(){
  const tbody = document.getElementById('data-table');
  const sectionOrder = ['CABLE','FEEDER','USB'];
  let currentShift = 'All';
  let lastJson = null;

  // Function to determine current shift based on time
  function getCurrentShiftByTime() {
    const now = new Date();
    const hour = now.getHours();
    const minute = now.getMinutes();
    const currentTimeInMinutes = hour * 60 + minute;

    const dayStart = 6 * 60;
    const dayEnd = 17 * 60 + 59; 

    const nightStart = 18 * 60;
    const nightEnd = 5 * 60 + 59; 

    if (currentTimeInMinutes >= dayStart && currentTimeInMinutes <= dayEnd) {
      return 'Day';
    } else if (currentTimeInMinutes >= nightStart || currentTimeInMinutes <= nightEnd) {
      return 'Night';
    } else {
      return 'Day';
    }
  }

  function getSortedLineKeys(sectionData){
    const keys = Object.keys(sectionData || {});
    keys.sort((a,b) => {
      const na = parseInt(String(a).replace(/\D/g,'')) || 0;
      const nb = parseInt(String(b).replace(/\D/g,'')) || 0;
      return na - nb;
    });
    return keys;
  }

  function render(data){
    lastJson = data;
    if (!tbody) return;
    tbody.innerHTML = '';
    sectionOrder.forEach(section => {
      const sectionData = (data.sections && data.sections[section]) || {};
      const lineKeys = getSortedLineKeys(sectionData);
      const shiftLoop = currentShift === 'All' ? shifts : [currentShift];
      shiftLoop.forEach(shift => {
        tbody.insertAdjacentHTML('beforeend', `<tr style="background:#f8f9fa;font-weight:bold;"><td colspan="7">${section} — ${shift} Shift</td></tr>`);
        lineKeys.forEach(label => {
          const m = (sectionData[label] && sectionData[label][shift]) || {target:0, actual:0, difference:0, achievement_rate:0, reject_qty:0, reject_ppm:0};
          tbody.insertAdjacentHTML('beforeend', `
            <tr>
              <td>${label}</td>
              <td>${fmt(m.target)}</td>
              <td>${fmt(m.actual)}</td>
              <td>${fmt(m.difference)}</td>
              <td>${fmt(m.achievement_rate)}%</td>
              <td>${fmt(m.reject_qty)}</td>
              <td>${fmt(m.reject_ppm)}</td>
            </tr>
          `);
        });
      });
    });
    renderCards(data);
  }

  function statusClass(pct){
    if (pct >= 101) return 'over';
    if (pct === 100) return 'good';
    if (pct >= 95.5) return 'warn';
    return 'bad';
  }
  function renderCards(data){
    const root = document.getElementById('cards-root');
    if (!root) return;
    root.innerHTML = '';

    sectionOrder.forEach(section => {
      const sectionData = (data.sections && data.sections[section]) || {};
      const lineKeys = getSortedLineKeys(sectionData);
      const shiftLoop = currentShift === 'All' ? shifts : [currentShift];

      shiftLoop.forEach(shift => {
        // Section + Shift header row
        const header = document.createElement('div');
        header.className = 'col-12';
        header.innerHTML = `<div class="section-summary p-1"><h5 class="m-0">${section} — ${shift} Shift</h5></div>`;
        root.appendChild(header);

        lineKeys.forEach(label => {
          const m = (sectionData[label] && sectionData[label][shift]) || {target:0, actual:0, difference:0, achievement_rate:0, reject_qty:0, reject_ppm:0};
          const pct = Number(m.achievement_rate || 0);
          const badge = statusClass(pct);
          const achRing = Math.max(0, Math.min(100, pct));
          const rejRing = Math.max(0, Math.min(100, (Number(m.actual || 0) > 0 ? (Number(m.reject_qty || 0) / Number(m.actual || 1)) * 100 : 0)));

          // Check for no production data
          const hasData = Number(m.target || 0) > 0 || Number(m.actual || 0) > 0 || Number(m.reject_qty || 0) > 0;

          const col = document.createElement('div');
          col.className = 'col-12 col-sm-6 col-md-4 col-lg-2';
          col.innerHTML = `
            <div class="line-card card h-100">
              <div class="card-header">
                <div class="line-title"><i class="bi bi-diagram-3 me-1"></i> ${label.toUpperCase()}</div>
                <div class="rates-labels">
                  <span class="achievement-rate ${pct > 100 ? 'bg-blue' : pct >= 95 ? 'bg-green' : 'bg-red'}">Achievement - ${pct.toFixed ? pct.toFixed(0) : pct}%</span>
                  <span class="reject-rate bg-red">Reject- ${rejRing.toFixed ? rejRing.toFixed(0) : rejRing}%</span>
                </div>
              </div>  
              <div class="card-body">
                ${hasData ? `
                  <div class="metrics-and-chart">
                    <div class="kpi-list">
                      <div class="metric">PLAN:  <span>${fmt(m.target)}</span></div>
                      <div class="metric">OUTPUT: <span>${fmt(m.actual)}</span></div>
                      <div class="metric">DIFFERENCE: <span>${fmt(m.difference)}</span></div>
                      <div class="metric">REJECT: <span>${fmt(m.reject_qty)}</span></div>
                      <div class="metric">REJECT PPM: <span>${fmt(m.reject_ppm)}</span></div>
                    </div>
                    <div class="donut-wrap">
                      <div class="dual-donut" style="--ach:${Math.round(achRing*10)/10}; --rej:${Math.round(rejRing*10)/10}; --size:200px;">
                        <div class="ring outer"></div>
                        <div class="ring inner"></div>
                      </div>

                    </div>
                  </div>
                ` : `
                  <div class="no-production">
                    <i class="bi bi-exclamation-triangle text-warning me-2"></i>
                    No Production
                  </div>
                `}
              </div>
            </div>`;
          root.appendChild(col);
        });
      });
    });
  }

  async function load(dateStr){
    // Automatically set currentShift based on time
    currentShift = getCurrentShiftByTime();

    // Update the dropdown to reflect the current shift
    const shiftSel = document.getElementById('shiftFilter');
    if (shiftSel) {
      shiftSel.value = currentShift;
    }

    const url = 'central_monitoring_api.php?date=' + encodeURIComponent(dateStr || new Date().toISOString().slice(0,10));
    try{
      const res = await fetch(url, { cache: 'no-store' });
      const text = await res.text();
      let json;
      try { json = JSON.parse(text); } catch(parseErr) {
        throw new Error(`HTTP ${res.status} ${res.statusText} | Response: ${text.slice(0,200)}`);
      }
      if (!json || json.success !== true) {
        const msg = json && (json.message || json.error) ? ` | ${json.message || json.error}` : '';
        throw new Error(`API error${msg}`);
      }
      render(json);
    }catch(err){
      console.error('Failed to load monitoring data:', err);
      if (tbody) tbody.innerHTML = `<tr><td colspan="7" style="color:#dc3545;">Failed to load data. ${String(err.message || err).slice(0,300)}</td></tr>`;
    }
  }

  function updateClock(){
    const now = new Date();
    const d = document.getElementById('currentDate');
    const t = document.getElementById('currentTime');
    if (d) d.textContent = now.toLocaleDateString();
    if (t) t.textContent = now.toLocaleTimeString();
  }

  // Init
  updateClock();
  setInterval(updateClock, 1000);
  load();
  setInterval(() => load(), 30000);

  // Optional: backup button hook placeholder
  const backupBtn = document.getElementById('backupButton');
  if (backupBtn) {
    backupBtn.addEventListener('click', function(){
      alert('Backup feature not implemented yet.');
    });
  }

  // Shift filter
  const shiftSel = document.getElementById('shiftFilter');
  if (shiftSel) {
    shiftSel.addEventListener('change', function(){
      currentShift = shiftSel.value;
      if (lastJson) { render(lastJson); } else { load(); }
    });
  }
})();
</script>
</body>
</html>
