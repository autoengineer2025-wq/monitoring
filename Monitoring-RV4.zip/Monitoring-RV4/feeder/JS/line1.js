// Fetch all drawing numbers and their details for dropdowns
let drawingList = [];
let selectedProdHours = null; // hours from selected production time (e.g., 10.25)
const FLOAT_EPSILON = 1e-6;

function fetchDrawingList() {
  return $.getJSON('../API/drawing_api.php?action=get_drawings', function(data) {
    drawingList = data;
  });
}

function toggleDrawingFields() {
  var mCount = parseInt(document.getElementById('mCount').value);
  var drawingFields = document.getElementById('drawingFields');
  drawingFields.innerHTML = '';
  if (!isNaN(mCount) && mCount > 0) {
    drawingFields.style.display = 'block';
    if (!Array.isArray(drawingList) || drawingList.length === 0) {
      fetchDrawingList()
        .then(() => {
          try { toggleDrawingFields(); } catch (e) { console.error('Render failed after fetch:', e); }
        })
        .catch(err => {
          console.error('Failed to load drawing list:', err);
          drawingFields.innerHTML = '<div class="text-danger">Failed to load drawing list. Please try again.</div>';
        });
      return;
    }
    for (let i = 1; i <= mCount; i++) {
      let options = '<option value="">Select drawing number</option>';
      drawingList.forEach(d => {
        const label = d.Fdrawingnum || d.Fdrawing_ID;
        options += `<option value="${d.Fdrawing_ID}">${label}</option>`;
      });
      drawingFields.innerHTML += `
      <div class="row mb-2">
        <div class="col-md">
          <label for="drawingNumber${i}" class="form-label">Drawing Number ${i}</label>
          <select class="form-select" id="drawingNumber${i}" name="Fdrawing_ID${i}" onchange="setDrawingDetails(${i})">
            ${options}
          </select>
        </div>
        <div class="col-md">
          <label for="taktTime${i}" class="form-label">Takt Time</label>
          <input type="text" class="form-control" id="taktTime${i}" name="takttime${i}" readonly>
        </div>
        <div class="col-md">
          <label for="length${i}" class="form-label">Length</label>
          <input type="text" class="form-control" id="length${i}" name="length${i}" readonly>
        </div>
        <div class="col-md">
          <label for="qty${i}" class="form-label">Qty</label>
          <input type="number" class="form-control" id="qty${i}" name="qty${i}" min="1" oninput="computeWorkingHours(${i})">
        </div>
        <div class="col-md">
          <label for="workingHours${i}" class="form-label">Working Hours</label>
          <input type="text" class="form-control" id="workingHours${i}" name="workingHours${i}" readonly>
        </div>
      </div>
      `;
    }
  } else {
    drawingFields.style.display = 'none';
  }

  // Also refresh achievement chart to reflect new target
  if (typeof updateAchievementChart === 'function') {
    try { updateAchievementChart(); } catch(e) {}
  }
}

function setDrawingDetails(idx) {
  const val = $(`#drawingNumber${idx}`).val();
  const found = drawingList.find(d => d.Fdrawing_ID == val);
  if (found) {
    $(`#taktTime${idx}`).val(found.takttime);
    $(`#length${idx}`).val(found.length);
    computeWorkingHours(idx);
  } else {
    $(`#taktTime${idx}`).val('');
    $(`#length${idx}`).val('');
    $(`#workingHours${idx}`).val('');
  }
}

// Compute working hours when qty is entered
function computeWorkingHours(idx) {
  let takttimeVal = $(`#taktTime${idx}`).val();
  const qtyVal = $(`#qty${idx}`).val();

  // If takttime is empty but a drawing is selected, try to auto-fill from drawingList
  if ((!takttimeVal || takttimeVal === '') && Array.isArray(drawingList) && drawingList.length > 0) {
    const selectedDid = $(`#drawingNumber${idx}`).val();
    if (selectedDid) {
      const found = drawingList.find(d => String(d.Fdrawing_ID) === String(selectedDid));
      if (found) {
        if (found.takttime != null) { $(`#taktTime${idx}`).val(found.takttime); takttimeVal = String(found.takttime); }
        if (found.length != null) { $(`#length${idx}`).val(found.length); }
      }
    }
  }

  const takttime = parseFloat(takttimeVal);
  const qty = parseInt(qtyVal, 10);

  if (isNaN(takttime) || isNaN(qty) || takttime <= 0 || qty < 0) {
    $(`#workingHours${idx}`).val('');
    return;
  }

  let workingHours = (takttime * qty) / 3600;

  if (selectedProdHours && !isNaN(selectedProdHours)) {
    const mCount = parseInt($('#mCount').val()) || 0;
    let sumOthers = 0;

    for (let i = 1; i <= mCount; i++) {
      if (i === idx) continue;
      const otherWH = parseFloat($(`#workingHours${i}`).val());
      if (!isNaN(otherWH)) sumOthers += otherWH;
    }

    const remaining = selectedProdHours - sumOthers;

    if (remaining <= 0) {
      // No hours left
      $(`#qty${idx}`).val(0);
      workingHours = 0;
    } else if (workingHours > remaining + FLOAT_EPSILON) {
      // Cap to remaining hours
      const maxQty = Math.floor((remaining * 3600) / takttime);
      const adjustedQty = Math.max(0, maxQty);
      $(`#qty${idx}`).val(adjustedQty);
      workingHours = (adjustedQty * takttime) / 3600;
    }
  }

  // Update field
  $(`#workingHours${idx}`).val(workingHours.toFixed(2));
}

// Helper to style remark select based on classification and disable it
function applyRemarkStyleAndLock($select, classification) {
  $select.prop('disabled', true);
  const colorMap = {
    'Parts problem': '#ffc107',
    'Machine problem': '#dc3545',
    'Change model': '#0d6efd',
    'Lack of man power': '#17a2b8'
  };
  const bg = colorMap[classification] || '#6c757d';
  const fg = '#ffffff';
  $select.css({ 'background-color': bg, 'color': fg, 'border-color': bg });
}

function cleanupModalArtifacts() {
  const anyOpen = document.querySelectorAll('.modal.show').length > 0;
  if (!anyOpen) {
    document.querySelectorAll('.modal-backdrop').forEach(el => el.remove());
    document.body.classList.remove('modal-open');
    document.body.style.overflow = '';
    document.body.style.paddingRight = '';
  } else {
    const backs = document.querySelectorAll('.modal-backdrop');
    if (backs.length > 1) {
      backs.forEach((el, idx) => { if (idx > 0) el.remove(); });
    }
  }
}

$(document).ready(function() {
  // Ensure a global focus sentinel exists to safely move focus
  if (!document.getElementById('focus-sentinel')) {
    const sentinel = document.createElement('div');
    sentinel.id = 'focus-sentinel';
    sentinel.tabIndex = -1;
    sentinel.style.position = 'fixed';
    sentinel.style.width = '1px';
    sentinel.style.height = '1px';
    sentinel.style.overflow = 'hidden';
    sentinel.style.left = '-9999px';
    document.body.appendChild(sentinel);
  }
  fetchDrawingList().then(() => {
    // If user already selected a model count, re-render fields
    if ($('#mCount').val()) toggleDrawingFields();
  });
  
  // Initialize output cell functionality
  initializeOutputCells();
  
  // Ensure initial difference styling on load
  try { updateAllDifferences(); } catch(e) {}
  
  setTimeout(function() {
    const firstAvailable = findNextAvailableBreak();
    if (firstAvailable.length > 0) {
      firstAvailable.addClass('active-break');
    }
  }, 100);

  // Lock and style any pre-selected remark classification (already saved)
  $('.remark-classification-select').each(function(){
    const $sel = $(this);
    const val = $sel.val();
    if (val) {
      applyRemarkStyleAndLock($sel, val);
    }
  });

  // If shift is over, disable editing and show banner
  try {
    if (isShiftOver()) {
      // Disable output cell interactions
      $('.output-cell').addClass('disabled-after-cutoff').css({
        pointerEvents: 'none',
        opacity: 0.6,
        cursor: 'not-allowed'
      });
      // Insert banner at top if not present
      if ($('#shift-finished-banner').length === 0) {
        const banner = $(
          '<div id="shift-finished-banner" class="alert alert-info py-2 mb-2" role="alert">'
          + '<strong>Shift finished.</strong> Target is capped to plan and editing is disabled until a new record is created.'
          + '</div>'
        );
        const container = $('.container-fluid, .p-4, body').first();
        container.prepend(banner);
      }
    }
  } catch(e) {}

  const remarksEl = document.getElementById('remarksModal');
  if (remarksEl) {
    $(remarksEl).on('mousedown', '[data-bs-dismiss="modal"], .btn-close', function() {
      try {
        this.blur();
        const sentinel = document.getElementById('focus-sentinel');
        if (sentinel) sentinel.focus();
      } catch(e) {  }
    });

    remarksEl.addEventListener('hide.bs.modal', function() {
      const sentinel = document.getElementById('focus-sentinel');
      if (this.contains(document.activeElement) && sentinel) {
        sentinel.focus();
      }
    });
    remarksEl.addEventListener('hidden.bs.modal', function() {
      cleanupModalArtifacts();
      try {
        if (window.__remarksLastFocus && document.contains(window.__remarksLastFocus)) {
          window.__remarksLastFocus.focus();
        }
      } catch(e) { }
    });
  }

  // Ensure real-time target and difference auto-refresh without user interaction
  try {
    // Initial compute on load
    if (typeof updateRealTimeTarget === 'function') {
      updateRealTimeTarget();
    }
    // Periodic refresh every 15 seconds
    window.__rt_target_timer = window.setInterval(function(){
      try {
        if (typeof updateRealTimeTarget === 'function') {
          updateRealTimeTarget();
        }
      } catch(e) { /* noop */ }
    }, 15000);
  } catch(e) { /* noop */ }
});

function initializeOutputCells() {
  $('.output-cell').on('click', function() {
    $(this).addClass('editable');
    $(this).attr('contenteditable', 'true');
    $(this).focus();
  });
  
  $(document).on('keydown', '.output-cell', function(e) {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      updateOutput($(this));
    }
  });
  
  $(document).on('keydown', function(e) {
    if (e.key !== 'Enter' && e.key !== ' ') return;

    const t = e.target;
    const tag = (t.tagName || '').toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
    if ($(t).is('[contenteditable="true"]')) return;
    if ($('.modal.show').length > 0 || $(t).closest('.modal').length > 0) return;

    const availableCell = findNextAvailableBreak();
    if (availableCell.length > 0) {
      e.preventDefault();
      updateOutput(availableCell);
    }
  });
  
  // Handle blur event to remove editable state
  $(document).on('blur', '.output-cell', function() {
    $(this).removeClass('editable');
    $(this).removeAttr('contenteditable');
  });
}

// Update output for a specific break
function updateOutput(cell) {
  const breakNumber = cell.data('break');
  const recordId = cell.data('record');
  
  if (!recordId) {
    alert('No production record found. Please save settings first.');
    return;
  }

  // Prevent updates after shift cutoff
  try {
    if (isShiftOver()) {
      showNotification('Shift finished. Editing is disabled until a new record is created.', 'error');
      return;
    }
  } catch(e) {}
  
  // Highlight current break
  $('.output-cell').removeClass('active-break');
  cell.addClass('active-break');
  
  // Show loading state
  cell.addClass('loading');
  
  $.ajax({
    url: 'API/update_qty.php',
    method: 'POST',
    contentType: 'application/json',
    data: JSON.stringify({
      record_id: recordId,
      break_number: breakNumber,
      output_value: 1 // This will be added to current value
    }),
    success: function(response) {
      cell.removeClass('loading');
      
             if (response.success) {
         // Update multiple cells if overflow occurred
         if (response.data.overflow_handled) {
           // Remove any existing overflow indicators
           $('.output-cell').removeClass('overflow-indicator');
           
           // Update all affected cells
           Object.keys(response.data.updated_breaks).forEach(key => {
             if (key.startsWith('actual')) {
               const breakNum = key.replace('actual', '');
               const cell = $(`.output-cell[data-break="${breakNum}"]`);
               if (cell.length > 0) {
                 cell.text(response.data.updated_breaks[key]);
                 // Add overflow indicator to cells that were updated due to butal
                 if (breakNum != response.data.break_number) {
                   cell.addClass('overflow-indicator');
                   // Remove indicator after 3 seconds
                   setTimeout(() => cell.removeClass('overflow-indicator'), 3000);
                 }
               }
             }
           });
           
           // Show sequential butal message
           const updatedBreaks = Object.keys(response.data.updated_breaks)
             .filter(key => key.startsWith('actual'))
             .map(key => key.replace('actual', ''))
             .filter(breakNum => breakNum != response.data.break_number);
           
           if (updatedBreaks.length > 0) {
             const butalMessage = `Excess output flowed to break(s): ${updatedBreaks.join(', ')}`;
             showNotification(butalMessage, 'success');
           }
         } else {
           const breakNum = response.data.break_number;
           const cell = $(`.output-cell[data-break="${breakNum}"]`);
           if (cell.length > 0) {
             cell.text(response.data.updated_breaks[`actual${breakNum}`]);
           }
           
           showNotification('Output updated successfully!', 'success');
         }
         
         updateAccumulatedActual();
         
         for (let i = 1; i <= 5; i++) {
           updateDifference(i);
         }
         
         setTimeout(function() {
           const nextBreak = findNextAvailableBreak();
           if (nextBreak.length > 0) {
             $('.output-cell').removeClass('active-break');
             nextBreak.addClass('active-break');
           }
         }, 500);

         // Persist analytics snapshot after successful output update
         persistBreakSnapshot(recordId);
       } else {
        showNotification(response.message, 'error');
      }
    },
    error: function(xhr, status, error) {
      cell.removeClass('loading');
      showNotification('Error updating output: ' + error, 'error');
    }
  });
}

function updateAccumulatedActual() {
  let accu = 0;
  $('.output-cell').each(function(index) {
    const value = parseInt($(this).text()) || 0;
    accu += value;
    $(this).siblings('.actual-accu-cell').text(accu);
  });
  
  // Update total actual in the dashboard
  const totalActual = accu;
  const actualElement = document.getElementById('total-actual');
  if (actualElement) {
    actualElement.textContent = totalActual;
  } else {
    $('.card-value.text-dark').text(totalActual);
  }
  
  let realTimeTarget = 0;
  if (typeof calculateRealTimeTarget === 'function') {
    realTimeTarget = calculateRealTimeTarget();
  } else {
    // Fallback to static plan target if real-time function not available
    realTimeTarget = parseInt($('.card-value.text-primary').text()) || 0;
  }
  
  const difference = totalActual - realTimeTarget;
  
  // Update both target and difference elements
  const targetElement = document.getElementById('real-time-target');
  const differenceElement = document.getElementById('real-time-difference');
  
  if (targetElement) {
    targetElement.textContent = realTimeTarget;
  }
  
  if (differenceElement) {
    // Format and style KPI difference
    const val = parseInt(difference, 10) || 0;
    differenceElement.textContent = (val === 0 ? '-' : val);
    differenceElement.classList.remove('text-success','text-danger');
    if (val > 0) differenceElement.classList.add('text-success');
    if (val < 0) differenceElement.classList.add('text-danger');
  } else {
    // Fallback to jQuery selector if ID not found
    const $el = $('.card-value.text-danger');
    const val = parseInt(difference, 10) || 0;
    $el.text(val === 0 ? '-' : val)
       .removeClass('text-success text-danger')
       .addClass(val > 0 ? 'text-success' : (val < 0 ? 'text-danger' : ''));
  }
  
  // Trigger chart refresh when output is updated
  if (typeof refreshChartData === 'function') {
    setTimeout(function() {
      refreshChartData();
    }, 500); 
  }
  
  if (typeof updateAchievementPerBreakChart === 'function') {
    setTimeout(function() {
      updateAchievementPerBreakChart();
    }, 500); 
  }
  
  if (typeof updateAchievementChart === 'function') {
    setTimeout(function() {
      updateAchievementChart();
    }, 500); 
  }

  // Keep per-break and accumulated differences in sync in real time
  if (typeof updateAllDifferences === 'function') {
    updateAllDifferences();
  }
}

// Persist per-break analytics snapshot for the current record (fire-and-forget)
function persistBreakSnapshot(recordId) {
  if (!recordId) return;
  try {
    $.post('API/save_break_snapshot.php', { record_id: recordId })
      .always(function(){ /* no-op */ });
  } catch(e) { /* ignore */ }
}

// Update difference (per-break and accumulated) values
function updateDifference(breakNumber) {
  const $cell = $(`.output-cell[data-break="${breakNumber}"]`);
  if ($cell.length === 0) return;
  const planOutput = parseInt($cell.siblings('.plan-output-cell').text()) || 0;
  const actualOutput = parseInt($cell.text()) || 0;
  const difference = actualOutput - planOutput;
  const $diffCell = $cell.siblings('.difference-cell');
  $diffCell.text(difference === 0 ? '-' : difference)
           .removeClass('text-success text-danger')
           .addClass(difference > 0 ? 'text-success' : (difference < 0 ? 'text-danger' : ''));

  const planAccu = parseInt($cell.siblings('.plan-accu-cell').text()) || 0;
  const actualAccu = parseInt($cell.siblings('.actual-accu-cell').text()) || 0;
  const diffAccu = actualAccu - planAccu;
  const $diffAccuCell = $cell.siblings('.diff-accu-cell');
  $diffAccuCell.text(diffAccu === 0 ? '-' : diffAccu)
               .removeClass('text-success text-danger')
               .addClass(diffAccu > 0 ? 'text-success' : (diffAccu < 0 ? 'text-danger' : ''));
}

// Update all differences in the table
function updateAllDifferences() {
  for (let i = 1; i <= 5; i++) {
    updateDifference(i);
  }
}

// Recalculate and render accumulated reject column
function updateRejectAccumulated() {
  let running = 0;
  for (let i = 1; i <= 5; i++) {
    const val = parseInt($(`.reject-input[data-break="${i}"]`).val()) || 0;
    running += val;
    $(`.reject-accu-cell[data-break="${i}"]`).text(running);
  }
}

// Find the next available break that can be updated
function findNextAvailableBreak() {
  let currentActiveBreak = 0;
  
  // Find currently active break
  $('.output-cell.active-break').each(function() {
    currentActiveBreak = $(this).data('break');
  });
  
  // Look for the next break that can be updated (prioritize breaks 1-4)
  for (let i = 1; i <= 4; i++) {
    const cell = $(`.output-cell[data-break="${i}"]`);
    if (cell.length > 0 && cell.data('record')) {
      const planOutput = parseInt(cell.siblings('.plan-output-cell').text()) || 0;
      const actualOutput = parseInt(cell.text()) || 0;
      
      // If this break is not completed yet, it's available
      if (actualOutput < planOutput) {
        return cell;
      }
    }
  }
  
  // If no break 1-4 is available, check break 5 (unlimited break)
  const cell5 = $('.output-cell[data-break="5"]');
  if (cell5.length > 0 && cell5.data('record')) {
    // Break 5 has no restrictions - always available
    return cell5;
  }
  
  // If no break is available, return the first one
  return $('.output-cell').first();
}

// Show notification
function showNotification(message, type) {
  const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
  const notification = $(`
    <div class="alert ${alertClass} alert-dismissible fade show position-fixed" 
         style="top: 20px; right: 20px; z-index: 9999; min-width: 300px;">
      ${message}
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
  `);
  
  $('body').append(notification);
  
  // Auto remove after 3 seconds
  setTimeout(function() {
    notification.alert('close');
  }, 3000);
}

// Save button handler
$('#saveSettingsBtn').on('click', function() {
  // Collect main form data
  const formData = {};
  formData.production_date = $('#prodDate').val();
  formData.Fprod_ID = $('#prodTime').val();
  formData.Fline_ID = $('#lineNumber').val();
  formData.shift = $('#shift').val();
  formData.mCount = $('#mCount').val();

  // === TOP-LEVEL VALIDATION ===
  if (!formData.production_date) {alert("Please select a Production Date.");
    return;
  }
  if (!formData.Fprod_ID) {
    alert("Please select a Production Time.");
    return;
  }
  if (!formData.Fline_ID) {
    alert("Please select a Line Number.");
    return;
  }
  if (!formData.shift) {
    alert("Please select a Shift.");
    return;
  }
  if (!formData.mCount || parseInt(formData.mCount) <= 0) {
    alert("Please select the number of models.");
    return;
  }

  const mCount = parseInt(formData.mCount, 10);

  // === MODEL-LEVEL VALIDATION ===
  for (let i = 1; i <= mCount; i++) {
    const drawingId = $(`#drawingNumber${i}`).val();
    const qty = parseInt($(`#qty${i}`).val(), 10);

    if (!drawingId) {
      alert(`Please select a Drawing Number for Model ${i}.`);
      return;
    }
    if (isNaN(qty) || qty <= 0) {
      alert(`Please enter a valid Quantity for Model ${i}.`);
      return;
    }

    // Add fields to formData
    formData[`Fdrawing_ID${i}`] = drawingId;
    formData[`takttime${i}`] = $(`#taktTime${i}`).val();
    formData[`length${i}`] = $(`#length${i}`).val();
    formData[`qty${i}`] = qty;
    formData[`workingHours${i}`] = $(`#workingHours${i}`).val();
  }

  // === TOTAL WORKING HOURS VALIDATION ===
  if (selectedProdHours && !isNaN(selectedProdHours)) {
    let totalWH = 0;
    for (let i = 1; i <= mCount; i++) {
      const wh = parseFloat(formData[`workingHours${i}`] || '0');
      if (!isNaN(wh)) totalWH += wh;
    }
    if (totalWH > selectedProdHours + FLOAT_EPSILON) {
      alert(`Total working hours (${totalWH.toFixed(2)}) exceed selected production time (${selectedProdHours}). Please adjust quantities.`);
      return;
    }
  }

  // === BREAK TIME FIELDS ===
  for (let i = 1; i <= 5; i++) {
    formData[`Fstart_Time${i}`] = $(`#Fstart_Time${i}`).val();
    formData[`Fend_Time${i}`] = $(`#Fend_Time${i}`).val();
  }

  // === SEND TO BACKEND ===
  console.log('Sending data to server:', formData);
  $.post('API/prod_api.php', formData, function(response) {
    console.log('Server response:', response);
    let res = {};
    try {
      res = typeof response === 'string' ? JSON.parse(response) : response;
    } catch(e) {
      console.error('JSON parse error:', e);
      alert("Invalid response from server.");
      return;
    }
    if (res.success) {
      // Close the modal first
      (function(){
        const el = document.getElementById('settingsModal');
        if (el && window.bootstrap && bootstrap.Modal) {
          const modal = bootstrap.Modal.getOrCreateInstance(el);
          modal.hide();
        }
      })();
      
      // Show success message
      alert('Data saved successfully! Redirecting...');

      // Use server response first, fallback to local formData
      const lineId = res.Fline_ID || formData.Fline_ID;
      const shiftVal = res.shift || formData.shift;
      const newRecordId = res.record_id || '';

      // Fire initial snapshot so fproduction_breaks is populated immediately
      if (newRecordId) {
        try { $.post('API/save_break_snapshot.php', { record_id: newRecordId }); } catch(e) {}
      }

      const params = new URLSearchParams({
        line: lineId,
        shift: shiftVal
      }).toString();
      const redirectUrl = `line${lineId}.php?${params}`;
      console.log('Redirecting to:', redirectUrl);

      // Try multiple redirect methods
      try {
        window.location.href = redirectUrl;
      } catch (e) {
        console.error('Redirect failed:', e);
        window.location.replace(redirectUrl);
      }
    } else {
      alert(res.message || 'Save failed.');
    }
  });
});

$('#prodTime').on('change', function() {
  var prodId = $(this).val();
  if (prodId) {
    $.getJSON('API/get_production_time.php', { id: prodId }, function(data) {
      selectedProdHours = data && data.Fprod_hours ? parseFloat(data.Fprod_hours) : null;
      for (let i = 1; i <= 5; i++) {
        $('#Fstart_Time' + i).val(data['Fstart_Time' + i] || '');
        $('#Fend_Time' + i).val(data['Fend_Time' + i] || '');
      }
      // Recompute and cap existing working hours if needed
      const mCount = parseInt($('#mCount').val()) || 0;
      for (let i = 1; i <= mCount; i++) {
        computeWorkingHours(i);
      }
    });
  } else {
    selectedProdHours = null;
    for (let i = 1; i <= 5; i++) {
      $('#Fstart_Time' + i).val('');
      $('#Fend_Time' + i).val('');
    }
  }
});


function calculateRealTimeTarget() {
  // Read overall plan target to clamp the result
  const planTargetInput = document.getElementById('plan_target');
  const planTarget = parseInt(planTargetInput ? planTargetInput.value : '0', 10) || 0;
  if (planTarget <= 0) return 0;

  // Helper: parse int safely
  const toInt = (v) => { const n = parseInt(v, 10); return isNaN(n) ? 0 : n; };

  const now = new Date();
  // Prefer the record's production_date from hidden input to anchor windows
  const prodDateInput = document.querySelector('input[name="production_date"]');
  const baseDate = (prodDateInput && prodDateInput.value) ? prodDateInput.value : now.toISOString().split('T')[0];

  // Build time windows from hidden inputs
  function buildWindows(forDate) {
    const list = [];
    let lastEnd = null;
    for (let i = 1; i <= 5; i++) {
      const si = document.getElementById(`start_time_${i}`);
      const ei = document.getElementById(`end_time_${i}`);
      if (!si || !ei) continue;
      const s = (si.value || '').trim();
      const e = (ei.value || '').trim();
      if (!s || !e) continue;
      if (s === '00:00:00' && e === '00:00:00') continue;
      let start = new Date(`${forDate}T${s}`);
      let end = new Date(`${forDate}T${e}`);
      // Roll windows forward so the sequence strictly increases across midnight
      if (lastEnd && start <= lastEnd) {
        // move start to next day until it's after lastEnd
        while (start <= lastEnd) start.setDate(start.getDate() + 1);
      }
      if (end <= start) {
        // ensure end is after start (cross-midnight)
        while (end <= start) end.setDate(end.getDate() + 1);
      }
      list.push({ index: i, start, end });
      lastEnd = end;
    }
    return list;
  }

  // Build windows for base date and previous date to handle cross-midnight night shifts
  const windowsToday = buildWindows(baseDate);
  const prev = new Date(baseDate);
  prev.setDate(prev.getDate() - 1);
  const baseDatePrev = prev.toISOString().split('T')[0];
  const windowsYesterday = buildWindows(baseDatePrev);

  function chooseActiveWindows() {
    const sets = [windowsToday, windowsYesterday];
    // Prefer the set whose overall span contains 'now'
    for (const set of sets) {
      if (!set || set.length === 0) continue;
      const minStart = Math.min(...set.map(w => +w.start));
      const maxEnd = Math.max(...set.map(w => +w.end));
      if (+now >= minStart && +now <= maxEnd) return set;
    }
    // Fallback: most recent start within 12 hours
    const TWELVE_HOURS_MS = 12 * 60 * 60 * 1000;
    let best = null;
    let bestStart = -Infinity;
    for (const set of sets) {
      if (!set || set.length === 0) continue;
      const recentStarts = set.map(w => +w.start).filter(s => s <= +now && (+now - s) <= TWELVE_HOURS_MS);
      if (recentStarts.length > 0) {
        const candidate = Math.max(...recentStarts);
        if (candidate > bestStart) { bestStart = candidate; best = set; }
      }
    }
    // Last resort: earliest start among non-empty sets
    if (!best) {
      const candidates = sets.filter(s => s && s.length > 0).map(s => ({ s, start: Math.min(...s.map(w => +w.start)) }));
      if (candidates.length === 0) return [];
      candidates.sort((a,b) => a.start - b.start);
      best = candidates[0].s;
    }
    return best || [];
  }
  const windows = chooseActiveWindows();

  // If shift is over, clamp to plan target
  try {
    const shiftInput = document.querySelector('input[name="shift"]');
    const shiftLabel = (shiftInput && shiftInput.value ? shiftInput.value : '').toLowerCase();
    if (baseDate) {
      const now = new Date();
      let cutoff;
      if (shiftLabel.includes('night')) {
        // 06:00 next day
        cutoff = new Date(baseDate + 'T06:00:00');
        cutoff.setDate(cutoff.getDate() + 1);
      } else {
        // 18:00 same day
        cutoff = new Date(baseDate + 'T18:00:00');
      }
      if (cutoff && now >= cutoff) {
        return planTarget;
      }
    }
  } catch(e) {}

  if (windows.length === 0) return 0;

  // Determine shiftStart as the earliest window that began within the last 12 hours, else earliest window start
  const TWELVE_HOURS_MS = 12 * 60 * 60 * 1000;
  const recentStarts = windows.filter(w => w.start <= now && (+now - w.start) <= TWELVE_HOURS_MS).map(w => +w.start);
  const shiftStart = recentStarts.length > 0 ? new Date(Math.min(...recentStarts)) : new Date(Math.min(...windows.map(w => +w.start)));

  function elapsedClamped(start, end) {
    if (now <= start) return 0;
    const effStart = start < shiftStart ? shiftStart : start;
    const effEnd = now < end ? now : end;
    if (effEnd <= effStart) return 0;
    return Math.floor((effEnd - effStart) / 1000);
  }

  // Read per-break plan outputs from the analytics table to mirror server allocation logic
  const planCells = document.querySelectorAll('.plan-output-cell');
  const planByBreak = [];
  planCells.forEach((cell, idx) => { planByBreak[idx + 1] = toInt((cell.textContent || '').trim()); });

  let cumulativeTarget = 0;
  const debugRows = [];
  for (const w of windows) {
    const planForThisBreak = planByBreak[w.index] || 0;
    if (planForThisBreak <= 0) continue;

    const totalSeconds = Math.max(0, Math.floor((w.end - w.start) / 1000));
    if (totalSeconds <= 0) continue;

    const elapsed = elapsedClamped(w.start, w.end);
    if (elapsed <= 0) continue;

    // Pro-rate plan output within the current window based on elapsed time
    const fraction = Math.max(0, Math.min(1, elapsed / totalSeconds));
    const contribution = Math.floor(planForThisBreak * fraction);
    cumulativeTarget += contribution;

    if (window.DEBUG_RT_TARGET) {
      debugRows.push({
        break: w.index,
        plan: planForThisBreak,
        start: w.start.toISOString(),
        end: w.end.toISOString(),
        totalSeconds,
        elapsed,
        fraction: Number(fraction.toFixed(4)),
        contribution
      });
    }
  }

  // Fallback smoothing: if per-break allocation leads to a flat target (e.g., plan for current break = 0),
  // compute an overall shift-based estimate using elapsed across all active windows.
  // Then take the max of detailed per-break target and this estimate, still clamped to planTarget.
  let totalShiftSeconds = 0;
  let elapsedShiftSeconds = 0;
  try {
    const allWindows = windows;
    for (const w of allWindows) {
      const span = Math.max(0, Math.floor((w.end - w.start) / 1000));
      totalShiftSeconds += span;
      elapsedShiftSeconds += elapsedClamped(w.start, w.end);
    }
  } catch(e) { totalShiftSeconds = 0; elapsedShiftSeconds = 0; }
  let fallbackEstimate = 0;
  if (totalShiftSeconds > 0 && elapsedShiftSeconds > 0) {
    const frac = Math.max(0, Math.min(1, elapsedShiftSeconds / totalShiftSeconds));
    fallbackEstimate = Math.floor(planTarget * frac);
  }

  // Never exceed the overall plan target
  const clamped = Math.min(Math.max(cumulativeTarget, fallbackEstimate), planTarget);
  if (window.DEBUG_RT_TARGET) {
    try {
      console.log('RT Target Debug -> planTarget:', planTarget, 'cumulativeTarget:', cumulativeTarget, 'fallbackEstimate:', fallbackEstimate, 'clamped:', clamped);
      console.table(debugRows);
    } catch(e) {}
  }
  return clamped;
}

function updateRealTimeTarget() {
  const targetElement = document.getElementById('real-time-target');
  const differenceElement = document.getElementById('real-time-difference');
  const actualElement = document.getElementById('total-actual');

  const realTimeTarget = calculateRealTimeTarget();
  if (targetElement) {
    targetElement.textContent = realTimeTarget;
  }
  if (differenceElement && actualElement) {
    const actualValue = parseInt(actualElement.textContent) || 0;
    const difference = actualValue - realTimeTarget;
    const val = parseInt(difference, 10) || 0;
    differenceElement.textContent = (val === 0 ? '-' : val);
    differenceElement.classList.remove('text-success','text-danger');
    if (val > 0) differenceElement.classList.add('text-success');
    if (val < 0) differenceElement.classList.add('text-danger');
  }
}

document.addEventListener('DOMContentLoaded', function() {

  $(document).on('change', '.remark-classification-select', function() {
      const classification = $(this).val();
      const breakNum = $(this).data('break');
      if (!classification) return;
      // Remember the triggering element to restore focus later
      window.__remarksLastFocus = document.activeElement;
      $('#remarksBreak').val(breakNum);
      $('#remarksClassification').val(classification);
      $('#remarksClassificationView').val(classification);
      // Prefill existing values if any
      const existingReason = $(`.remark-reason[data-break="${breakNum}"]`).text().trim();
      const existingCounter = $(`.remark-countermeasure[data-break="${breakNum}"]`).text().trim();
      $('#remarksReason').val(existingReason);
      $('#remarksCountermeasure').val(existingCounter);
      const modal = new bootstrap.Modal(document.getElementById('remarksModal'));
      modal.show();
  });

  $('#saveRemarksBtn').on('click', function() {
      const breakNum = $('#remarksBreak').val();
      const classification = $('#remarksClassification').val();
      const reason = $('#remarksReason').val().trim();
      const countermeasure = $('#remarksCountermeasure').val().trim();

      if (!reason || !countermeasure) {
          alert('Please fill in both Reason and Countermeasure.');
          return;
      }

      const recordId = $('#recordId').val() || $('input[name="record_id"]').val() || '';
      let lineId = $('input[name="line_id"]').val() || $('#lineNumber').val() || '';
      let shift = $('input[name="shift"]').val() || $('#shift').val() || '';
      const urlParams = new URLSearchParams(window.location.search);
      if (!lineId && urlParams.get('line')) lineId = urlParams.get('line');
      if (!shift && urlParams.get('shift')) shift = urlParams.get('shift');
      const productionDate = $('input[name="production_date"]').val() || $('#prodDate').val() || new Date().toISOString().split('T')[0];

      $.ajax({
          url: 'API/save_remarks.php',
          method: 'POST',
          dataType: 'json',
          data: {
              record_id: recordId,
              line_id: lineId,
              shift: shift,
              production_date: productionDate,
              break_number: breakNum,
              classification: classification,
              reason: reason,
              countermeasure: countermeasure
          },
          success: function(res) {
              if (res && res.success) {
                  const $select = $(`.remark-classification-select[data-break="${breakNum}"]`);
                  $select.val(classification);
                  $(`.remark-reason[data-break="${breakNum}"]`).text(reason);
                  $(`.remark-countermeasure[data-break="${breakNum}"]`).text(countermeasure);

                  // Disable select and apply background color to reflect saved state
                  $select.prop('disabled', true);
                  try {
                      const colorMap = {
                          'Parts problem': '#ffc107',   
                          'Machine problem': '#dc3545',   
                          'Change model': '#0d6efd',     
                          'Lack of man power': '#17a2b8' 
                      };
                      const bg = colorMap[classification] || '#6c757d'; 
                      const fg = '#ffffff';
                      $select.css({ 'background-color': bg, 'color': fg, 'border-color': bg });
                  } catch(e) { }

                  // Move focus outside modal before hiding, then hide immediately
                  try {
                      const modalEl = document.getElementById('remarksModal');
                      const sentinel = document.getElementById('focus-sentinel');
                      if (sentinel) { sentinel.focus(); }
                      const inst = bootstrap.Modal.getInstance(modalEl);
                      if (inst) inst.hide();
                  } catch (e) {
                      const inst = bootstrap.Modal.getInstance(document.getElementById('remarksModal'));
                      if (inst) inst.hide();
                  }

                  // Persist analytics snapshot after saving remarks
                  persistBreakSnapshot(recordId);

              } else {
                  alert(res && res.message ? res.message : 'Failed to save remarks.');
              }
          },
          error: function(xhr) {
              alert('Error saving remarks.');
          }
      });
  });
});

if (!window.__line1_init_bound) {
  document.addEventListener('DOMContentLoaded', function() {
    updateRealTimeTarget();
    if (!window.__line1_target_interval) {
      window.__line1_target_interval = setInterval(updateRealTimeTarget, 60000);
    }
  });
  window.__line1_init_bound = true;
}
