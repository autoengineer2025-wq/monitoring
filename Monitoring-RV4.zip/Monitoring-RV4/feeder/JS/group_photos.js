// Group member photo manager (DB-backed, with upload & selector)
// Requirements on page:
// - Hidden input: input[name="line_id"]
// - Member images: <img class="member-photo" data-group="A|B" data-role="leader|technician" ...>
// - Bootstrap JS available for modal

(function(){
  const API_URL = '../API/member_photos.php';
  const UPLOAD_URL = '../API/upload_member_photo.php';
  const LIST_URL = '../API/list_member_photos.php';

  function getLineId(){
    const el = document.querySelector('input[name="line_id"]');
    return el ? parseInt(el.value, 10) || 0 : 0;
  }
  function groupOf(el){ return (el.getAttribute('data-group')||'').toUpperCase(); }
  function roleOf(el){ return (el.getAttribute('data-role')||'').toLowerCase(); }

  async function fetchAll(lineId){
    const url = `${API_URL}?action=get&line_id=${encodeURIComponent(lineId)}`;
    const res = await fetch(url);
    const j = await res.json();
    if (!j || !j.success) return null;
    return j.data || null;
  }
  async function saveOne(lineId, group, role, url){
    const fd = new FormData();
    fd.append('action','set');
    fd.append('line_id', String(lineId));
    fd.append('group', group);
    fd.append('role', role);
    fd.append('url', url);
    const res = await fetch(API_URL, { method: 'POST', body: fd });
    const j = await res.json().catch(()=>({success:false}));
    return !!(j && j.success);
  }

  function applyData(map){
    const photos = document.querySelectorAll('img.member-photo[data-group][data-role]');
    photos.forEach((img)=>{
      const g = groupOf(img);
      const r = roleOf(img);
      const url = (map && map[g] && typeof map[g][r] === 'string') ? map[g][r] : '';
      if (url && url.trim() !== '') {
        img.src = url;
      } else {
        if (!img.getAttribute('src') || img.getAttribute('src').trim() === '') {
          img.src = 's.png';
        }
      }
    });
  }

  async function listExisting(lineId, group, role){
    const url = `${LIST_URL}?line_id=${encodeURIComponent(lineId)}&group=${encodeURIComponent(group)}&role=${encodeURIComponent(role)}`;
    const res = await fetch(url);
    const j = await res.json();
    if (!j || !j.success) return [];
    return Array.isArray(j.files) ? j.files : [];
  }

  function showSelectModal(options){
    // options: { title, message, files: [{url,name}], onSelect(url), onUpload(), onEnterUrl() }
    const id = 'memberPhotoSelectModal';
    let modalEl = document.getElementById(id);
    if (modalEl) modalEl.remove();
    modalEl = document.createElement('div');
    modalEl.className = 'modal fade';
    modalEl.id = id;
    modalEl.tabIndex = -1;
    modalEl.innerHTML = `
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">${options.title || 'Select Profile Photo'}</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <p class="mb-2">${options.message || ''}</p>
            <div class="row g-2" id="photoChoiceGrid"></div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" id="btnEnterUrl">Enter URL</button>
            <button type="button" class="btn btn-primary" id="btnUploadNew">Upload New</button>
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
          </div>
        </div>
      </div>`;
    document.body.appendChild(modalEl);

    const grid = modalEl.querySelector('#photoChoiceGrid');
    const files = options.files || [];
    if (files.length === 0) {
      grid.innerHTML = '<div class="text-muted">No existing photos found.</div>';
    } else {
      files.forEach((f)=>{
        const col = document.createElement('div');
        col.className = 'col-6 col-md-4 col-lg-3';
        col.innerHTML = `
          <div class="card h-100">
            <img src="${f.url}" class="card-img-top" alt="${f.name}" style="object-fit:cover;height:140px;">
            <div class="card-body p-2 text-center">
              <div class="small text-truncate" title="${f.name}">${f.name}</div>
              <button class="btn btn-sm btn-success mt-2 btnChoose">Select</button>
            </div>
          </div>`;
        const btn = col.querySelector('.btnChoose');
        btn.addEventListener('click', ()=>{
          try { modalInstance.hide(); } catch(e) {}
          options.onSelect && options.onSelect(f.url);
        });
        grid.appendChild(col);
      });
    }

    const btnUpload = modalEl.querySelector('#btnUploadNew');
    const btnUrl = modalEl.querySelector('#btnEnterUrl');
    btnUpload.addEventListener('click', ()=>{ try { modalInstance.hide(); } catch(e) {} options.onUpload && options.onUpload(); });
    btnUrl.addEventListener('click', ()=>{ try { modalInstance.hide(); } catch(e) {} options.onEnterUrl && options.onEnterUrl(); });

    const modalInstance = new bootstrap.Modal(modalEl);
    modalInstance.show();
  }

  document.addEventListener('DOMContentLoaded', async function(){
    const lineId = getLineId();
    try {
      const map = lineId ? await fetchAll(lineId) : null;
      if (map) applyData(map);
    } catch(e){}

    // Reusable hidden file input
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    fileInput.style.display = 'none';
    document.body.appendChild(fileInput);

    const photos = document.querySelectorAll('img.member-photo[data-group][data-role]');
    photos.forEach(function(img){
      img.addEventListener('dblclick', async function(){
        try {
          const g = groupOf(img);
          const r = roleOf(img);
          const existing = await listExisting(lineId, g, r);
          const proceedUploadOrUrl = async () => {
            const useUpload = confirm('Do you want to upload an image file?\nClick OK to upload, or Cancel to enter a URL.');
            if (useUpload) {
              const onChange = async function(){
                try {
                  if (!fileInput.files || fileInput.files.length === 0) return;
                  const fd = new FormData();
                  fd.append('line_id', String(lineId));
                  fd.append('group', g);
                  fd.append('role', r);
                  fd.append('file', fileInput.files[0]);
                  const res = await fetch(UPLOAD_URL, { method: 'POST', body: fd });
                  const j = await res.json();
                  if (j && j.success && j.url) {
                    const url = String(j.url);
                    const ok = await saveOne(lineId, g, r, url);
                    if (ok) img.src = url; else alert('Failed to save uploaded photo URL');
                  } else {
                    alert((j && j.error) ? j.error : 'Upload failed');
                  }
                } catch(e) {
                  alert('Upload failed');
                } finally {
                  fileInput.value = '';
                  fileInput.removeEventListener('change', onChange);
                }
              };
              fileInput.addEventListener('change', onChange);
              fileInput.click();
            } else {
              const cur = img.src || '';
              const val = prompt('Enter image URL (absolute or relative path):', cur);
              if (val != null) {
                const ok = await saveOne(lineId, g, r, String(val||'').trim());
                if (ok) img.src = String(val||'').trim();
                else alert('Failed to save photo to server');
              }
            }
          };

          if (Array.isArray(existing) && existing.length > 0) {
            showSelectModal({
              title: 'Profile already uploaded',
              message: 'A photo is already in the database for this role. Please select from the list, or upload a new one.',
              files: existing,
              onSelect: async (url) => {
                const ok = await saveOne(lineId, g, r, url);
                if (ok) img.src = url; else alert('Failed to select photo');
              },
              onUpload: proceedUploadOrUrl,
              onEnterUrl: proceedUploadOrUrl
            });
          } else {
            await proceedUploadOrUrl();
          }
        } catch(e) {}
      });

      img.addEventListener('contextmenu', async function(e){
        e.preventDefault();
        if (confirm('Reset photo to default?')) {
          const ok = await saveOne(lineId, groupOf(img), roleOf(img), '');
          if (ok) img.src = 's.png'; else alert('Failed to reset photo');
        }
        return false;
      });
    });
  });
})();
