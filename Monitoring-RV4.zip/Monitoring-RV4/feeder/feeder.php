<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Simple Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../node_modules/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="../node_modules/bootstrap-icons/font/bootstrap-icons.css">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f8f9fa;
    }
    .sidebar {
      background-color: #fff;
      color: #222;
      border-right: 1px solid #e3f0ff;
      box-shadow: 0 0 8px rgba(163, 201, 247, 0.08);
      min-height: 100vh;
    }
    .sidebar .nav-link {
      color: #222;
      font-weight: 500;
      border-radius: 8px;
      margin-bottom: 8px;
      transition: background 0.2s, color 0.2s;
    }
    .sidebar .nav-link.active,
    .sidebar .nav-link:hover {
      background-color: #a3c9f7;
      color: #222;
    }
    .sidebar h4 {
      color: #222;
      font-weight: 700;
    }
    .content-area {
      padding: 2rem;
    }
    .navbar {
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>

<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <nav class="sidebar col-lg-2 col-md-3 d-flex flex-column p-3">
      <h4 class="mb-5 text-center">Central monitoring - Feeder</h4>
      <ul class="nav flex-column">
        <li class="mb-2 nav-item">
          <a href="#" class="nav-link" data-page="feeder.php">
            <i class="bi bi-speedometer2 me-2"></i> Dashboard
          </a>
        </li>
        <li class="mb-2 nav-item">
          <a href="model.php" class="nav-link" data-page="model.php">
            <i class="bi bi-cpu me-2"></i> Model Number
          </a>
        </li>
        <li class="mb-2 nav-item">
          <a href="drawing.php" class="nav-link active" data-page="drawing.php">
            <i class="bi bi-file-earmark-text me-2"></i> Drawing Number
          </a>
        </li>
        <li class="mb-2 nav-item">
          <a href="production.php" class="nav-link" data-page="production.php">
            <i class="bi bi-clock-history me-2"></i> Production Time
          </a>
        </li>
        <li class="nav-item mb-2">
          <a href="production.php" class="nav-link">
            <i class="bi bi-bar-chart-steps me-2"></i> Line
          </a>
        </li>
      </ul>
    </nav>

    <!-- Main Content Area -->
    <div class="col-lg-10 col-md-9 px-0">
      <!-- Top Navbar -->
      <nav class="navbar navbar-expand-lg navbar-light bg-white px-4">
        <div class="container-fluid">
          <form class="d-flex me-auto">
            <input class="form-control me-2" type="search" placeholder="Search">
            <button class="btn btn-outline-secondary" type="submit"><i class="bi bi-search"></i></button>
          </form>
          <button class="btn btn-outline-danger"><i class="bi bi-box-arrow-right me-1"></i> Logout</button>
        </div>
      </nav>
      <div class="content-area"></div> <!-- Add this line -->
    </div>
  </div>
</div>

<script src="../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script>
  // No AJAX, just let anchor tags work as normal navigation
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function(e) {
      const page = this.getAttribute('data-page');
      if (page) {
        window.location.href = '/Monitoring-RV4/feeder/' + page;
      }
    });
  });
</script>

</body>
</html>