<?php
include_once '../../../database/init.php';

$today = date('Y-m-d');
$lines = $database->select('fline', '*');
// Default to Line 4 but allow URL override (?line or ?line_id)
$selectedLine = isset($_GET['line']) ? intval($_GET['line']) : (isset($_GET['line_id']) ? intval($_GET['line_id']) : 4);
$selectedShift = $_GET['shift'] ?? 'Day Shift';
$queryRecordId = isset($_GET['record_id']) ? intval($_GET['record_id']) : null;

$prodRecord = null;
if ($queryRecordId) {
  $prodRecord = $database->get('fproduction_record', '*', ['record_id' => $queryRecordId]);
  if ($prodRecord) { $today = $prodRecord['production_date']; }
}
if (!$prodRecord) {
  $prodRecord = $database->get('fproduction_record', '*', [
    'production_date' => $today,
    'Fline_ID' => $selectedLine,
    'Shift' => $selectedShift,
    'ORDER' => ['created_at' => 'DESC']
  ]);
}
if (!$prodRecord) {
  $prodRecord = $database->get('fproduction_record', '*', [
    'Fline_ID' => $selectedLine,
    'Shift' => $selectedShift,
    'ORDER' => ['created_at' => 'DESC']
  ]);
  if ($prodRecord) { $today = $prodRecord['production_date']; }
}

$recordId = $prodRecord['record_id'] ?? null;
$planTarget = $prodRecord ? intval($prodRecord['plan_target']) : 0;
$takttimeString = $prodRecord['takttime'] ?? '';

// Try to load per-break snapshots (using the record's production_date)
$breaks = [];
if ($recordId) {
  $breaks = $database->select('fproduction_breaks', '*', [
    'record_id' => $recordId,
    'production_date' => $prodRecord['production_date'],
    'ORDER' => ['break_number' => 'ASC']
  ]) ?? [];
}

// Helper arrays
$breakLabels = ['1ST','2ND','3RD','4TH','5TH'];

$loadedRecordInfo = $recordId ? ("rec #{$recordId}") : 'none';
?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Monitoring</title>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="../../API/style.css">
  <!-- Style CSS -->
  <link rel="stylesheet" href="../../../node_modules/bootstrap/dist/css/bootstrap.min.css">
  <!-- Bootstrap Icons CSS -->
  <link rel="stylesheet" href="../../../node_modules/bootstrap-icons/font/bootstrap-icons.css">
  <!-- jQuery -->
  <script src="../../../node_modules/jquery/dist/jquery.min.js"></script>
  <!-- Bootstrap JS Bundle -->
  <script src="../../../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Chart.js -->
  <script src="../../../node_modules/chart.js/dist/chart.umd.js"></script>
  <style>
      :root {
        --card-radius: 10px;
        --card-border: #e9ecef;
        --card-shadow: 0 4px 12px rgba(0,0,0,0.06);
        --gap: 6px;
      }

      /* KPI strip styles (design only) */
      .kpi-strip {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 8px;
        margin-bottom: 6px;
      }
      .kpi-pill {
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 6px 8px;
        border-radius: 999px;
        background: #f8f9fa;
        border: 1px solid #e9ecef;
        font-size: 0.85rem;
        line-height: 1;
      }
      .kpi-pill .label { color: #6c757d; font-weight: 600; }
      .kpi-pill .value { color: #212529; font-weight: 700; }

      /* Daily Operation split charts (design only) */
      .chart-grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; width: 100%; }
      .chart-box { background: #fff; border: 1px solid #e9ecef; border-radius: 6px; padding: 6px; display:flex; flex-direction:column; }
      .chart-title { font-size: 0.85rem; font-weight: 600; color:#6c757d; margin-bottom: 4px; text-align:center; }
      @media (max-width: 992px) { .chart-grid-3 { grid-template-columns: 1fr; } }

      /* Card styling */
      .card-custom {
        background: #fff;
        border: 1px solid var(--card-border);
        border-radius: var(--card-radius);
        box-shadow: var(--card-shadow);
        border: 2px solid #000;
      }

      .card-custom strong { font-weight: 600; }
      .card-custom .badge { opacity: 0.85; }

      #three-months-total {
        font-size: clamp(1.6rem, 3.2vw, 2.6rem);
        line-height: 1.1;
      }

      /* Chart containers */
      .card-custom .flex-grow-1 { min-height: 180px; }

      @media (max-width: 1400px) {
        .card-custom .flex-grow-1 { min-height: 160px; }
      }

      @media (max-width: 992px) {
        .card-custom .flex-grow-1 { min-height: 140px; }
      }

      @media (max-width: 576px) {
        .card-custom .flex-grow-1 { min-height: 120px; }
      }
      /* Layout improvements */
      .two-col-section { align-items: stretch; }
      .left-panel .card-custom { height: 100%; }
      .left-panel .table-responsive {
        /* Make the left table scroll within viewport on large screens */
        max-height: calc(100vh - 260px);
        overflow-y: auto;
      }
      .table-sticky thead th {
        position: sticky;
        top: 0;
        background: #fff;
        z-index: 2;
      }

      .group-card {
      border: 2px solid #000;
      display: flex;
    }
    .group-label {
      border-right: 2px solid #000;
      text-align: center;
      font-weight: bold;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      min-width: 100px;
    }
    .group-label .small-text {
      font-size: 1rem;
    }
    .group-label .big-letter {
      font-size: 3rem;
      color: #007bff; /* Bootstrap blue */
      line-height: 1;
    }
    .group-members {
      flex: 1;
      padding: 0.5rem;
    }
    .member-card {
      border: 1px solid #000;
      text-align: center;
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center; 
    }
    .member-card img {
      display: block;
      width: auto;          
      height: 80px;        
      margin: 0 auto;       
      border-bottom: 1px solid #000;
    }
    .member-role {
      font-weight: 500;
      padding: 0.25rem;
    }
    /* Group cards layout tweaks */
    .group-card { gap: 6px; margin-bottom: 8px; }
    .group-members .row > [class^="col-"] { padding-left: 6px; padding-right: 6px; display: flex; }
    .group-members .member-card { flex: 1 1 auto; display: flex; flex-direction: column; }
    .card-custom.group-wrapper { padding: 8px; display: grid; grid-template-rows: 1fr 1fr; gap: 8px; }
    .group-wrapper .group-card { height: 100%; }
    .member-card { justify-content: center; }
</style>
    </head>

  
    <body class="p-3">
    <!-- Hidden inputs to support read-only JS computations -->
    <input type="hidden" name="production_date" value="<?= htmlspecialchars($today) ?>">
    <input type="hidden" name="line_id" value="<?= htmlspecialchars($selectedLine) ?>">
    <input type="hidden" name="shift" value="<?= htmlspecialchars($selectedShift) ?>">
    <input type="hidden" name="record_id" id="recordId" value="<?= htmlspecialchars($recordId ?? '') ?>">
    <input type="hidden" id="plan_target" value="<?= intval($planTarget) ?>">
    <input type="hidden" id="takttime" value="<?= htmlspecialchars($takttimeString) ?>">
    <?php for ($i=1;$i<=5;$i++): ?>
      <input type="hidden" id="start_time_<?= $i ?>" value="<?= htmlspecialchars($prodRecord["Fstart_Time{$i}"] ?? '') ?>">
      <input type="hidden" id="end_time_<?= $i ?>" value="<?= htmlspecialchars($prodRecord["Fend_Time{$i}"] ?? '') ?>">
    <?php endfor; ?>

    
    <div class="row g-3">
 
      
      <!-- GRID FOR Line Info (Line / Shift / Date / Time) -->
      <div class="col-12 col-lg-2">
        <div class="card-custom h-100 px-3 py-2 d-flex flex-column">
          <!-- Header: title only -->
          <div class="d-flex align-items-center justify-content-between w-100 mb-2">
            <strong style="font-size:1rem;">Production Monitoring Dashboard</strong>
          </div>
          <!-- Row 1: Shift (left) and Date/Time (right) -->
          <div class="row g-2 align-items-center mb-1">
            <div class="col-6 d-flex align-items-center">
              <span class="badge bg-light text-dark d-flex align-items-center"><i class="bi bi-people me-1"></i><span id="shift-label"><?= htmlspecialchars($selectedShift) ?></span></span>
            </div>
            <div class="col-6 d-flex justify-content-end align-items-center gap-2">
              <span class="badge bg-light text-dark d-flex align-items-center"><i class="bi bi-calendar me-1"></i><span id="current-date"></span></span>
              <span class="badge bg-light text-dark d-flex align-items-center"><i class="bi bi-clock me-1"></i><span id="current-time"></span></span>
            </div>
          </div>
          <!-- Row 2: Line centered -->
          <div class="w-100 text-center">
            <div class="fw-bold" style="font-size:6rem; line-height:2.5;">Line <?= htmlspecialchars($selectedLine) ?></div>
          </div>
        </div>
      </div>

    
      <!-- GRID FOR GROUP CARDS (A and B in one card) -->
      <div class="col-12 col-lg-2">
          <div class="card-custom group-wrapper h-100">
        <!-- GROUP A -->
        <div class="group-card">
          <div class="group-label">
            <span class="small-text">GROUP</span>
            <span class="big-letter">A</span>
          </div>
          <div class="group-members">
            <div class="row g-2">
              <div class="col-6">
                <div class="member-card">
                  <img src="s.png" alt="Line Leader A">
                  <div class="member-role">Line Leader</div>
                </div>
              </div>
              <div class="col-6">
                <div class="member-card">
                  <img src="s.png" alt="Technician A">
                  <div class="member-role">Technician</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- GROUP B -->
        <div class="group-card">
          <div class="group-label">
            <span class="small-text">GROUP</span>
            <span class="big-letter">B</span>
          </div>
          <div class="group-members">
            <div class="row g-2">
              <div class="col-6">
                <div class="member-card">
                  <img src="s.png" alt="Line Leader B">
                  <div class="member-role">Line Leader</div>
                </div>
              </div>
              <div class="col-6">
                <div class="member-card">
                  <img src="s.png" alt="Technician B">
                  <div class="member-role">Technician</div>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
    </div>
      <!-- GRID FOR ACHIEVEMENT RATE -->
    <div class="col-12 col-lg-2">
    <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2">
      <div class="d-flex align-items-center justify-content-between w-100 mb-1">
        <strong style="font-size:1.1rem;">Achievement Rate</strong>
        <div class="d-flex flex-wrap gap-1 ms-2">
          <span class="badge bg-danger px-2 py-1">95%↓</span>
          <span class="badge bg-warning text-dark px-2 py-1">96-99%</span>
          <span class="badge bg-success px-2 py-1">100%</span>
          <span class="badge bg-primary px-2 py-1">101%↑</span>
        </div>
      </div>
      <div class="d-flex justify-content-center w-100 mt-auto">
        <canvas id="achievementChart" width="150" height="150"></canvas>
      </div>
    </div>
    </div>

      <!-- GRID FOR PER BREAKTIME ACHIEVEMENT RATE -->
      <div class="col-12 col-lg-4">
     <div class="card-custom h-100 d-flex flex-column justify-content-between px-2 py-1" style="min-height: 360px;">
       <div class="d-flex align-items-center justify-content-between w-100 mb-1">
         <strong style="font-size:0.9rem;">Achievement Per Break</strong>
       </div>
       <div class="d-flex justify-content-center w-100 mt-auto" style="height: 100%; min-height: 320px;">
         <canvas id="achievementPerBreakChart" style="width: 100%; height: 100%;"></canvas>
       </div>
     </div>
   </div>

      <!-- GRID FOR LINE REJECTION RATE -->
    <div class="col-12 col-lg-2">
    <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2">
      <div class="d-flex align-items-center justify-content-between w-100 mb-1">
        <strong style="font-size:0.9rem;">LINE REJECTION RATE</strong>
        <div class="d-flex flex-wrap gap-1 ms-2">
          <span class="badge bg-danger px-1 py-1">95%↓</span>
          <span class="badge bg-warning text-dark px-1 py-1">96-99%</span>
          <span class="badge bg-success px-1 py-1">100%</span>
          <span class="badge bg-primary px-1 py-1">101%↑</span>
        </div>
      </div>
      <div class="d-flex justify-content-center w-100 mt-auto">
        <canvas id="lineRejectionChart" width="150" height="150"></canvas>
      </div>
    </div>
    </div>

    </div>

    <!-- Main content: Left = Drawing Numbers Data (full height), Right = all charts/metrics -->
    <div class="row g-3 mb-2 two-col-section">
    <div class="col-12 col-sm-6 col-lg-6">
    <div class="card-custom h-100 d-flex flex-column px-2 py-1">
        <div class="d-flex justify-content-between align-items-center mb-1">
            <strong style="font-size:0.9rem;">Data Analytics Board</strong>
        </div>
        <div class="table-responsive flex-grow-1">
            <?php if (!$prodRecord): ?>
              <div class="alert alert-warning m-2">
                No production record found for the selected criteria. Try selecting another date, or create a record in <code>feeder/line/line1.php</code>.
              </div>
            <?php endif; ?>
            <table class="table table-bordered text-center mb-0 analytics-table table-sticky">
                <tr>
                    <th colspan="2" rowspan="2" style="text-align: center; vertical-align: middle;">
                      Break
                    </th>
                    <th colspan="2" rowspan="">Time</th>
                    <th rowspan="2" style="text-align: center; vertical-align: middle;">
                      WORK HR
                    </th>                    
                    <th colspan="2">PLAN</th>
                    <th colspan="2">RESULT</th>
                    <th colspan="2">DIFF</th>
                    <th colspan="2">REJECT</th>
                    <th colspan="5"  style="text-align: center; vertical-align: middle;">REMARKS</th>
                </tr>
                <tr>
                    <th>Start</th>
                    <th>End</th>
                    <th>Output</th> 
                    <th>Accu</th>
                    <th>Output</th>
                    <th>Accu</th>
                    <th>Balanced</th>
                    <th>Accu</th>
                    <th>Qty</th>
                    <th>Accu</th>
                    <th>Classification</th>
                    <th>Reason</th>
                    <th>Countermeasure</th>
                </tr>
                      <tbody>
                      <?php
                        $hasSnapshots = is_array($breaks) && count($breaks) === 5;
                        $accuReject = 0;
                        for ($i=1; $i<=5; $i++):
                          $snap = $hasSnapshots ? $breaks[$i-1] : null;
                          $start = $snap['start_time'] ?? ($prodRecord["Fstart_Time{$i}"] ?? '');
                          $end   = $snap['end_time'] ?? ($prodRecord["Fend_Time{$i}"] ?? '');
                          $workSeconds = intval($snap['work_seconds'] ?? 0);
                          if (!$workSeconds && $start && $end) {
                            $st = strtotime($start); $en = strtotime($end); if ($en > $st) $workSeconds = $en - $st;
                          }
                          $workHourStr = $workSeconds ? (round($workSeconds/3600,2).' HR | '.number_format($workSeconds).' SEC') : '-';
                          $planOut = intval($snap['plan_output'] ?? 0);
                          $planAcc = intval($snap['plan_accu'] ?? 0);
                          $actOut  = intval($snap['actual_output'] ?? ($prodRecord["actual{$i}"] ?? 0));
                          // Recompute actual accu from record if snapshot missing
                          $actAcc = intval($snap['actual_accu'] ?? 0);
                          if (!$actAcc) {
                            $sum=0; for($j=1;$j<= $i;$j++){ $sum += intval($prodRecord["actual{$j}"] ?? 0);} $actAcc = $sum;
                          }
                          $diffBal = ($snap && isset($snap['diff_balanced'])) ? intval($snap['diff_balanced']) : ($actOut - $planOut);
                          $diffAcc = ($snap && isset($snap['diff_accu'])) ? intval($snap['diff_accu']) : ($actAcc - $planAcc);
                          $rejQty  = intval($snap['reject_qty'] ?? 0);
                          $accuReject = intval($snap['reject_accu'] ?? ($accuReject + $rejQty));
                          $classif = $snap['classification'] ?? '';
                          $reason  = $snap['reason'] ?? '';
                          $cm      = $snap['countermeasure'] ?? '';
                      ?>
                      <tr>
                          <td colspan="2"><?= htmlspecialchars($breakLabels[$i-1]) ?></td>
                          <td><?= htmlspecialchars($start ?: '-') ?></td>
                          <td><?= htmlspecialchars($end ?: '-') ?></td>
                          <td><?= $workHourStr ?></td>
                          <td class="plan-output-cell"><?= $planOut ?></td>
                          <td class="plan-accu-cell"><?= $planAcc ?></td>
                          <td class="output-cell" data-break="<?= $i ?>"><div><?= $actOut ?></div></td>
                          <td class="actual-accu-cell"><?= $actAcc ?></td>
                          <td class="difference-cell"><?= ($diffBal===0?'-':$diffBal) ?></td>
                          <td class="diff-accu-cell"><?= ($diffAcc===0?'-':$diffAcc) ?></td>
                          <td class="reject-qty-cell"><?= $rejQty ?></td>
                          <td class="reject-accu-cell"><?= $accuReject ?></td>
                          <td><div class="small text-center remark-classification"><?= htmlspecialchars($classif) ?></div></td>
                          <td><div class="mt-1 small text-center remark-reason" ><?= htmlspecialchars($reason) ?></div></td>
                          <td><div class="mt-1 small text-center remark-countermeasure" ><?= htmlspecialchars($cm) ?></div></td>
                      </tr>
                      <?php endfor; ?>
                      </tbody>
                      </table>
    </div>
    </div>
    </div>
      
      <!-- Right column: Metrics and charts stacked in rows -->
      <div class="col-12 col-lg-6">
        <!-- Row A: Totals and Daily Output (4/8) -->
        <div class="row g-3">
          <div class="col-12 col-lg-4">
            <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2 w-100">
              <div class="d-flex align-items-center justify-content-between w-100 mb-1">
                <strong style="font-size:1rem;">Past 3 Months Output</strong>
              </div>
              <div class="flex-grow-1" style="min-height: 220px;">
                <canvas id="output3MChart"></canvas>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-8">
            <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2 w-100">
              <div class="d-flex align-items-center justify-content-between w-100 mb-1">
                <strong style="font-size:1rem;">Daily Output (This Month)</strong>
                <span class="badge bg-secondary" id="daily-range-badge" style="font-size:0.7rem;">-</span>
              </div>
              <div class="flex-grow-1" style="min-height: 220px;">
                <canvas id="monthlyDailyOutputChart"></canvas>
              </div>
            </div>
          </div>
        </div>

        <!-- Row B: Operation Rates (4/8) -->
        <div class="row g-3 mt-1">
          <div class="col-12 col-lg-4">
            <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2 w-100">
              <div class="d-flex align-items-center justify-content-between w-100 mb-1">
                <strong style="font-size:1rem;">Operation Rate (Past 3 Months)</strong>
              </div>
              <div class="flex-grow-1" style="min-height: 220px;">
                <canvas id="opRate3MChart"></canvas>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-8">
            <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2 w-100">
              <div class="d-flex align-items-center justify-content-between w-100 mb-1">
                <strong style="font-size:1rem;">Operation Rate (This Months)</strong>
              </div>
              <div class="flex-grow-1" style="min-height: 220px;">
                <canvas id="opRateDailyChart"></canvas>
              </div>
            </div>
          </div>
        </div>

        <!-- Row C: Yield Rates (4/8) -->
        <div class="row g-3 mt-1">
          <div class="col-12 col-lg-4">
            <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2 w-100">
              <div class="d-flex align-items-center justify-content-between w-100 mb-1">
                <strong style="font-size:1rem;">Past 3 Months Yield Rate</strong>
                <span class="badge bg-secondary" id="oprate-daily-range" style="font-size:0.7rem;">-</span>
              </div>
              <div class="flex-grow-1" style="min-height: 220px;">
                <canvas id="yield3MChart"></canvas>
              </div>
            </div>
          </div>
          <div class="col-12 col-lg-8">
            <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2 w-100">
              <div class="d-flex align-items-center justify-content-between w-100 mb-1">
                <strong style="font-size:1rem;">Yield Rate (Daily, This Month)</strong>
                <span class="badge bg-secondary" id="yield-daily-range" style="font-size:0.7rem;">-</span>
              </div>
              <div class="flex-grow-1" style="min-height: 220px;">
                <canvas id="yieldDailyChart"></canvas>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
<script>window.READ_ONLY_VIEW = true;</script>
  <script src="../../JS/api.js"></script>
  <script src="../../JS/line1.js"></script>
  <script src="../../JS/lineview2.charts.js"></script>
  <script src="../../JS/line1.view.js"></script>
  <script src="../../JS/realtime_view.js"></script>

  <script>
    (function(){
      function updateClock(){
        const now = new Date();
        const dateStr = now.toLocaleDateString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
        const timeStr = now.toLocaleTimeString();
        const d = document.getElementById('current-date');
        const t = document.getElementById('current-time');
        if (d) d.textContent = dateStr;
        if (t) t.textContent = timeStr;
      }
      updateClock();
      setInterval(updateClock, 1000);
    })();
  </script>

  <?php
    $needsSnapshot = ($recordId && (!is_array($breaks) || count($breaks) !== 5));
    if ($needsSnapshot):
  ?>
  <script>
    // Auto-generate snapshots so plan/classification/remarks appear without manual action
    (function(){
      try {
        $.post('../API/save_break_snapshot.php', { record_id: <?= json_encode((int)$recordId) ?> })
         .always(function(){
            // Reload once to display fresh snapshots
            setTimeout(function(){ location.reload(); }, 300);
         });
      } catch(e) { /* no-op */ }
    })();
  </script>
  <?php endif; ?>

  <script>
    // Respect server-provided shift if present; otherwise detect Day/Night by local time
    (function(){
      function detectShift(now){
        const h = now.getHours();
        return (h >= 6 && h < 18) ? 'Day Shift' : 'Night Shift';
      }
      function applyShift(){
        const now = new Date();
        const detected = detectShift(now);
        const shiftInput = document.querySelector('input[name="shift"]');
        const label = document.getElementById('shift-label');

        // If server already provided a shift, honor it and don't overwrite.
        if (shiftInput && shiftInput.value) {
          if (label) label.textContent = shiftInput.value;
          return;
        }

        // No server shift provided: use detected value and update input/label
        if (label) label.textContent = detected;
        if (shiftInput && shiftInput.value !== detected){
          shiftInput.value = detected;
          window.dispatchEvent(new Event('realtime_shift_changed'));
        }
      }
      applyShift();
      setInterval(applyShift, 60000);
    })();
  </script>

  </body>
  </html>
  <?php
  ?>
