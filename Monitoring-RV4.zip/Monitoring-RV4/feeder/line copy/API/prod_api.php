<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');
include __DIR__ . '/../../../database/init.php';

// Debug log
file_put_contents('debug.txt', "RAW POST DATA:\n" . print_r($_POST, true) . "\n", FILE_APPEND);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $production_date = $_POST['production_date'] ?? '';
    $Fline_ID        = $_POST['Fline_ID'] ?? '';
    $Fprod_ID        = $_POST['Fprod_ID'] ?? '';
    $shift           = $_POST['shift'] ?? '';
    $mCount          = intval($_POST['mCount'] ?? 0);

    if (!$production_date || !$Fline_ID || !$Fprod_ID || !$shift || $mCount <= 0) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        exit;
    }

    // Enforce one record per (production_date, line, shift)
    $existing = $database->get("fproduction_record", "*", [
        "production_date" => $production_date,
        "Fline_ID"        => $Fline_ID,
        "Shift"           => $shift
    ]);
    if ($existing) {
        echo json_encode(['success' => false, 'message' => 'Record already exists for this line, shift, and date']);
        exit;
    }

    // Initialize consolidated data
    $totalPlanTarget = 0;
    $totalWorkingHours = 0;
    $takttimeValues = [];
    $lengthValues = [];
    $drawingIds = [];
    $quantities = [];
    $modelPlanTargets = [];
    
    // Collect data from all models
    for ($i = 1; $i <= $mCount; $i++) {
        $Fdrawing_ID  = $_POST["Fdrawing_ID$i"] ?? '';
        $qty          = intval($_POST["qty$i"] ?? 0);
        $workingHours = floatval($_POST["workingHours$i"] ?? 0);
        $takttime     = floatval($_POST["takttime$i"] ?? 0);
        $length       = floatval($_POST["length$i"] ?? 0);

        if (!$Fdrawing_ID || $qty <= 0) continue;

        // Calculate plan target for this model
        $modelPlanTarget = ($takttime > 0 && $workingHours > 0) ? (int)floor(($workingHours * 3600) / $takttime) : 0;
        
        // Accumulate totals
        $totalPlanTarget += $modelPlanTarget;
        $totalWorkingHours += $workingHours;
        
        // Store individual values for multi-model support
        $takttimeValues[] = $takttime;
        $lengthValues[] = $length;
        $drawingIds[] = $Fdrawing_ID;
        $quantities[] = $qty;
        $modelPlanTargets[] = $modelPlanTarget;
    }

    // Create comma-separated strings for multi-model data
    $takttimeString = implode(', ', $takttimeValues);
    $lengthString = implode(', ', $lengthValues);
    $drawingIdString = implode(', ', $drawingIds);

    // Use the first drawing ID as the primary one (for compatibility)
    $primaryDrawingId = !empty($drawingIds) ? $drawingIds[0] : '';

    // Create single consolidated record
    $data = [
        "production_date" => $production_date,
        "Shift"           => $shift,
        "Fline_ID"        => $Fline_ID,
        "Fprod_ID"        => $Fprod_ID,
        "Fdrawing_ID"     => $drawingIdString, // Comma-separated drawing IDs for multi-model support
        "plan_target"     => $totalPlanTarget,
        "target"          => 0,
        "working_hours"   => $totalWorkingHours,
        "actual1"         => 0,
        "actual2"         => 0,
        "actual3"         => 0,
        "actual4"         => 0,
        "actual5"         => 0,
        "total_actual"    => 0,
        "takttime"        => $takttimeString,
        "reject_count"    => 0,
        "reject_ppm"      => null,
        "length"          => $lengthString,
        "Fstart_Time1"    => $_POST['Fstart_Time1'] ?? null,
        "Fend_Time1"      => $_POST['Fend_Time1'] ?? null,
        "Fstart_Time2"    => $_POST['Fstart_Time2'] ?? null,
        "Fend_Time2"      => $_POST['Fend_Time2'] ?? null,
        "Fstart_Time3"    => $_POST['Fstart_Time3'] ?? null,
        "Fend_Time3"      => $_POST['Fend_Time3'] ?? null,
        "Fstart_Time4"    => $_POST['Fstart_Time4'] ?? null,
        "Fend_Time4"      => $_POST['Fend_Time4'] ?? null,
        "Fstart_Time5"    => $_POST['Fstart_Time5'] ?? null,
        "Fend_Time5"      => $_POST['Fend_Time5'] ?? null,
        "created_at"      => date('Y-m-d H:i:s')
        // Note: model_info column may not exist in database, so we'll handle multi-model logic differently
    ];

    file_put_contents('debug.txt', "CONSOLIDATED INSERT DATA:\n" . print_r($data, true) . "\n", FILE_APPEND);
    // Insert into feeder table
    $result = $database->insert("fproduction_record", $data);
    $newRecordId = $database->id();
    
    // Create per-model progress rows for sequencing (one row per model)
    if ($newRecordId && count($drawingIds) > 0) {
        for ($i = 0; $i < count($drawingIds); $i++) {
            $database->insert('fproduction_model_progress', [
                'record_id' => $newRecordId,
                'model_index' => $i + 1,
                'Fdrawing_ID' => $drawingIds[$i],
                'model_qty_per_press' => intval($quantities[$i] ?? 0),
                'model_plan_total' => intval($modelPlanTargets[$i] ?? 0),
                'produced_units' => 0,
                'created_at' => date('Y-m-d H:i:s')
            ]);
        }
    }

    if ($result) {
        echo json_encode([
            'success' => true,
            'Fline_ID' => $Fline_ID,
            'shift'    => $shift,
            'record_id' => $newRecordId ?: $result,
            'plan_target' => $totalPlanTarget,
            'model_count' => $mCount
        ]);
    } else {
        echo json_encode([
            'success' => false, 
            'message' => 'Insert failed: ' . json_encode($database->error)
        ]);
    }
    exit;
}
