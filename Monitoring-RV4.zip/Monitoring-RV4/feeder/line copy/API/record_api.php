<?php
include_once '../../../database/init.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

try {
    if ($action === 'get_latest') {
        $production_date = $_GET['production_date'] ?? date('Y-m-d');
        $line_id = isset($_GET['line_id']) ? intval($_GET['line_id']) : 1;
        $shift = $_GET['shift'] ?? 'Day Shift';

        // Get latest record for date/line/shift (fallback: latest for line/shift any date)
        $record = $database->get('fproduction_record', '*', [
            'production_date' => $production_date,
            'Fline_ID' => $line_id,
            'Shift' => $shift,
            'ORDER' => ['created_at' => 'DESC']
        ]);
        if (!$record) {
            $record = $database->get('fproduction_record', '*', [
                'Fline_ID' => $line_id,
                'Shift' => $shift,
                'ORDER' => ['created_at' => 'DESC']
            ]);
        }
        if (!$record) {
            echo json_encode(['success' => false, 'message' => 'Production record not found']);
            exit;
        }

        $record_id = intval($record['record_id']);

        // Load rejects per break for this record
        $rejects = [];
        try {
            $rejRows = $database->select('fproduction_rejects', '*', [ 'record_id' => $record_id ]);
            foreach ($rejRows as $r) { $rejects[strval(intval($r['break_number']))] = intval($r['qty']); }
        } catch (Exception $e) { $rejects = []; }

        // Load remarks per break for this record (latest per break)
        $remarks = [];
        try {
            $rRows = $database->select('fproduction_remarks', '*', [
                'record_id' => $record_id,
                'ORDER' => [ 'break_number' => 'ASC', 'id' => 'DESC' ]
            ]);
            foreach ($rRows as $r) {
                $bn = (int)($r['break_number'] ?? 0);
                if ($bn <= 0) continue;
                if (!isset($remarks[$bn])) {
                    $remarks[$bn] = [
                        'classification' => $r['classification'] ?? '',
                        'reason' => $r['reason'] ?? '',
                        'countermeasure' => $r['countermeasure'] ?? ''
                    ];
                }
            }
        } catch (Exception $e) { $remarks = []; }

        echo json_encode([
            'success' => true,
            'data' => $record,
            'rejects' => $rejects,
            'remarks' => $remarks
        ]);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Invalid action']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
