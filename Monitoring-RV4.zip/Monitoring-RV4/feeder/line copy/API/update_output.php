<?php
header('Content-Type: application/json');
include __DIR__ . '/../../../database/init.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_output') {
        $breakNumber = $_POST['break_number'] ?? '';
        $outputValue = $_POST['output_value'] ?? '';
        $productionDate = $_POST['production_date'] ?? '';
        $lineId = $_POST['line_id'] ?? '';
        $shift = $_POST['shift'] ?? '';
        
        if (!$breakNumber || !$productionDate || !$lineId || !$shift) {
            echo json_encode(['success' => false, 'message' => 'Missing required fields']);
            exit;
        }
        
        // Find the production record
        $record = $database->get("fproduction_record", "*", [
            "production_date" => $productionDate,
            "Fline_ID" => $lineId,
            "Shift" => $shift,
            "ORDER" => ["created_at" => "DESC"]
        ]);
        
        if (!$record) {
            echo json_encode(['success' => false, 'message' => 'Production record not found']);
            exit;
        }
        
        // Update the output field based on break number
        // Column names in fproduction_record are actual1..actual5
        $outputField = "actual" . $breakNumber;
        
        $result = $database->update("fproduction_record", [
            $outputField => $outputValue
        ], [
            "production_date" => $productionDate,
            "Fline_ID" => $lineId,
            "Shift" => $shift
        ]);
        
        if ($result) {
            echo json_encode(['success' => true, 'message' => 'Output updated successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update output']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
