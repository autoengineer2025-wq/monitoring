<?php
include_once '../../../database/init.php';

header('Content-Type: application/json');
// Prevent HTML notices/warnings from breaking JSON responses
@ini_set('display_errors', 0);
@ini_set('display_startup_errors', 0);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    if (function_exists('ob_get_level')) { while (ob_get_level() > 0) { @ob_end_clean(); } }
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) {
        $data = $_POST;
    }

    $record_id = $data['record_id'] ?? null;
    $break_number = $data['break_number'] ?? null;
    $output_value = $data['output_value'] ?? null; // not used, but kept for compatibility

    if (!$record_id || !$break_number || $output_value === null) {
        if (function_exists('ob_get_level')) { while (ob_get_level() > 0) { @ob_end_clean(); } }
        echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
        exit;
    }

    // Load production record
    $prodRecord = $database->get('fproduction_record', '*', ['record_id' => $record_id]);
    if (!$prodRecord) {
        if (function_exists('ob_get_level')) { while (ob_get_level() > 0) { @ob_end_clean(); } }
        echo json_encode(['success' => false, 'message' => 'Production record not found']);
        exit;
    }

    // Resolve drawing IDs (comma-separated) and load per-model qtys
    $rawDrawingIds = $prodRecord['Fdrawing_ID'] ?? '';
    $drawingIdArray = array_values(array_filter(array_map('trim', explode(',', $rawDrawingIds)), function($v){ return $v !== ''; }));
    $primaryDrawingId = $drawingIdArray[0] ?? '';

    // Get primary drawing takttime for single-model fallback
    $drawing = $primaryDrawingId ? $database->get('fdrawingnumber', '*', ['Fdrawing_ID' => $primaryDrawingId]) : null;
    $takttime = $drawing ? floatval($drawing['takttime'] ?? 0) : 0;

    // Per-model batch qty from drawingnumber.qty only (fallback to 1)
    $drawingQtyPerModel = [];
    foreach ($drawingIdArray as $did) {
        $qtyVal = 1;
        $row = $database->get('fdrawingnumber', ['qty'], ['Fdrawing_ID' => $did]);
        if (is_array($row) && array_key_exists('qty', $row)) {
            $qtyVal = max(1, (int)$row['qty']);
        }
        $drawingQtyPerModel[] = $qtyVal;
    }

    // Compute plan per break and per-model using multi-model capacities
    $planOutputs = [];
    $planOutputsByModel = [];
    $remainingTotalPlan = intval($prodRecord['plan_target'] ?? 0);

    // Build takttime array (from stored comma-separated string)
    $takttimeArray = [];
    $rawTt = $prodRecord['takttime'] ?? '';
    if ($rawTt && strpos($rawTt, ',') !== false) {
        $takttimeArray = array_values(array_filter(array_map(function($v){
            $f = (float)trim($v);
            return $f > 0 ? $f : null;
        }, explode(',', $rawTt))));
    } elseif ($rawTt) {
        $single = (float)$rawTt;
        if ($single > 0) { $takttimeArray = [$single]; }
    }

    // Optional: per-model caps from production_model_progress
    $modelPlanTotals = [];
    if (!empty($record_id)) {
        try {
            $rows = $database->select('fproduction_model_progress', '*', [
                'record_id' => $record_id,
                'ORDER' => ['model_index' => 'ASC']
            ]);
            foreach ($rows as $r) {
                $modelPlanTotals[]  = (int)($r['model_plan_total'] ?? 0);
            }
        } catch (Exception $e) {
            $modelPlanTotals = [];
        }
    }

    $modelCount = max(count($takttimeArray), count($modelPlanTotals));
    if ($modelCount === 0) {
        // Fallback to single model behavior using primary drawing takttime
        $remainingPlan = $remainingTotalPlan;
        for ($i = 1; $i <= 5; $i++) {
            $start = $prodRecord["Fstart_Time{$i}"] ?? '';
            $end   = $prodRecord["Fend_Time{$i}"] ?? '';
            $output = 0;
            $byModel = [];
            if ($start && $end && $takttime > 0) {
                $start_ts = strtotime($start);
                $end_ts   = strtotime($end);
                $seconds  = max(0, $end_ts - $start_ts);
                $possible = $seconds > 0 ? floor($seconds / $takttime) : 0;
                $output   = min($possible, $remainingPlan);
                $remainingPlan -= $output;
                // Single-model case: all goes to model 0
                $byModel = [ (int)$output ];
            }
            $planOutputs[$i] = (int)$output;
            $planOutputsByModel[$i] = $byModel;
        }
    } else {
        // Normalize arrays
        for ($k = 0; $k < $modelCount; $k++) {
            if (!isset($takttimeArray[$k]) || $takttimeArray[$k] <= 0) { $takttimeArray[$k] = PHP_FLOAT_MAX; }
            if (!isset($modelPlanTotals[$k])) { $modelPlanTotals[$k] = null; }
        }
        $remainingPerModel = $modelPlanTotals; // null means unlimited

        for ($i = 1; $i <= 5; $i++) {
            $start = $prodRecord["Fstart_Time{$i}"] ?? '';
            $end   = $prodRecord["Fend_Time{$i}"] ?? '';
            $breakTotal = 0;
            $breakByModel = array_fill(0, $modelCount, 0);
            if ($start && $end && $remainingTotalPlan > 0) {
                $start_ts = strtotime($start);
                $end_ts   = strtotime($end);
                $seconds  = max(0, $end_ts - $start_ts);
                if ($seconds > 0) {
                    // Sequential time-based filling across models
                    $secondsLeft = $seconds;
                    for ($m = 0; $m < $modelCount && $secondsLeft > 0 && $remainingTotalPlan > 0; $m++) {
                        $tt = $takttimeArray[$m];
                        if (!($tt > 0 && $tt < PHP_FLOAT_MAX)) { continue; }
                        $modelRemain = $remainingPerModel[$m];
                        if ($modelRemain === null) { $modelRemain = PHP_INT_MAX; }
                        $maxByTime = (int)floor($secondsLeft / $tt);
                        // Stop allocating to later models ONLY if time cannot produce at least 1 unit
                        if ($maxByTime <= 0) { break; }
                        $allocUnits = min($maxByTime, (int)$modelRemain, (int)$remainingTotalPlan);
                        // If this model cannot allocate due to cap/remaining, skip to next model
                        if ($allocUnits <= 0) { continue; }
                        $breakByModel[$m] += $allocUnits;
                        $breakTotal += $allocUnits;
                        $secondsLeft -= $allocUnits * $tt;
                        if ($remainingPerModel[$m] !== null) {
                            $remainingPerModel[$m] = max(0, (int)$remainingPerModel[$m] - $allocUnits);
                        }
                        $remainingTotalPlan = max(0, (int)$remainingTotalPlan - $allocUnits);
                    }
                }
            }
            $planOutputs[$i] = (int)$breakTotal;
            $planOutputsByModel[$i] = $breakByModel;
        }
    }

    // Validate previous breaks must be completed
    $currentBreak = intval($break_number);
    for ($i = 1; $i < $currentBreak; $i++) {
        $prevActual = intval($prodRecord["actual{$i}"] ?? 0);
        $prevPlan   = intval($planOutputs[$i] ?? 0);
        if ($prevActual < $prevPlan) {
            if (function_exists('ob_get_level')) { while (ob_get_level() > 0) { @ob_end_clean(); } }
            echo json_encode([
                'success' => false,
                'message' => "Break {$i} must be completed first (Plan: {$prevPlan}, Actual: {$prevActual})"
            ]);
            exit;
        }
    }

    $updateData = [];
    $breakToUpdate = $currentBreak;
    $applied = false;
    while (!$applied && $breakToUpdate <= 5) {
        $planForBreak   = intval($planOutputs[$breakToUpdate] ?? 0);
        $byModel        = $planOutputsByModel[$breakToUpdate] ?? [];
        $currentActual  = intval($prodRecord["actual{$breakToUpdate}"] ?? 0);
        // Build cumulative thresholds for slices
        $thresholds = [];
        $run = 0;
        foreach ($byModel as $val) { $run += (int)$val; $thresholds[] = $run; }

        // If no byModel (e.g., no time configured), treat as no capacity
        if (empty($thresholds) && $planForBreak > 0) { $thresholds = [$planForBreak]; }

        // Find first slice not yet completed
        $sliceRemaining = 0;
        $currentModelIdx = 0;
        foreach ($thresholds as $idx => $t) {
            if ($currentActual < $t) { $sliceRemaining = $t - $currentActual; $currentModelIdx = $idx; break; }
        }

        // If break has capacity and some slice remainder exists, apply it
        if ($breakToUpdate === 5) {
            // Break 5 unlimited: if thresholds exist, complete the current slice; otherwise add 1
            $batch = 1;
            if ($sliceRemaining > 0) {
                // Use per-model batch if available
                $batch = max(1, (int)($drawingQtyPerModel[$currentModelIdx] ?? 1));
                $toAdd = min($batch, $sliceRemaining);
                $updateData["actual{$breakToUpdate}"] = $currentActual + $toAdd;
            } else {
                $updateData["actual{$breakToUpdate}"] = $currentActual + 1;
            }
            $applied = true;
            break;
        }

        if ($planForBreak > 0 && $currentActual < $planForBreak && $sliceRemaining > 0) {
            // Batch by current model's drawing qty, capped to the slice remainder
            $batch = max(1, (int)($drawingQtyPerModel[$currentModelIdx] ?? 1));
            $toAdd = min($batch, $sliceRemaining);
            $updateData["actual{$breakToUpdate}"] = $currentActual + $toAdd;
            $applied = true;
            break;
        }

        // Otherwise move to next break
        $breakToUpdate++;
    }

    if (!$applied) {
        if (function_exists('ob_get_level')) { while (ob_get_level() > 0) { @ob_end_clean(); } }
        echo json_encode([
            'success' => false,
            'message' => 'No available capacity to update for the selected break(s).'
        ]);
        exit;
    }

    // Recompute total_actual
    $totalActual = 0;
    for ($i = 1; $i <= 5; $i++) {
        if (isset($updateData["actual{$i}"])) {
            $totalActual += intval($updateData["actual{$i}"]);
        } else {
            $totalActual += intval($prodRecord["actual{$i}"] ?? 0);
        }
    }
    $updateData['total_actual'] = $totalActual;

    // Persist
    $ok = $database->update('fproduction_record', $updateData, ['record_id' => $record_id]);
    if (!$ok) {
        if (function_exists('ob_get_level')) { while (ob_get_level() > 0) { @ob_end_clean(); } }
        echo json_encode(['success' => false, 'message' => 'Failed to update output']);
        exit;
    }

    if (function_exists('ob_get_level')) { while (ob_get_level() > 0) { @ob_end_clean(); } }
    echo json_encode([
        'success' => true,
        'message' => 'Output updated successfully',
        'data' => [
            'break_number'   => $currentBreak,
            'updated_breaks' => $updateData,
            'total_actual'   => $totalActual,
            'overflow_handled' => count($updateData) > 1
        ]
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
?>
