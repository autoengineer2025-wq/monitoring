<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include __DIR__ . '/../../database/init.php';

$action = $_GET['action'] ?? '';

if ($action === 'get_models') {
    $models = $database->select("fmodelnumber", ["Fmodel_ID", "Fmodel"]);
    echo json_encode($models);
    exit;
}

if ($action === 'create') {
    $model_ID   = $_POST['modelNumber'] ?? '';
    $drawingnum = $_POST['drawingNumber'] ?? '';
    $takttime   = $_POST['taktTime'] ?? '';
    $length     = $_POST['length'] ?? '';
    $qty        = $_POST['quantity'] ?? '';

    if (!$model_ID || !$drawingnum) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        exit;
    }

    try {
        $result = $database->insert("fdrawingnumber", [
            "Fmodel_ID"   => $model_ID,
            "Fdrawingnum" => $drawingnum,
            "takttime"    => $takttime,
            "length"      => $length,
            "qty"         => $qty
        ]);
        if ($result->rowCount() > 0) {
            echo json_encode(['success' => true, 'id' => $database->id()]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Insert failed']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

if ($action === 'get_drawings') {
    // Join fdrawingnumber and fmodelnumber to get model name
    $drawings = $database->select("fdrawingnumber", [
        "[>]fmodelnumber" => ["Fmodel_ID" => "Fmodel_ID"]
    ], [
        "fdrawingnumber.Fdrawing_ID",
        "fdrawingnumber.Fmodel_ID",
        "fmodelnumber.Fmodel",
        "fdrawingnumber.Fdrawingnum",
        "fdrawingnumber.takttime",
        "fdrawingnumber.length",
        "fdrawingnumber.qty"
    ]);
    echo json_encode($drawings);
    exit;
}

if ($action === 'edit') {
    $id        = $_POST['Fdrawing_ID'] ?? '';
    $model_ID  = $_POST['modelNumber'] ?? '';
    $drawingnum= $_POST['drawingNumber'] ?? '';
    $takttime  = $_POST['taktTime'] ?? '';
    $length    = $_POST['length'] ?? '';
    $qty       = $_POST['quantity'] ?? '';

    if (!$id || !$model_ID || !$drawingnum) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        exit;
    }

    try {
        $result = $database->update("fdrawingnumber", [
            "Fmodel_ID"   => $model_ID,
            "Fdrawingnum" => $drawingnum,
            "takttime"    => $takttime,
            "length"      => $length,
            "qty"         => $qty
        ], [
            "Fdrawing_ID" => $id
        ]);
        if ($result->rowCount() > 0) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Update failed or no changes']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

if ($action === 'delete') {
    $id = $_POST['Fdrawing_ID'] ?? '';
    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'Missing drawing ID']);
        exit;
    }
    try {
        $result = $database->delete("fdrawingnumber", [
            "Fdrawing_ID" => $id
        ]);
        if ($result->rowCount() > 0) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Delete failed']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}