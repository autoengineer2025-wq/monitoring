<?php
header('Content-Type: application/json');
include __DIR__ . '/../../database/init.php';

$action = $_GET['action'] ?? '';

if ($action === 'fetch') {
    $rows = $database->select("fproductiontime", "*");
    echo json_encode($rows);
    exit;
}

if ($action === 'add') {
    $data = [
        "Fprod_name"    => $_POST['productionName'] ?? '',
        "Fprod_hours"   => $_POST['productionHours'] ?? 0,
        "Fshift"        => $_POST['Fshift'] ?? 'Day',
        "Fstart_Time1"  => $_POST['startTime1'] ?? null,
        "Fend_Time1"    => $_POST['endTime1'] ?? null,
        "Fstart_Time2"  => $_POST['startTime2'] ?? null,
        "Fend_Time2"    => $_POST['endTime2'] ?? null,
        "Fstart_Time3"  => $_POST['startTime3'] ?? null,
        "Fend_Time3"    => $_POST['endTime3'] ?? null,
        "Fstart_Time4"  => $_POST['startTime4'] ?? null,
        "Fend_Time4"    => $_POST['endTime4'] ?? null,
        "Fstart_Time5"  => $_POST['startTime5'] ?? null,
        "Fend_Time5"    => $_POST['endTime5'] ?? null,
    ];
    $result = $database->insert("fproductiontime", $data);
    echo json_encode(['success' => (bool)$result, 'id' => $database->id()]);
    exit;
}

if ($action === 'edit') {
    $id = $_POST['Fprod_ID'] ?? '';
    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'Missing ID']);
        exit;
    }
    $data = [
        "Fprod_name"    => $_POST['productionName'] ?? '',
        "Fprod_hours"   => $_POST['productionHours'] ?? 0,
        "Fshift"        => $_POST['Fshift'] ?? 'Day',
        "Fstart_Time1"  => $_POST['startTime1'] ?? null,
        "Fend_Time1"    => $_POST['endTime1'] ?? null,
        "Fstart_Time2"  => $_POST['startTime2'] ?? null,
        "Fend_Time2"    => $_POST['endTime2'] ?? null,
        "Fstart_Time3"  => $_POST['startTime3'] ?? null,
        "Fend_Time3"    => $_POST['endTime3'] ?? null,
        "Fstart_Time4"  => $_POST['startTime4'] ?? null,
        "Fend_Time4"    => $_POST['endTime4'] ?? null,
        "Fstart_Time5"  => $_POST['startTime5'] ?? null,
        "Fend_Time5"    => $_POST['endTime5'] ?? null,
    ];
    $result = $database->update("fproductiontime", $data, ["Fprod_ID" => $id]);
    echo json_encode(['success' => $result->rowCount() > 0]);
    exit;
}

if ($action === 'delete') {
    $id = $_POST['Fprod_ID'] ?? '';
    if (!$id) {
        echo json_encode(['success' => false, 'message' => 'Missing ID']);
        exit;
    }
    $result = $database->delete("fproductiontime", ["Fprod_ID" => $id]);
    echo json_encode(['success' => $result->rowCount() > 0]);
    exit;
}