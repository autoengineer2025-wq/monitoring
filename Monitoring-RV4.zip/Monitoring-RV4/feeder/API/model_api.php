<?php
header('Content-Type: application/json');
include __DIR__ . '/../../database/init.php';

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        $models = $database->select('fmodelnumber', '*');
        echo json_encode($models);
        break;

    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);
        $modelNumber = trim($input['modelNumber'] ?? '');
        if ($modelNumber !== '') {
            $database->insert('fmodelnumber', ['Fmodel' => $modelNumber]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Model number required']);
        }
        break;

    case 'PUT':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        $modelNumber = trim($input['modelNumber'] ?? '');
        if ($id && $modelNumber !== '') {
            $database->update('fmodelnumber', ['Fmodel' => $modelNumber], ['Fmodel_ID' => $id]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Invalid data']);
        }
        break;

    case 'DELETE':
        $input = json_decode(file_get_contents('php://input'), true);
        $id = intval($input['id'] ?? 0);
        if ($id) {
            $database->delete('fmodelnumber', ['Fmodel_ID' => $id]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Invalid ID']);
        }
        break;
}
exit;