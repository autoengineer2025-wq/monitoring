<?php
    header('Content-type: application/json');
    include __DIR__ . '/../../database/init.php';
    
    $action = $_GET['action'];
    if ($action === 'fetch'){
        $lines = $database->select("fline", ['Fline_ID', 'Flinenumber']);
        echo json_encode($lines);
        exit;
    }
    
    if ($action === 'add'){
        $linenum = $_POST['Flinenumber'] ?? '';
        if (!$linenum){
            echo json_encode(['error' => 'Line number is required']);
            exit;
        }
        $result = $database->insert('fline', ['Flinenumber' => $linenum]);
        echo json_encode(['success' => (bool)$result, 'id' => $database->id()]);
        exit;
    }
    
    if ($action === 'delete'){
        $id = $_POST['Fline_ID'] ?? '';
        if (!$id){
            echo json_encode(['error' => 'Line ID is required']);
            exit;
        }
        $result = $database->delete("fline", ['Fline_ID' => $id]);
        echo json_encode(['success' => $result->rowCount() > 0]);
        exit;    
    }
    