<?php
header('Content-Type: application/json');
include __DIR__ . '/../../database/init.php';

$action = $_GET['action'] ?? 'get_latest';

function safe_int($v, $def = 0) { return is_numeric($v) ? (int)$v : $def; }
function safe_str($v, $def = '') { return is_string($v) ? $v : $def; }

try {
    if ($action === 'get_latest') {
        $date = $_GET['production_date'] ?? date('Y-m-d');
        $line = $_GET['line_id'] ?? '';
        $shift = $_GET['shift'] ?? '';
        if ($line === '' || $shift === '') {
            echo json_encode(['success' => false, 'message' => 'Missing line_id or shift']);
            exit;
        }

        $record = $database->get('fproduction_record', '*', [
            'production_date' => $date,
            'Fline_ID' => $line,
            'Shift' => $shift,
            'ORDER' => ['created_at' => 'DESC']
        ]);

        if (!$record) {
            echo json_encode(['success' => true, 'data' => null]);
            exit;
        }

        $record_id = $record['record_id'] ?? null;
        $rejects = [];
        if ($record_id) {
            try {
                $rejRows = $database->select('fproduction_rejects', ['break_number','qty'], [ 'record_id' => $record_id ]);
                foreach ($rejRows as $rj) {
                    $bn = safe_int($rj['break_number']);
                    if ($bn >= 1 && $bn <= 5) {
                        $rejects[(string)$bn] = safe_int($rj['qty']);
                    }
                }
            } catch (Exception $e) {
                $rejects = [];
            }
        }

        $fields = [
            'record_id' => $record['record_id'] ?? null,
            'plan_target' => safe_int($record['plan_target'] ?? 0),
            'target' => safe_int($record['target'] ?? 0),
            'total_actual' => safe_int($record['total_actual'] ?? 0),
            'takttime' => safe_str($record['takttime'] ?? ''),
            'Fdrawing_ID' => safe_str($record['Fdrawing_ID'] ?? ''),
        ];

        for ($i=1; $i<=5; $i++) {
            $fields["actual{$i}"] = safe_int($record["actual{$i}"] ?? 0);
            $fields["Fstart_Time{$i}"] = safe_str($record["Fstart_Time{$i}"] ?? '');
            $fields["Fend_Time{$i}"] = safe_str($record["Fend_Time{$i}"] ?? '');
        }

        echo json_encode(['success' => true, 'data' => $fields, 'rejects' => $rejects]);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Unknown action']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error']);
}
