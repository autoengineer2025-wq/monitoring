<?php
include_once '../../database/init.php'; 

// Fetch production times (feeder schema)
$prodTimes = $database->select("fproductiontime", "*");

// Fetch lines
$lines = $database->select("fline", "*");
$today = date('Y-m-d');
$selectedLine = $_GET['line'] ?? ($lines[0]['Fline_ID'] ?? '');
$selectedShift = $_GET['shift'] ?? 'Day Shift';

// Fetch production records for today, selected line, and shift
$prodRecords = $database->select("fproduction_record", "*", [
    "production_date" => $today,
    "Fline_ID" => $selectedLine,
    "Shift" => $selectedShift
]);
$planTarget = isset($prodRecords[0]) ? intval($prodRecords[0]['plan_target']) : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Feeder Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="../../node_modules/bootstrap/dist/css/bootstrap.min.css">
  <!-- Bootstrap Icons CSS -->
  <link rel="stylesheet" href="../../node_modules/bootstrap-icons/font/bootstrap-icons.css">
  <!-- App Styles -->
  <link rel="stylesheet" href="../API/style.css">
</head> 

<body>
  <!-- Hidden inputs for real-time target calculation -->
  <?php if (!empty($prodRecords)): ?>
  <input type="hidden" id="plan_target" value="<?= intval($prodRecords[0]['plan_target']) ?>">
  <input type="hidden" id="takttime" value="<?= htmlspecialchars($prodRecords[0]['takttime'] ?? '') ?>">
  <?php for ($i = 1; $i <= 5; $i++): ?>
  <input type="hidden" id="start_time_<?= $i ?>" value="<?= htmlspecialchars($prodRecords[0]["Fstart_Time$i"] ?? '') ?>">
  <input type="hidden" id="end_time_<?= $i ?>" value="<?= htmlspecialchars($prodRecords[0]["Fend_Time$i"] ?? '') ?>">
  <?php endfor; ?>
  <?php endif; ?>
  
  <div class="container-fluid p-4">
  <div class="d-flex justify-content-between align-items-center mb-4">
  <h4>Feeder Dashboard</h4>
  <div>
  <i class="bi bi-gear-fill" data-bs-toggle="modal" data-bs-target="#settingsModal" style="cursor:pointer;"></i>
  </div>
  </div>
  <div class="row mb-3">
  <div class="col-md-4 d-flex align-items-center">
  <span class="fw-bold me-2">Line Number:</span>
  <span><h1 class="fw-bold me-2"></h1></span>
  </div>
  <div class="col-md-4 d-flex align-items-center">
    <span class="fw-bold me-2">Shift:</span>
    <span></span>  
  </div>
  <div class="col-md-4 d-flex align-items-center justify-content-md-end">
  <span class="me-3"><i class="bi bi-calendar"></i> <span id="current-date"></span></span> 
  <span><i class="bi bi-clock"></i> <span id="current-time"></span></span>
  </div>
  </div>


  <div class="row g-3 mb-3 justify-content-center">
  <div class="col-6 col-md-3">
  <div class="card-custom text-center h-100">
  <div class="card-header-small d-flex justify-content-between align-items-center">PLAN</div>
  <div class="card-value text-primary">0</div>
</div>
  </div>
  <div class="col-6 col-md-3">
  <div class="card-custom text-center h-100">
  <div class="card-header-small d-flex justify-content-between align-items-center">TARGET</div>
  <div class="card-value text-success">0</div>
  </div>
  </div>
  <div class="col-6 col-md-3">
  <div class="card-custom text-center h-100">
  <div class="card-title d-flex justify-content-between align-items-center">
  <span>ACTUAL</span>
  <button class="btn btn-sm btn-primary">Edit</button>
  </div>
  <div class="card-value text-dark">0</div>
  </div>
  </div>
  <div class="col-6 col-md-3">
  <div class="card-custom text-center h-100">
  <div class="card-header-small d-flex justify-content-between align-items-center">DIFFERENCE</div>
  <div class="card-value text-danger">0</div>
  </div>
  </div>
  </div>

  <!-- 2nd Row: Achievement Rate, Past 3 Months Output, Data Analytics Board -->
<div class="row g-2 mb-2">
  <!-- Achievement Rate Card -->
  <div class="col-12 col-sm-6 col-md-3">
    <div class="card-custom h-100 d-flex flex-column justify-content-between px-3 py-2">
      <div class="d-flex align-items-center justify-content-between w-100 mb-1">
        <strong style="font-size:1.1rem;">Achievement Rate</strong>
        <div class="d-flex flex-wrap gap-1 ms-2">
          <span class="badge bg-danger px-2 py-1">95%↓</span>
          <span class="badge bg-warning text-dark px-2 py-1">96-99%</span>
          <span class="badge bg-success px-2 py-1">100%</span>
          <span class="badge bg-primary px-2 py-1">101%↑</span>
        </div>
      </div>
      <div class="d-flex justify-content-center w-100 mt-auto">
        <canvas id="achievementChart" width="150" height="150"></canvas> <!-- Adjusted canvas size -->
      </div>
    </div>
  </div>


  <!-- DATA ANALYTICS BOARD -->
  <div class="col-12 col-sm-6 col-md-9">
    <div class="card-custom h-100 d-flex flex-column px-2 py-1">
        <div class="d-flex justify-content-between align-items-center mb-1">
            <strong style="font-size:0.9rem;">Data Analytics Board</strong>
            <button class="btn btn-sm btn-primary py-0 px-2">Add</button>
        </div>
        <div class="table-responsive flex-grow-1">
            <table class="table table-bordered table-sm text-center mb-0">
                <tr>
                    <th colspan="2" rowspan="2" style="text-align: center; vertical-align: middle;">
                      Break
                    </th>
                    <th colspan="2">Time</th>
                    <th rowspan="2" style="text-align: center; vertical-align: middle;">
                      WORK HR
                    </th>                    
                    <th colspan="2">PLAN</th>
                    <th colspan="2">RESULT</th>
                    <th colspan="2">DIFF</th>
                    <th colspan="2">REJECT</th>
                    <th colspan="3" rowspan="2" style="text-align: center; vertical-align: middle;">REMARKS</th>
                </tr>
                <tr>
                    <th>Start</th>  
                    <th>End</th>
                    <th>Output</th>
                    <th>Accu</th>
                    <th>Output</th>
                    <th>Accu</th>
                    <th>Balanced</th>
                    <th>Accu</th>
                    <th>Qty</th>
                    <th>Accu</th>
                </tr>
                <tr>
                    <td colspan="2"></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><b></b></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td colspan="2">—</td>
                </tr>
            </table>
        </div>
    </div>
</div>
</div>


</div>
<!-- Modal -->
<div class="modal fade" id="settingsModal" tabindex="-1" aria-labelledby="settingsModalLabel" aria-hidden="true">
<div class="modal-dialog modal-xl">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="settingsModalLabel">Settings</h5>
<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
<div class="modal-body">
<form id="settingsForm">
<div class="mb-3">
<label for="prodDate" class="form-label">Production Date</label> 
<input type="date" class="form-control" id="prodDate" name="prodDate">
</div>
<div class="mb-3">
<label for="shift" class="form-label">Shift</label>
<select class="form-select" id="shift" name="shift">
  <option value="">Select shift</option>
  <option value="Day">Day</option>
  <option value="Night">Night</option>
</select>
</div>
<div class="mb-3">
<label for="prodTime" class="form-label">Production Time</label>
<select class="form-select" id="prodTime" name="prodTime">
  <option value="">Select production time</option>
  <?php foreach($prodTimes as $pt): ?>
    <option value="<?= $pt['Fprod_ID'] ?>"><?= htmlspecialchars($pt['Fprod_hours']) ?></option>
  <?php endforeach; ?>
</select>
</div>
<div class="mb-3">
<label for="lineNumber" class="form-label">Line Number</label>
<select class="form-select" id="lineNumber" name="lineNumber">
  <option value="">Select line number</option>
  <?php foreach($lines as $line): ?>
    <option value="<?= $line['Fline_ID'] ?>"><?= htmlspecialchars($line['Fline_ID']) ?></option>
  <?php endforeach; ?>
</select>
  </div>

<div class="mb-3">
<label for="mCount" class="form-label">Model Count</label>
<select class="form-select" id="mCount" name="mCount" onchange="toggleDrawingFields()">
  <option value="">Select model count</option>
  <?php for($i=1;$i<=15;$i++): ?>
    <option value="<?= $i ?>"><?= $i ?></option>
  <?php endfor; ?>
</select>
<div id="drawingFields" style="display:none; margin-top:15px;"></div>
</div>
<?php for($i=1;$i<=5;$i++): ?>
  <input type="hidden" id="Fstart_Time<?= $i ?>" name="Fstart_Time<?= $i ?>">
  <input type="hidden" id="Fend_Time<?= $i ?>" name="Fend_Time<?= $i ?>">
<?php endfor; ?>
</form>
</div>
<div class="modal-footer">
  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
  <button type="button" class="btn btn-primary" id="saveSettingsBtn">Save changes</button>
</div>
</div>
</div>
</div>



  <script src="../../node_modules/jquery/dist/jquery.min.js"></script>
  <script src="../../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../../node_modules/chart.js/dist/chart.umd.js"></script>
  <script src="../JS/line1.js"></script>
  <script src="../JS/api.js"></script>
  <script>
    (function(){
      function updateClock(){
        const now = new Date();
        const dateStr = now.toLocaleDateString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
        const timeStr = now.toLocaleTimeString();
        const d = document.getElementById('current-date');
        const t = document.getElementById('current-time');
        if (d) d.textContent = dateStr;
        if (t) t.textContent = timeStr;
      }
      updateClock();
      setInterval(updateClock, 1000);

      let _allProdTimes = null; // cached from API

      function fetchAllProdTimes(){
        if (_allProdTimes) return Promise.resolve(_allProdTimes);
        return fetch('../API/prodtime_api.php?action=fetch')
          .then(r => r.json())
          .then(rows => { _allProdTimes = Array.isArray(rows) ? rows : []; return _allProdTimes; })
          .catch(() => { _allProdTimes = []; return _allProdTimes; });
      }

      function populateProdTimes(filterShift){
        const sel = document.getElementById('prodTime');
        if (!sel) return;
        const rows = (_allProdTimes || []);
        const fx = (filterShift || '').toLowerCase();
        const filtered = fx ? rows.filter(r => (r.Fshift || 'Day').toLowerCase() === fx) : rows;
        // preserve current selection if possible
        const prev = sel.value;
        sel.innerHTML = '<option value="">Select production time</option>';
        filtered.forEach(r => {
          const opt = document.createElement('option');
          opt.value = String(r.Fprod_ID);
          // Show hours as label, optionally name
          opt.textContent = (r.Fprod_hours ? r.Fprod_hours : '') + (r.Fprod_name ? ' ('+r.Fprod_name+')' : '');
          sel.appendChild(opt);
        });
        // try restore
        if ([...sel.options].some(o => o.value === prev)) sel.value = prev;
      }

      // When modal opens, load prod times and bind events
      document.addEventListener('DOMContentLoaded', function(){
        const modalEl = document.getElementById('settingsModal');
        if (!modalEl) return;
        modalEl.addEventListener('show.bs.modal', function(){
          fetchAllProdTimes().then(() => {
            const shiftSel = document.getElementById('shift');
            const currentShift = (shiftSel && shiftSel.value) ? shiftSel.value : '';
            populateProdTimes(currentShift);
          });
        });

        const shiftSel = document.getElementById('shift');
        if (shiftSel) {
          shiftSel.addEventListener('change', function(){
            populateProdTimes(this.value);
          });
        }
      });
    })();
  </script>
</body>
</html>
