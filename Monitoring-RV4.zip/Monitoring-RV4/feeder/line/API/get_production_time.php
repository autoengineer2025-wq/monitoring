<?php
include_once '../../../database/init.php';
header('Content-Type: application/json');
$id = $_GET['id'] ?? '';
if ($id) {
    $row = $database->get("fproductiontime", "*", ["Fprod_ID" => $id]);

    if ($row) {
        $result = [];
        if (isset($row['Fprod_hours'])) {
            $result['Fprod_hours'] = $row['Fprod_hours'];
        }
        if (isset($row['Fshift'])) {
            $result['Fshift'] = $row['Fshift'];
        }

        for ($i = 1; $i <= 5; $i++) {
            $result["Fstart_Time$i"] = $row["Fstart_Time$i"] ?? '';
            $result["Fend_Time$i"] = $row["Fend_Time$i"] ?? '';
        }
        echo json_encode($result);
        exit;
    }
}
echo json_encode([]);