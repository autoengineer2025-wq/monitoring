<?php
header('Content-Type: application/json');
include __DIR__ . '/../../../database/init.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_output') {
        $breakNumber = $_POST['break_number'] ?? '';
        $outputValue = $_POST['output_value'] ?? '';
        $productionDate = $_POST['production_date'] ?? '';
        $lineId = $_POST['line_id'] ?? '';
        $shift = $_POST['shift'] ?? '';
        
        if (!$breakNumber || !$productionDate || !$lineId || !$shift) {
            echo json_encode(['success' => false, 'message' => 'Missing required fields']);
            exit;
        }
        
        // Find the production record
        $record = $database->get("fproduction_record", "*", [
            "production_date" => $productionDate,
            "Fline_ID" => $lineId,
            "Shift" => $shift,
            "ORDER" => ["created_at" => "DESC"]
        ]);
        
        if (!$record) {
            echo json_encode(['success' => false, 'message' => 'Production record not found']);
            exit;
        }
        
        // Update the output field based on break number and recompute total_actual
        // Column names in fproduction_record are actual1..actual5
        $outputField = "actual" . $breakNumber;

        // Compute new totals from the current record replacing only the targeted break
        $a1 = (int)($record['actual1'] ?? 0);
        $a2 = (int)($record['actual2'] ?? 0);
        $a3 = (int)($record['actual3'] ?? 0);
        $a4 = (int)($record['actual4'] ?? 0);
        $a5 = (int)($record['actual5'] ?? 0);
        $newVal = (int)$outputValue;
        switch ((int)$breakNumber) {
            case 1: $a1 = $newVal; break;
            case 2: $a2 = $newVal; break;
            case 3: $a3 = $newVal; break;
            case 4: $a4 = $newVal; break;
            case 5: $a5 = $newVal; break;
        }
        $totalActual = $a1 + $a2 + $a3 + $a4 + $a5;

        $result = $database->update("fproduction_record", [
            $outputField => $newVal,
            'total_actual' => $totalActual
        ], [
            "production_date" => $productionDate,
            "Fline_ID" => $lineId,
            "Shift" => $shift
        ]);

        if ($result) {
            echo json_encode([
                'success' => true,
                'message' => 'Output updated successfully',
                'data' => [
                    'break_number' => (int)$breakNumber,
                    'output_value' => $newVal,
                    'total_actual' => $totalActual
                ]
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update output']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
