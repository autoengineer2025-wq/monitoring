<?php
include_once '../../../database/init.php';
header('Content-Type: application/json');

// Basic validation
$recordId = $_POST['record_id'] ?? '';
$lineId = $_POST['line_id'] ?? '';
$shift = $_POST['shift'] ?? '';
$productionDate = $_POST['production_date'] ?? '';
$breakNumber = $_POST['break_number'] ?? '';
$classification = $_POST['classification'] ?? '';
$reason = $_POST['reason'] ?? '';
$countermeasure = $_POST['countermeasure'] ?? '';

try {
    if (!$lineId || !$shift || !$productionDate || !$breakNumber || !$classification || !$reason || !$countermeasure) {
        throw new Exception('Missing required fields.');
    }

    // Ensure we have a valid record_id; if not provided, resolve it from date + line + shift
    if (!$recordId) {
        $resolved = $database->get('fproduction_record', '*', [
            'production_date' => $productionDate,
            'Fline_ID' => intval($lineId),
            'Shift' => $shift,
            'ORDER' => ['created_at' => 'DESC']
        ]);
        if ($resolved && isset($resolved['record_id'])) {
            $recordId = $resolved['record_id'];
        }
    }

    if (!$recordId) {
        echo json_encode(['success' => false, 'message' => 'Production record not found for the given date/line/shift. Please save Setup first.']);
        exit;
    }

    // Insert remark
    $database->insert('fproduction_remarks', [
        'record_id' => $recordId,
        'Fline_ID' => $lineId,
        'Shift' => $shift,
        'production_date' => $productionDate,
        'break_number' => intval($breakNumber),
        'classification' => $classification,
        'reason' => $reason,
        'countermeasure' => $countermeasure
    ]);

    if ($database->id()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Insert failed.']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>


