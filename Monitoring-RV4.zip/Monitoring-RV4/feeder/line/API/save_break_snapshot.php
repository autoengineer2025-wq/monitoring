<?php
include_once '../../../database/init.php';
header('Content-Type: application/json');
@ini_set('display_errors', 0);
@ini_set('display_startup_errors', 0);

try {
    $recordId = $_POST['record_id'] ?? $_GET['record_id'] ?? null;
    if (!$recordId) {
        echo json_encode(['success' => false, 'message' => 'record_id is required']);
        exit;
    }

    $database->query(
        "CREATE TABLE IF NOT EXISTS `fproduction_breaks` (
            `id` INT(11) NOT NULL AUTO_INCREMENT,
            `record_id` INT(11) NOT NULL,
            `production_date` DATE NOT NULL,
            `Fline_ID` INT(11) NOT NULL,
            `Shift` VARCHAR(50) NOT NULL,
            `break_number` TINYINT(4) NOT NULL,
            `start_time` TIME NULL,
            `end_time` TIME NULL,
            `work_seconds` INT(11) NOT NULL DEFAULT 0,
            `plan_output` INT(11) NOT NULL DEFAULT 0,
            `plan_accu` INT(11) NOT NULL DEFAULT 0,
            `actual_output` INT(11) NOT NULL DEFAULT 0,
            `actual_accu` INT(11) NOT NULL DEFAULT 0,
            `diff_balanced` INT(11) NOT NULL DEFAULT 0,
            `diff_accu` INT(11) NOT NULL DEFAULT 0,
            `reject_qty` INT(11) NOT NULL DEFAULT 0,
            `reject_accu` INT(11) NOT NULL DEFAULT 0,
            `classification` VARCHAR(100) NULL,
            `reason` TEXT NULL,
            `countermeasure` TEXT NULL,
            `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            UNIQUE KEY `uniq_record_break_date` (`record_id`, `break_number`, `production_date`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
    );

    // Load production record
    $prodRecord = $database->get('fproduction_record', '*', ['record_id' => $recordId]);
    if (!$prodRecord) {
        echo json_encode(['success' => false, 'message' => 'Production record not found']);
        exit;
    }

    $production_date = $prodRecord['production_date'];
    $Fline_ID = (int)($prodRecord['Fline_ID'] ?? 0);
    $Shift = (string)($prodRecord['Shift'] ?? '');

    // Resolve drawing IDs and takttimes
    $rawDrawingIds = $prodRecord['Fdrawing_ID'] ?? '';
    $drawingIdArray = array_values(array_filter(array_map('trim', explode(',', $rawDrawingIds)), function($v){ return $v !== ''; }));

    $takttimeArray = [];
    $rawTt = $prodRecord['takttime'] ?? '';
    if ($rawTt && strpos($rawTt, ',') !== false) {
        $takttimeArray = array_values(array_filter(array_map(function($v){
            $f = (float)trim($v);
            return $f > 0 ? $f : null;
        }, explode(',', $rawTt))));
    } elseif ($rawTt) {
        $single = (float)$rawTt;
        if ($single > 0) { $takttimeArray = [$single]; }
    }

    // Load per-model plan caps if any
    $modelPlanTotals = [];
    try {
        $rows = $database->select('fproduction_model_progress', '*', [
            'record_id' => $recordId,
            'ORDER' => ['model_index' => 'ASC']
        ]);
        foreach ($rows as $r) { $modelPlanTotals[] = (int)($r['model_plan_total'] ?? 0); }
    } catch (Exception $e) { $modelPlanTotals = []; }

    // Compute plan outputs by break (similar to UI logic)
    $planOutputs = [];
    $planOutputsByModel = [];
    $remainingTotalPlan = (int)($prodRecord['plan_target'] ?? 0);

    $modelCount = max(count($takttimeArray), count($modelPlanTotals));
    if ($modelCount === 0) {
        // Single-model fallback using first takttime if available
        $primaryTakt = 0.0;
        if (!empty($takttimeArray)) { $primaryTakt = (float)$takttimeArray[0]; }
        $remainingPlan = $remainingTotalPlan;
        for ($i = 1; $i <= 5; $i++) {
            $start = $prodRecord["Fstart_Time{$i}"] ?? '';
            $end   = $prodRecord["Fend_Time{$i}"] ?? '';
            $out = 0; $byModel = [];
            if ($start && $end && $primaryTakt > 0) {
                $sec = max(0, strtotime($end) - strtotime($start));
                $possible = $sec > 0 ? floor($sec / $primaryTakt) : 0;
                $out = (int)min($possible, $remainingPlan);
                $remainingPlan -= $out;
                $byModel = [$out];
            }
            $planOutputs[$i] = $out;
            $planOutputsByModel[$i] = $byModel;
        }
    } else {
        for ($k = 0; $k < $modelCount; $k++) {
            if (!isset($takttimeArray[$k]) || $takttimeArray[$k] <= 0) { $takttimeArray[$k] = PHP_FLOAT_MAX; }
            if (!isset($modelPlanTotals[$k])) { $modelPlanTotals[$k] = null; }
        }
        $remainingPerModel = $modelPlanTotals; // null => unlimited
        for ($i = 1; $i <= 5; $i++) {
            $start = $prodRecord["Fstart_Time{$i}"] ?? '';
            $end   = $prodRecord["Fend_Time{$i}"] ?? '';
            $breakTotal = 0; $breakByModel = array_fill(0, $modelCount, 0);
            if ($start && $end && $remainingTotalPlan > 0) {
                $seconds  = max(0, strtotime($end) - strtotime($start));
                if ($seconds > 0) {
                    $secondsLeft = $seconds;
                    for ($m = 0; $m < $modelCount && $secondsLeft > 0 && $remainingTotalPlan > 0; $m++) {
                        $tt = $takttimeArray[$m];
                        if (!($tt > 0 && $tt < PHP_FLOAT_MAX)) { continue; }
                        $modelRemain = $remainingPerModel[$m];
                        if ($modelRemain === null) { $modelRemain = PHP_INT_MAX; }
                        $maxByTime = (int)floor($secondsLeft / $tt);
                        if ($maxByTime <= 0) { break; }
                        $allocUnits = min($maxByTime, (int)$modelRemain, (int)$remainingTotalPlan);
                        if ($allocUnits <= 0) { continue; }
                        $breakByModel[$m] += $allocUnits;
                        $breakTotal += $allocUnits;
                        $secondsLeft -= $allocUnits * $tt;
                        if ($remainingPerModel[$m] !== null) {
                            $remainingPerModel[$m] = max(0, (int)$remainingPerModel[$m] - $allocUnits);
                        }
                        $remainingTotalPlan = max(0, (int)$remainingTotalPlan - $allocUnits);
                    }
                }
            }
            $planOutputs[$i] = (int)$breakTotal;
            $planOutputsByModel[$i] = $breakByModel;
        }
    }

    // Load rejects by break for this record
    $rejectsByBreak = [];
    try {
        $rejRows = $database->select('fproduction_rejects', '*', [ 'record_id' => $recordId ]);
        foreach ($rejRows as $rj) { $rejectsByBreak[(int)$rj['break_number']] = (int)$rj['qty']; }
    } catch (Exception $e) { $rejectsByBreak = []; }

    // Load remarks strictly by record_id (prefer the latest per break)
    $remarksByBreak = [];
    try {
        $rRows = $database->select('fproduction_remarks', '*', [
            'record_id' => $recordId,
            'ORDER' => [ 'break_number' => 'ASC', 'id' => 'DESC' ]
        ]);
        foreach ($rRows as $r) {
            $bn = (int)($r['break_number'] ?? 0);
            if ($bn <= 0) continue;
            // Keep only the latest per break (since ordered by id DESC within break groups)
            if (!isset($remarksByBreak[$bn])) {
                $remarksByBreak[$bn] = $r;
            }
        }
        // Fallback: if table has no 'id' column, the order clause will be ignored safely by Medoo
    } catch (Exception $e) { $remarksByBreak = []; }

    // Compute and upsert all 5 breaks
    $accuPlan = 0; $accuReject = 0; $accuActual = 0;
    $results = [];
    for ($i = 1; $i <= 5; $i++) {
        $start = $prodRecord["Fstart_Time{$i}"] ?? null;
        $end   = $prodRecord["Fend_Time{$i}"] ?? null;
        $workSeconds = 0;
        if ($start && $end) {
            $st = strtotime($start); $en = strtotime($end);
            if ($en > $st) { $workSeconds = $en - $st; }
        }
        $plan = (int)($planOutputs[$i] ?? 0);
        $accuPlan += $plan;
        $actual = (int)($prodRecord["actual{$i}"] ?? 0);
        $accuActual += $actual;
        $diff = $actual - $plan;
        $diffAccu = $accuActual - $accuPlan;
        $rej = (int)($rejectsByBreak[$i] ?? 0);
        $accuReject += $rej;
        $remark = $remarksByBreak[$i] ?? null;

        // Upsert row
        $existing = $database->get('fproduction_breaks', '*', [
            'record_id' => $recordId,
            'break_number' => $i,
            'production_date' => $production_date
        ]);

        $rowData = [
            'record_id' => (int)$recordId,
            'production_date' => $production_date,
            'Fline_ID' => $Fline_ID,
            'Shift' => $Shift,
            'break_number' => $i,
            'start_time' => $start ?: null,
            'end_time' => $end ?: null,
            'work_seconds' => $workSeconds,
            'plan_output' => $plan,
            'plan_accu' => $accuPlan,
            'actual_output' => $actual,
            'actual_accu' => $accuActual,
            'diff_balanced' => $diff,
            'diff_accu' => $diffAccu,
            'reject_qty' => $rej,
            'reject_accu' => $accuReject,
            'classification' => $remark['classification'] ?? null,
            'reason' => $remark['reason'] ?? null,
            'countermeasure' => $remark['countermeasure'] ?? null,
            'updated_at' => date('Y-m-d H:i:s')
        ];

        if ($existing) {
            $database->update('fproduction_breaks', $rowData, [
                'record_id' => $recordId,
                'break_number' => $i,
                'production_date' => $production_date
            ]);
        } else {
            $rowData['created_at'] = date('Y-m-d H:i:s');
            $database->insert('fproduction_breaks', $rowData);
        }

        $results[$i] = $rowData;
    }

    echo json_encode(['success' => true, 'data' => $results]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}
