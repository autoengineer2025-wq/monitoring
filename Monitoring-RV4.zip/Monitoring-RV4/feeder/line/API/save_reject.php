<?php
include_once '../../../database/init.php';
header('Content-Type: application/json');

try {
    $recordId = $_POST['record_id'] ?? null;
    $breakNumber = intval($_POST['break_number'] ?? 0);
    $qty = intval($_POST['qty'] ?? 0);
    if (!$recordId || $breakNumber <= 0) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        exit;
    }


    $existing = $database->get('fproduction_rejects', '*', [
        'record_id' => $recordId,
        'break_number' => $breakNumber
    ]);

    if ($existing) {
        $res = $database->update('fproduction_rejects', ['qty' => $qty], [
            'record_id' => $recordId,
            'break_number' => $breakNumber
        ]);
    } else {
        $res = $database->insert('fproduction_rejects', [
            'record_id' => $recordId,
            'break_number' => $breakNumber,
            'qty' => $qty
        ]);
    }

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>


