<?php
include_once '../../../database/init.php';

header('Content-Type: application/json');

// Get parameters
$viewType = $_GET['view'] ?? 'weekly';
$lineId = $_GET['line'] ?? '';
$shift = $_GET['shift'] ?? 'Day Shift';

try {
    $today = date('Y-m-d');
    $data = [];

    // Helper: sum rejects for a given record id
    $sumRejectsByRecord = function($recordId) use ($database) {
        if (empty($recordId)) return 0;
        try {
            $rows = $database->select('fproduction_rejects', ['qty'], ['record_id' => intval($recordId)]);
            $sum = 0;
            foreach ((array)$rows as $r) { $sum += (int)($r['qty'] ?? 0); }
            return $sum;
        } catch (Exception $e) { return 0; }
    };

    if ($viewType === 'daily') {
        // Daily view: 1st day of current month to last day of current month
        $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth = date('Y-m-t');
        
        $currentDate = new DateTime($firstDayOfMonth);
        $endDate = new DateTime($lastDayOfMonth);
        
        while ($currentDate <= $endDate) {
            $dateStr = $currentDate->format('Y-m-d');
            $dayName = $currentDate->format('D');
            $dayDate = $currentDate->format('M j');
            
            // Fetch all production records for this date (some days can have multiple entries)
            $dayRecords = $database->select("fproduction_record", "*", [
                "production_date" => $dateStr,
                "Fline_ID" => $lineId,
                "Shift" => $shift,
                "ORDER" => ["created_at" => "ASC"]
            ]);

            // Aggregate metrics for the day
            $output = 0;
            $planTarget = 0;
            $rejectCount = 0;
            foreach ((array)$dayRecords as $rec) {
                $output += intval($rec['total_actual'] ?? 0);
                $planTarget += intval($rec['plan_target'] ?? 0);
                $rejectCount += $sumRejectsByRecord($rec['record_id'] ?? 0);
            }

            // Calculate operation rate (actual vs plan)
            $operationRate = $planTarget > 0 ? round(($output / $planTarget) * 100, 1) : 0;

            // Calculate yield rate from actual rejects table
            $totalProduced = $output + $rejectCount;
            $yieldRate = $totalProduced > 0 ? round((($totalProduced - $rejectCount) / $totalProduced) * 100, 2) : 0;
            
            $data[] = [
                'label' => "$dayName $dayDate",
                'output' => $output,
                'operationRate' => $operationRate,
                'yieldRate' => $yieldRate,
                // Provide per-day plan target for mixed chart bars
                'plan' => $planTarget
            ];
            
            $currentDate->add(new DateInterval('P1D'));
        }
        
    } elseif ($viewType === 'weekly') {
        // Weekly view: Each week of current month
        $firstDayOfMonth = date('Y-m-01');
        $lastDayOfMonth = date('Y-m-t');
        
        $currentDate = new DateTime($firstDayOfMonth);
        $endDate = new DateTime($lastDayOfMonth);
        
        $weekNumber = 1;
        $weekStart = clone $currentDate;
        
        while ($currentDate <= $endDate) {
            $dayOfWeek = $currentDate->format('N');
            
            if ($dayOfWeek == 1 || $currentDate->format('j') == 1) {
                // Start of a new week
                $weekStart = clone $currentDate;
            }
            
            // Check if this is the end of a week (Sunday) or last day of month
            if ($dayOfWeek == 7 || $currentDate->format('j') == $endDate->format('j')) {
                // End of a week, calculate weekly totals
                $weekEnd = clone $currentDate;
                
                // Get all records for this week
                $weekRecords = $database->select("fproduction_record", "*", [
                    "AND" => [
                        "production_date[>=]" => $weekStart->format('Y-m-d'),
                        "production_date[<=]" => $weekEnd->format('Y-m-d'),
                        "Fline_ID" => $lineId,
                        "Shift" => $shift
                    ],
                    "ORDER" => ["production_date" => "ASC"]
                ]);
                
                // Calculate aggregated metrics for the week
                $totalOutput = 0;
                $totalPlanTarget = 0;
                $totalRejectCount = 0;
                $totalProduced = 0;
                
                foreach ($weekRecords as $record) {
                    $totalOutput += intval($record['total_actual']);
                    $totalPlanTarget += intval($record['plan_target']);
                    $totalRejectCount += $sumRejectsByRecord($record['record_id'] ?? 0);
                }
                
                $totalProduced = $totalOutput + $totalRejectCount;
                
                // Calculate operation rate (actual vs plan)
                $operationRate = $totalPlanTarget > 0 ? round(($totalOutput / $totalPlanTarget) * 100, 1) : 0;
                
                // Calculate yield rate
                $yieldRate = $totalProduced > 0 ? round((($totalProduced - $totalRejectCount) / $totalProduced) * 100, 2) : 0;
                
                $weekLabel = "Week " . $weekNumber . " (" . $weekStart->format('M j') . " - " . $weekEnd->format('M j') . ")";
                
                $data[] = [
                    'label' => $weekLabel,
                    'output' => $totalOutput,
                    'operationRate' => $operationRate,
                    'yieldRate' => $yieldRate
                ];
                
                $weekNumber++;
            }
            
            $currentDate->add(new DateInterval('P1D'));
        }
        
    } else {
        // 3 Months view: Past 3 months aggregated by month
        $currentMonth = new DateTime($today);
        $threeMonthsAgo = new DateTime($today);
        $threeMonthsAgo->modify('-3 months');
        
        $currentDate = new DateTime($threeMonthsAgo->format('Y-m-01'));
        
        while ($currentDate <= $currentMonth) {
            $monthStr = $currentDate->format('Y-m');
            $monthLabel = $currentDate->format('M Y');
            
            $monthRecords = $database->select("fproduction_record", "*", [
                "AND" => [
                    "production_date[~]" => $monthStr . '%',
                    "Fline_ID" => $lineId,
                    "Shift" => $shift
                ],
                "ORDER" => ["production_date" => "ASC"]
            ]);
            
            // Calculate aggregated metrics for the month
            $totalOutput = 0;
            $totalPlanTarget = 0;
            $totalRejectCount = 0;
            $totalProduced = 0;
            
            foreach ($monthRecords as $record) {
                $totalOutput += intval($record['total_actual']);
                $totalPlanTarget += intval($record['plan_target']);
                $totalRejectCount += $sumRejectsByRecord($record['record_id'] ?? 0);
            }
            
            $totalProduced = $totalOutput + $totalRejectCount;
            
            // Calculate operation rate (actual vs plan)
            $operationRate = $totalPlanTarget > 0 ? round(($totalOutput / $totalPlanTarget) * 100, 1) : 0;
            
            // Calculate yield rate
            $yieldRate = $totalProduced > 0 ? round((($totalProduced - $totalRejectCount) / $totalProduced) * 100, 2) : 0;
            
            $data[] = [
                'label' => $monthLabel,
                'output' => $totalOutput,
                'operationRate' => $operationRate,
                'yieldRate' => $yieldRate
            ];
            
            $currentDate->modify('+1 month');
        }
    }
    
    echo json_encode([
        'success' => true,
        'data' => $data,
        'title' => $viewType === 'daily' ? 'Daily Production Performance (Current Month)' : 
                  ($viewType === 'weekly' ? 'Weekly Production Performance (Current Month)' : '3 Months Production Performance')
    ]);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
