<?php
// API: feeder/line/API/member_photos.php
// Actions:
//   GET  ?action=get&line_id=1         -> returns { success, data: { "A": { leader: url, technician: url }, "B": { ... } } }
//   POST action=set, line_id, group, role, url  -> upserts a record and returns { success }
//
// Requires DB table (MySQL example):
//   CREATE TABLE IF NOT EXISTS fmember_photos (
//     id INT AUTO_INCREMENT PRIMARY KEY,
//     Fline_ID INT NOT NULL,
//     group_code VARCHAR(8) NOT NULL,
//     role VARCHAR(32) NOT NULL,
//     photo_url TEXT NOT NULL,
//     updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
//     UNIQUE KEY uq_line_group_role (Fline_ID, group_code, role)
//   );

header('Content-Type: application/json');

try {
  include_once '../../../database/init.php'; // provides $database (Medoo)
} catch (Exception $e) {
  http_response_code(500);
  echo json_encode([ 'success' => false, 'error' => 'DB init failed' ]);
  exit;
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? ($_POST['action'] ?? '');

function jres($ok, $data = [], $code = 200) {
  http_response_code($code);
  echo json_encode(array_merge([ 'success' => (bool)$ok ], $data));
  exit;
}

if ($action === 'get' && $method === 'GET') {
  $lineId = isset($_GET['line_id']) ? intval($_GET['line_id']) : 0;
  if ($lineId <= 0) { jres(false, [ 'error' => 'Missing line_id' ], 400); }
  try {
    $rows = $database->select('fmember_photos', ['Fline_ID','group_code','role','photo_url'], [ 'Fline_ID' => $lineId ]);
    $map = [ 'A' => [ 'leader' => '', 'technician' => '' ], 'B' => [ 'leader' => '', 'technician' => '' ] ];
    if (is_array($rows)) {
      foreach ($rows as $r) {
        $g = strtoupper((string)($r['group_code'] ?? ''));
        $role = strtolower((string)($r['role'] ?? ''));
        $url = (string)($r['photo_url'] ?? '');
        if (!isset($map[$g])) $map[$g] = [];
        $map[$g][$role] = $url;
      }
    }
    jres(true, [ 'data' => $map ]);
  } catch (Exception $e) {
    jres(false, [ 'error' => 'Query failed' ], 500);
  }
}

if ($action === 'set' && $method === 'POST') {
  $lineId = isset($_POST['line_id']) ? intval($_POST['line_id']) : 0;
  $group = isset($_POST['group']) ? strtoupper(trim((string)$_POST['group'])) : '';
  $role  = isset($_POST['role']) ? strtolower(trim((string)$_POST['role'])) : '';
  $url   = isset($_POST['url']) ? trim((string)$_POST['url']) : '';

  if ($lineId <= 0 || !$group || !$role) { jres(false, [ 'error' => 'Missing parameters' ], 400); }
  // Allow empty URL to mean reset
  try {
    $existing = $database->get('fmember_photos', ['id'], [ 'Fline_ID' => $lineId, 'group_code' => $group, 'role' => $role ]);
    if ($existing && isset($existing['id'])) {
      $database->update('fmember_photos', [ 'photo_url' => $url ], [ 'id' => $existing['id'] ]);
    } else {
      $database->insert('fmember_photos', [ 'Fline_ID' => $lineId, 'group_code' => $group, 'role' => $role, 'photo_url' => $url ]);
    }
    jres(true);
  } catch (Exception $e) {
    jres(false, [ 'error' => 'Save failed' ], 500);
  }
}

jres(false, [ 'error' => 'Unsupported action/method' ], 405);
