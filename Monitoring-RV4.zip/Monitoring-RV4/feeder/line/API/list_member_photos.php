<?php
// API: feeder/line/API/list_member_photos.php
// GET: line_id, group, role
// Returns previously uploaded files for that line/group/role by scanning the uploads directory
// { success: true, files: [ { url, name, size, mtime } ] }

header('Content-Type: application/json');

function jres($ok, $data = [], $code = 200) {
  http_response_code($code);
  echo json_encode(array_merge([ 'success' => (bool)$ok ], $data));
  exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
  jres(false, [ 'error' => 'Method not allowed' ], 405);
}

$lineId = isset($_GET['line_id']) ? intval($_GET['line_id']) : 0;
$group  = isset($_GET['group']) ? strtoupper(trim((string)$_GET['group'])) : '';
$role   = isset($_GET['role']) ? strtolower(trim((string)$_GET['role'])) : '';

if ($lineId <= 0 || !$group || !$role) {
  jres(false, [ 'error' => 'Missing parameters' ], 400);
}

$dir = __DIR__ . '/../uploads';
if (!is_dir($dir)) { jres(true, [ 'files' => [] ]); }

$prefix = 'line' . $lineId . '_' . $group . '_' . $role . '_';
$dh = opendir($dir);
if (!$dh) { jres(false, [ 'error' => 'Cannot read uploads directory' ], 500); }

$files = [];
while (($file = readdir($dh)) !== false) {
  if ($file === '.' || $file === '..') continue;
  if (strpos($file, $prefix) !== 0) continue;
  $path = $dir . '/' . $file;
  if (!is_file($path)) continue;
  $stat = stat($path);
  $files[] = [
    'url' => '../uploads/' . $file,
    'name' => $file,
    'size' => $stat ? (int)$stat['size'] : 0,
    'mtime' => $stat ? (int)$stat['mtime'] : 0
  ];
}
closedir($dh);

// sort newest first
usort($files, function($a,$b){ return ($b['mtime'] <=> $a['mtime']); });

jres(true, [ 'files' => $files ]);
